echo "Cleaning compiled tools"
rm ${LIBSVM_PYTHON_DIR}/../svm.o
rm ${LIBSVM_PYTHON_DIR}/../libsvm.so.2

rm ${SPINEX_DIR}/phipsi_dssp.e
rm ${SPINEX_DIR}/bin/phipsi_ss0.e
rm ${SPINEX_DIR}/bin/phipsi_rsa.e
rm ${SPINEX_DIR}/bin/phipsi_phipsi0.e
rm ${SPINEX_DIR}/bin/phipsi_ss1.e
rm ${SPINEX_DIR}/bin/phipsi_phipsi1.e

rm ${SPINED_DIR}/data/davar/binary/dphi/spiner_test.e
rm ${SPINED_DIR}/data/davar/binary/dpsi/spiner_test.e
rm ${SPINED_DIR}/data/spd/forcasp9/spiner_pred.e
