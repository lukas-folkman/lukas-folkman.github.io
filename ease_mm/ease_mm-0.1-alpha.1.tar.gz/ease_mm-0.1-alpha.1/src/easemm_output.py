#!/usr/bin/env python

import sys
import easemm_input
import biodata
import collections

EASE_MM_THRESHOLD = 0.328
NEUTRAL = 0.5
LIKELY = 1
if LIKELY < NEUTRAL: raise ValueError

def get_formatted_result(ddg_raw, probability_raw):
	ddg = ('%.4f' % ddg_raw) if ddg_raw is not None else None
	if ddg_raw >= LIKELY: ddg_class = 'stabilising'
	elif ddg_raw <= -1 * LIKELY: ddg_class = 'destabilising'
	elif ddg_raw > -1 * NEUTRAL and ddg_raw < NEUTRAL: ddg_class = 'neutral'
	elif ddg_raw >= NEUTRAL and ddg_raw < LIKELY: ddg_class = 'likely_stabilising'	
	elif ddg_raw > -1 * LIKELY and ddg_raw <= -1 * NEUTRAL: ddg_class = 'likely_destabilising'
	else: raise ValueError
	stability_class_probability, stability_class = None, None
	if probability_raw is not None:
		rescaled_prob = rescale_probability(probability_raw, EASE_MM_THRESHOLD)
		stability_class = 'STABILISING' if rescaled_prob > 0.5 else 'DESTABILISING'
		rescaled_prob = rescaled_prob if rescaled_prob > 0.5 else 1 - rescaled_prob
		stability_class_probability = ('%.2f' % (100 * rescaled_prob)) + '%'	
	return ddg, ddg_class, stability_class_probability, stability_class

def save_results(predictions, output_fn, spider_dir=None, chr_info=None, class_output=False):
	with open(output_fn, 'w') as f:
		print >> f, '#' + ('chr_info\t' if chr_info is not None else '') + 'seq_name\tmutation\tddG\tddG_class\t' + ('stability_class\tclass_probability\t' if class_output else '') + 'SS\trASA'
		spider_cache, seq_id_cache = None, None
		for seq_id in predictions:
			if spider_dir is not None and seq_id != seq_id_cache:
				spider_cache = biodata.parse_spider(seq_id, path=spider_dir)
				seq_id_cache = seq_id
			for mutation in predictions[seq_id]:
				ss, rasa = '---', '---'
				if spider_dir is not None:
					position = int(mutation[1:-1])
					if mutation[0] != spider_cache[position - 1][0]:
						print >> sys.stderr, 'ERROR: Spider file (predicted SS/rASA) does not match the sequence'
						raise ValueError
					ss = spider_cache[position - 1][1]
					rasa = '%.2f' % biodata.get_relative_asa(mutation[0], float(spider_cache[position - 1][7]))
				ddg, ddg_class, class_prob, stab_class = get_formatted_result(predictions[seq_id][mutation][0], predictions[seq_id][mutation][1])
				if chr_info is not None:
					for chr_i in chr_info[seq_id + '_' + mutation]:
						print >> f, '\t'.join([chr_i, seq_id, mutation, ddg, ddg_class] + ([stab_class, class_prob] if class_output else []) + [ss, rasa])
				else:
					print >> f, '\t'.join([seq_id, mutation, ddg, ddg_class] + ([stab_class, class_prob] if class_output else []) + [ss, rasa])

def rescale_probability(probability, threshold):
	if probability > threshold:
		a = threshold
		b = 1.0
		c = probability
		y = 0.5
		z = 1.0
	else:
		a = 0.0
		b = threshold
		c = probability
		y = 0.0
		z = 0.5

	#rescale a----c---b to y----x---z
	return ( ((z - y) / (b - a)) * (c - a) ) + y
	
def read_results(filename):
	predictions = collections.OrderedDict({})
	with open(filename, 'r') as f:
		for line in f:
			if line[0] == '#': continue
			line_split = line.strip().split()
			if len(line_split) != 4:
				print >> sys.stderr, 'ERROR: unexpected format of the results file:', line.strip() 
				raise ValueError
			seq_id, mut, real, raw_prob = line_split
			if seq_id not in predictions: predictions[seq_id] = collections.OrderedDict({})
			if mut in predictions[seq_id]:
				print >> sys.stderr, 'ERROR: duplicate prediction:', line.strip()
				raise ValueError
			predictions[seq_id][mut] = (float(real) if real is not None else None, float(raw_prob) if raw_prob is not None else None)
	return predictions

def read_sequences(sequence_ids):
	seq_id_dict = {}
	for seq_id in sequence_ids:
		seq_id_dict[biodata.read_fasta(seq_id)] = seq_id
	return seq_id_dict
	
def main():
	USAGE = 'USAGE: python easemm_output.py result_filename {protein|genome} query_filename {realval|realval_class} [--tab_output tab_output] [--spider_dir spider_dir]'
	if len(sys.argv) == 5 or len(sys.argv) == 7 or len(sys.argv) == 9:
		result_fn = sys.argv[1]
		query_type = sys.argv[2]
		if query_type not in ['protein', 'genome']: print >> sys.stderr, 'WRONG ARGUMENTS:', ' '.join(sys.argv), '\n', USAGE; sys.exit(1) 
		query_fn = sys.argv[3]
		if sys.argv[4] == 'realval': class_output = False
		elif sys.argv[4] == 'realval_class': class_output = True
		else: print >> sys.stderr, 'WRONG ARGUMENTS:', ' '.join(sys.argv), '\n', USAGE; sys.exit(1) 
		tab_output, spider_dir = None, None
		if len(sys.argv) == 7 or len(sys.argv) == 9:
			if sys.argv[5] == '--tab_output': tab_output = sys.argv[6]
			else: print >> sys.stderr, 'WRONG ARGUMENTS:', ' '.join(sys.argv), '\n', USAGE; sys.exit(1) 
			if len(sys.argv) == 9:
				if sys.argv[7] == '--spider_dir': spider_dir = sys.argv[8]
				else: print >> sys.stderr, 'WRONG ARGUMENTS:', ' '.join(sys.argv), '\n', USAGE; sys.exit(1) 
	else:
		print >> sys.stderr, 'WRONG ARGUMENTS:', ' '.join(sys.argv), '\n', USAGE; sys.exit(1)
	
	chr_info = None
	predictions = read_results(result_fn)
	if len(predictions) == 0:
		print 'No successful predictions, please check your inputs.'
		sys.exit()
	
	if query_type == 'protein':
		seq_id_dict = read_sequences(predictions.keys())
		print '#SEQ: seq_name MEAFNKLSPRYA...\n#MUT: XnY ddG ddG_class ' + ('stability_class class_probability ' if class_output else '') + 'WmZ ddG ddG_class ' + ('stability_class class_probability ' if class_output else '') + '...'
		seq_lines, mut_lines = easemm_input.read_seq_mut_from_query(query_fn)
		for i in range(len(seq_lines)):
			name = seq_lines[i][0]
			seq = seq_lines[i][1]
			mutations = mut_lines[i][0]
			if seq in seq_id_dict:
				seq_id = seq_id_dict[seq]
				results = ''
				for mutation in mutations:
					for m in easemm_input.expand_wild_card_mutation(mutation, seq):
						results += m + ' '
						ddg, ddg_class, stability_class_probability, stability_class = None, None, None, None
						if seq_id in predictions and m in predictions[seq_id]:
							ddg, ddg_class, stability_class_probability, stability_class = get_formatted_result(predictions[seq_id][m][0], predictions[seq_id][m][1])
						results += str(ddg) + ' ' + str(ddg_class) + ' ' + (str(stability_class) + ' ' + str(stability_class_probability) + ' ' if class_output else '')
			else:
				results = 'ERROR: an unexpected error occurred while predicting these mutations.'
			print 'SEQ:', name, seq
			print 'MUT:', results
			
	elif query_type == 'genome':
		print '#CHR\tPOS\tccds_mutation_id\tREF\tALT\tddG\tddG_class' + ('\tstability_class\tclass_probability' if class_output else '')
		chr_info = {}
		with open(query_fn, 'r') as f:
			for line in f:
				v = biodata.VariantData(line.strip().split())
				chromosome, position, reference, mutated = biodata.get_chr_info(v.pdb_id)
				ddg, ddg_class, stability_class_probability, stability_class = None, None, None, None
				if v.seq_id in predictions and v.ddg_mutation_info() in predictions[v.seq_id]:
					key = v.seq_id + '_' + v.ddg_mutation_info()
					if key not in chr_info: chr_info[key] = []
					chr_info[key].append(v.pdb_id)
					ddg, ddg_class, stability_class_probability, stability_class = get_formatted_result(predictions[v.seq_id][v.ddg_mutation_info()][0], predictions[v.seq_id][v.ddg_mutation_info()][1])
				print '\t'.join(map(str, [chromosome, position, v.seq_id + '_' + v.ddg_mutation_info(), reference, mutated, ddg, ddg_class] + ([stability_class, stability_class_probability] if class_output else [])))
	else:
		raise ValueError
	
	if tab_output is not None: save_results(predictions, tab_output, spider_dir, chr_info, class_output=class_output)
	
if __name__ == "__main__":
	main()
