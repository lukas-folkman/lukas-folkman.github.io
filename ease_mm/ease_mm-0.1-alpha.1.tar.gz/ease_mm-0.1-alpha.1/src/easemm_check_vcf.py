#!/usr/bin/env python

import sys
import biodata
import easemm_input

def parse_vcf_input(line, line_number):
	line_split = line.strip().split()
	if len(line_split) < 5:
		raise easemm_input.EaseFormatError('Input too short, these field are mandatory: CHROM POS ID REF ALT', line_number)
	
	chromosome = line_split[0]
	chromosome = chromosome.strip('chr')
	if chromosome not in biodata.CHROMOSOMES:
		raise easemm_input.EaseFormatError('Invalid chromosome (CHROM), only 1-22XY are supported', line_number)
	
	try:
		position = int(line_split[1])
	except ValueError:
		raise easemm_input.EaseFormatError('Invalid position (POS), not a number',line_number)
	
	reference = line_split[3]
	mutated = line_split[4]
	if not biodata.isDNA(reference) or not biodata.isDNA(mutated):
		raise easemm_input.EaseFormatError('Only ACGT is supported for the REF and ALT fields', line_number)
	if reference == mutated:
		raise easemm_input.EaseFormatError('REF must be different from ALT', line_number)
	
	return chromosome, position, reference, mutated

def main():
	if len(sys.argv) < 2 or len(sys.argv) > 3: print >> sys.stderr, 'USAGE: python easemm_check_vcf.py query_filename [SNV]'; sys.exit(1)
	query_filename = sys.argv[1]
	snv_only = sys.argv[2] == 'SNV' if len(sys.argv) > 2 else False
	line_number = 0
	error = []
	with open(query_filename, 'r') as f:
		for line in f:
			line_number += 1
			if line[0] == '#' or len(line.strip()) == 0: continue
			try:
				chromosome, position, reference, mutated = parse_vcf_input(line, line_number)
				if not snv_only or biodata.isSNP(reference, mutated):
					print '\t'.join([chromosome, str(position), '.', reference, mutated])
			except easemm_input.EaseFormatError as e:
				error.append(e.message)
	if len(error) != 0:
		print >> sys.stderr, '\n'.join(error)
		sys.exit(1)

if __name__ == "__main__":
	main()
