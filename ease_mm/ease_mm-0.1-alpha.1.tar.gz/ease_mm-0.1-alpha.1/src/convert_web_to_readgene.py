#!/usr/bin/env python

import sys
import features
import biodata

def main():
	if len(sys.argv) != 2: print >> sys.stderr, 'USAGE: python convert_web_to_readgene.py query_filename'; sys.exit(1)
	
	web_format_fn = sys.argv[1]
	
	with open(web_format_fn + '.mapping', 'w') as mapping_file:
		with open(web_format_fn, 'r') as f:
			chr_cache = None
			for line in f:
				if line[0] == '#': continue
				try:
					chromosome, position, reference, mutated = biodata.parse_user_input(line)
				except ValueError as e:
					print >> sys.stderr, 'ERROR:', str(e), ':', line.strip()
					continue
	
				#strip SNV
				if biodata.isSNP(reference, mutated):
					reference, mutated, position = biodata.strip_snp_ref_mut(reference, mutated, position)
				#otherwise, strip and change padding regardless of the variant type
				else:
					# make post-padding a single letter post-padding
					if reference.endswith(mutated) or mutated.endswith(reference):
						reference, mutated = biodata.strip_end_to_sigle_base(reference, mutated)
					#change pre-padding to post-padding
					elif reference.startswith(mutated) or mutated.startswith(reference):
						if chr_cache != chromosome:
							chr_cache = chromosome
							chromosome_seq = biodata.parse_chromosome_ref_ass_1000G(chromosome, features.REF_GENOME)
						try:
							changed_padding = biodata.change_padding(chromosome_seq, chromosome, position, reference, mutated).split()
							reference, mutated, position = changed_padding[3], changed_padding[4], changed_padding[1]
						except Exception:
							print >> sys.stderr, 'ERROR: CANNOT CHANGE PADDING:', line.strip()
							continue
					#there is no padding
					else:
						print >> sys.stderr, 'ERROR: NO PADDING OR COMPLEX CHANGE:', line.strip()
						continue
				
				print >> mapping_file, '|'.join(['chr'+chromosome, str(position), reference + '/' + mutated]), line.strip()
				print '\t'.join(['chr'+chromosome, str(position), '.', reference, mutated])

if __name__ == "__main__":
	main()
