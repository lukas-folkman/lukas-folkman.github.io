#!/usr/bin/env python
from misc_yang import *
import os

server = 'http://sparks-lab.org/server/ease'

def prtmail(email, jobid, descr, sdir):
	fp = open(os.path.join(sdir, 'email.txt'), 'w')
	print >>fp, """From: webmaster@sparks-lab.org (do not reply!)
To: %s
Subject: EASE-MM results for job %s
Follow this link to collect your results:
%s/info/%s/results.html
""" % (email, descr, server, jobid)
	fp.close()
	os.system('cat %s | sendmail -t' % os.path.join(sdir, 'email.txt'))

def buildweb(fn, fn_error, jobid, descr):
	lines = openfile(fn).readlines() if os.path.isfile(fn) else None
	# build the html from file 'result'
	fp = openfile(os.path.join(sdir, "results.html"), "w")
	print >>fp, "<html><title>EASE-MM results</title><head><style> a:link {color:green;} a:visited {color:green;} a:hover {color:#c5000b;} a:active {color:green;} </style></head><body>\n";
	if lines is None or len(lines) == 0:
		print >>fp, '<h2><font color=red size=5>Incorrect query format</font></h2>'
		with open(fn_error, 'r') as fp_error:
			print >>fp, '<p>%s</p>' % '<br>\n'.join(fp_error.readlines())
		print >>fp, '<hr><p>Please check your <a href="query">query</a> and the correct <a href="%s/ease_format.txt">format</a> for EASE-MM web-server.<br>' % server
		print >>fp, 'If the problem persists, please contact the web-master.</p>'
		print >>fp, "</body></html>"
		fp.close()
		return
#
	chr_info = lines[0].strip('#').strip().split()[0] == 'chr_info'
	print >>fp, '<h2>EASE-MM results for job: %s</h2>' % descr
	print >>fp, '<p>Results in the EASE-MM query format: <a href="results_query.txt">results_query.txt</a></p>'
	print >>fp, '<p>Results in a tab-delimited format: <a href="results.txt">results.txt</a></p>'
	print >>fp, '<p>The query submitted for this job: <a href="query">query</a></p>'
	with open(fn_error, 'r') as fp_error:
		if len(fp_error.readlines()) != 0: print >>fp, '<p><font color=red><b>Error log:</b></font> <a href="error">error</a></p>'
	print >>fp, '<p>Please see the description of EASE-MM\'s <a href="%s">output format</a>.</p>' % (server + '/ease_output.txt')
	print >>fp, "<table border='0'>"
	print >>fp, '<tr>' + ('<th>VCF<sup>&nbsp;</sup>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th> ' if chr_info else '') + '<th>Sequence name<sup>&nbsp;</sup>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th> <th>Mutation<sup>&nbsp;</sup>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th> <th>&Delta;&Delta;G<sub>u</sub>&nbsp;<sup>[<a href="'+server+'/ease_output.txt">?</a>]</sup></th> <th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th> <th>Stability class&nbsp;<sup>[<a href="'+server+'/ease_output.txt">?</a>]</sup>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th> <th>SS&nbsp;<sup>[<a href="'+server+'/ease_output.txt">?</a>]</sup>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th> <th>rASA&nbsp;<sup>[<a href="'+server+'/ease_output.txt">?</a>]</sup>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th> <th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>  <th>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>  <th></th> </tr>'
	fp.flush()
	for x in lines:
		ss = x.split()
		if x[0] == '#' or len(ss) == 0: continue
		try:
			seq_name_id = 1 if chr_info else 0
			seq_name = ss[seq_name_id]
			ss[seq_name_id] = '<a href="features/%s.fasta">%s</a>' % (seq_name, seq_name)
			ss[seq_name_id + 3] = ss[seq_name_id + 3].replace('_', ' ')
			if ss[seq_name_id + 3].lower() == 'stabilising':
				ss[seq_name_id + 3] = '<font color=blue><i>%s</i></font>' % ss[seq_name_id + 3].lower()
			elif ss[seq_name_id + 3].lower() == 'likely stabilising':
				ss[seq_name_id + 3] = '<font color=navy><i>%s</i></font>' % ss[seq_name_id + 3].lower()
			elif ss[seq_name_id + 3].lower() == 'destabilising':
				ss[seq_name_id + 3] = '<font color=red><i>%s</i></font>' % ss[seq_name_id + 3].lower()
			elif ss[seq_name_id + 3].lower() == 'likely destabilising':
				ss[seq_name_id + 3] = '<font color=firebrick><i>%s</i></font>' % ss[seq_name_id + 3].lower()
			elif ss[seq_name_id + 3].lower() == 'neutral':
				ss[seq_name_id + 3] = '<font color=black><i>%s</i></font>' % ss[seq_name_id + 3].lower()
			print >>fp, ('<tr>' + ('<td>%s</td> ' if chr_info else '') + '<td>%s</td> <td>%s</td> <td align="right">%s</td> <td></td> <td>%s</td> <td>%s</td> <td>%s</td> <td>%s</td> <td>%s</td> <td>%s</td></tr>') % tuple(ss + ['<a href="features/%s.pssm">PSSM</a>' % seq_name, '<a href="features/%s.spd3">SPIDER</a>' % seq_name, '<a href="features/%s.spd">SPINE-D</a>' % seq_name])
		except:
			print >>fp, "UNEXPECTED ERROR: %s<br>" % x
	print >>fp, "</table>"
	print >>fp, "</body></html>"
	fp.close()
#
# Main
if len(argv) < 1: die('usage: RUN sdir')
sdir = argv[1]
ss = openfile(os.path.join(sdir, 'info')).readline().split()
jobid, descr, email = ss[0], ss[0], ss[1]
try: descr = ' '.join(ss[3 : 3 + int(ss[2])]) if int(ss[2]) > 0 else ss[0] 
except: pass
if len(descr) > 60: descr = descr[:57] + '...'
buildweb(os.path.join(sdir, 'results.txt'), os.path.join(sdir, 'error'), jobid, descr)
if '@' in email: prtmail(email, jobid, descr, sdir)

