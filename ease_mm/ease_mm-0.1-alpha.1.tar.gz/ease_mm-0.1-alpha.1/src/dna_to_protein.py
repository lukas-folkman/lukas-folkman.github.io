#!/usr/bin/env python

import biodata
import sys

def isDNA(dna):
	for base in dna:
		if base.upper() not in 'ACGT':
			return False
	return True

def isNFS(reference_nu, mutated_nu, reference_aa, mutated_aa):
	return (len(reference_nu) - len(mutated_nu)) % 3 == 0 and not ('*' in mutated_aa and '*' not in reference_aa)

def main():
	if len(sys.argv) != 5: print >> sys.stderr, 'USAGE: python dna_to_protein.py query_filename CCDS_nucleotides CCDS_proteins CCDS_data'; sys.exit(1)
	disease = 1
	variant_datafile = sys.argv[1]
	ccds_dna_filename = sys.argv[2]
	ccds_protein_filename = sys.argv[3]
	ccds_data_filename = sys.argv[4]
	
	ccds_dna = biodata.parse_ccds_fasta_datafile(ccds_dna_filename)
	ccds_proteins = biodata.parse_ccds_fasta_datafile(ccds_protein_filename)
	ccds_data = biodata.parse_ccds_datafile(ccds_data_filename)
	
	with open(variant_datafile) as f:
		for line in f:
			if line[0] != '>':
				continue
			line_split = line[1:].split()
			line_split.insert(0, str(disease))
			line_split.append('-1') #just to obey the format
			line_split.append('-1') #just to obey the format
			line_split.append('None') #just to obey the format
			line_split.append('NA') #just to obey the format
			variant = biodata.VariantData(line_split, strict=False)
			
			if not isDNA(variant.reference) or not isDNA(variant.mutated):
				print >> sys.stderr, 'ERROR: NON-DNA BASE:', line.strip()
				continue
			
			seq = ccds_dna[variant.seq_id]
			dna_position = variant.position * 3
			extracted_reference = seq[dna_position : dna_position + len(variant.reference)]
			if variant.reference != extracted_reference:
				print >> sys.stderr, 'ERROR: variant data and ccds_nu do not match:', variant, 'ccds_nu:', extracted_reference, 'in', line.strip()
				continue
			
			reference_aa = biodata.translate_dna(variant.reference)
			mutated_aa = biodata.translate_dna(variant.mutated)
			if biodata.isSNP(variant.reference, variant.mutated):
				if mutated_aa == '*':
					variant.type = 'NS'
				else:
					variant.type = 'MS'
			elif isNFS(variant.reference, variant.mutated, reference_aa, mutated_aa):
				variant.type = 'NFS'
			else:
				variant.type = 'FS'
				mutated_aa = biodata.translate_dna(variant.mutated + seq[dna_position + len(variant.reference) :])
				if '*' not in mutated_aa:
					mutated_aa += '!'
				else:
					mutated_aa = mutated_aa[:mutated_aa.find('*')+1]
			
			variant.reference = reference_aa
			variant.mutated = mutated_aa
			
			try: biodata.check_seq(variant, ccds_proteins[variant.seq_id])
			except ValueError: variant.type = 'SEQ_MISMATCH'
			
			if variant.type == 'FS':
				biodata.reposition_mutation_site(variant, ccds_proteins)
				if isNFS(variant.chr_reference, variant.chr_mutated, variant.reference, variant.mutated):
					variant.type = 'NFS'
			
			if variant.type == 'NS' or variant.type == 'MS':
				if variant.reference != variant.mutated:
					biodata.strip_snp_variant(variant)
				else:
					variant.type = 'SYNONYMOUS'
			
			variant.set_splice_aa_sites(ccds_data)
			variant.set_gene_name(ccds_data)
			
			if variant.type not in ['SEQ_MISMATCH', 'SYNONYMOUS']:
				try:
					#this will check if everything complies with the format
					variant = biodata.VariantData(str(variant).split())
				except biodata.ComplexChangeVariantException:
					variant.type = variant.type + '_COMPLEX_CHANGE'
			
			print variant

if __name__ == "__main__":
	main()
