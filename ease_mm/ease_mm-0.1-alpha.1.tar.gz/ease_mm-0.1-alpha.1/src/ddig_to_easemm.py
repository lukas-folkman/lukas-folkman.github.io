#!/usr/bin/env python

import sys
import biodata

lines = open(sys.argv[1], 'r').readlines()

#-1 CCDS10001.1 124 G/S chr14|105739124|C/T - 107 66 35 22 BRF1 MS
#1A23 H32L 1A23 7.0 30.0 5.3 1 DDG

for line in lines:
	v = biodata.VariantData(line.strip().split())
	print v.chr_info(), v.reference + str(v.position + 1) + v.mutated, v.seq_id, 0.0, 0.0, 0.0, -1, 'DDG'