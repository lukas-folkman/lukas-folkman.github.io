#include "misc.h"

class CCDS_class;
vector<CCDS_class> ccds_dat;
map<string, string> ccds_nuc;
const int CHR_X=23, CHR_Y=24;
FILE *fp_target;
//
namespace SNP_dat{
	int frag_chr, frag_dir, snp_pos, snp_size, snp_num;
	long frag_start;
	string frag_seq, snp_seq0, snp_seq1, snp_target, tags;
	string frag_seq_rev, snp_seq0_rev, snp_seq1_rev;
};
//
string reverse_seq(string &seq1){
	string seq2 = seq1;
	reverse(seq2.begin(), seq2.end());
	for(int i=0; i<seq2.size(); i++){
		if(seq2[i] == 'A') seq2[i] = 'T';
		else if(seq2[i] == 'T') seq2[i] = 'A';
		else if(seq2[i] == 'G') seq2[i] = 'C';
		else if(seq2[i] == 'C') seq2[i] = 'G';
		else {
			warn("unkown base: -%c- %s\n", seq2[i], seq1.c_str());
			seq2[i] = 'N';
		}
	}
	return seq2;
}
int getchr_num(char *chr){
	if(*chr == 'X') return CHR_X;
	else if(*chr == 'Y') return CHR_Y;
	else return atoi(chr);
}
class CCDS_class{
	int noDNAseq;
	int chromo, gene_id, direction;
	long pos_start, pos_end, nbase;
	string nc_accession, gene, ccds_id;
	vector<long> frags[3];
public:
	CCDS_class(char *str){
		noDNAseq = 0;
		char ss[400][50];
		int nt = str2dat(str, ss);
		int it = strlen(ss[nt-2]);
		if(ss[nt-2][it-1] != ']') die("wrong CCDS: %s", str);
//
		chromo = getchr_num(ss[0]);
		nc_accession = ss[1];
		gene = ss[2];
		gene_id = atoi(ss[3]);
		ccds_id = ss[4];
		if(strchr("XY", ss[0][0]) != NULL) ccds_id = ccds_id + ss[0][0];
		for(it=6; it<nt; it++){
			if(ss[it][0] == '[') break;
		}
		if(it>=nt-1) die("no [: %s", str);
//
		direction = ss[it-3][0];
		if(direction != '+' && direction != '-'){
			die("wrong ccds direction: %s\n%s", ss[it-3], str);
		}
		pos_start = atoi(ss[it-2]);
		pos_end = atoi(ss[it-1]);
//
		long i1, i2, n=0, m=-1;
		for(int i=it; i<nt-1; i++){
			int k=0;
			if(i==it) {assert(ss[i][0] == '['); k=1;}
			sscanf(ss[i]+k, "%ld-%ld", &i1, &i2);
// CCDS: [a-b] starting from 0
			frags[0].push_back(i1);
			frags[1].push_back(i2);
			frags[2].push_back(n);
			n += (i2 - i1) + 1;
			if(i1 <= m) die("some overlap or unsorted: %s", str);
			m = i2;
//			printf(" %ld-%ld", i1, i2);
		}
		nbase = n;
//		printf("\n");
	}
	int has_site(int ic, long ipos){
		if(ic==chromo && ipos>=pos_start && ipos<=pos_end) return 1;
		return 0;
	}
	int calfrag(long i1){
		for(int i=0; i<frags[0].size(); i++){
			if(i1>=frags[0][i]){
				if(i1<=frags[1][i]) return i;
			} else return -(i+1);
		}
		return -(int(frags[0].size()) + 100);
	}
	int calposition(){
		using namespace SNP_dat;
		int nseq = frag_seq.size();
		long i0 = frag_start;
		long i1 = i0 + nseq - 1;
		if(noDNAseq) return -1; //{cerr<<"noDNA "<<ccds_id<<endl; return -1;}
		if(! has_site(frag_chr, i0) || ! has_site(frag_chr, i1)) return -1; 
		int brev = 0;
		if(frag_dir == '*'){
			if(direction == '-') brev = 1;
		} else if(frag_dir != direction) {
			cout<<"diff_dir "<<ccds_id<<endl; return -1;
		}
		int idx[nseq];
		long i = i0;
		for(int m=0; m<nseq; m++) idx[m] = -100;
/*		cout<<frags[0][0]<<' '<<frags[1][0]<<' '<<frags[2][0]<<endl;
		cout<<i0<<endl;*/
		vector<int> frag_used;
		while(i < i0+nseq){
			int ik = i;
			int it = calfrag(i);
			if(it <= -(int(frags[0].size()) + 100)) {
				for(;i<i0+nseq; i++) idx[i-i0] = -1;
			} else {
				if(it < 0){
					it = -it - 1;
					for(; i<min(frags[0][it]+1, i0+nseq); i++) idx[i-i0] = -1;
				}
				if(i<min(frags[1][it]+1, i0+nseq)) frag_used.push_back(it);
				for(; i<min(frags[1][it]+1, i0+nseq); i++){
					if(i < frags[0][it]) continue;
					idx[i-i0] = frags[2][it] + (i-frags[0][it]);
				}
			}
			if(i==ik) die("stuck at: %d %d", i, it);
		}
		if(frag_used.size() > 1){
			printf("multiple frag: "); prtdim(frag_used.size(), frag_used);
		}
		if(ccds_nuc.count(ccds_id) < 1){
			noDNAseq = 1;
			warn("no ccds seq: %s", ccds_id.c_str());
			return -2;
		}
		string *pfrag_seq=&frag_seq, *psnp_seq1=&snp_seq1;
		if(brev){
			pfrag_seq = &frag_seq_rev;
			psnp_seq1 = &snp_seq1_rev;
		}
		string *ref_seq = &ccds_nuc[ccds_id];
		assert(nbase == ref_seq->size());
		if(direction == '-'){
			reverse(idx, idx+nseq);
			for(int i=0; i<nseq; i++){
				if(idx[i] < 0) continue;
				idx[i] = nbase - idx[i] - 1;
			}
		}
		bool bmatch = 1;
		string seq1(nseq, '-');
		for(i=0; i<nseq; i++){
			if(idx[i] < 0) continue;
			seq1[i] = '+';
			if((*pfrag_seq)[i] != (*ref_seq).at(idx[i])){
				bmatch = 0; seq1[i] = (*ref_seq).at(idx[i]);
			}
		}
		long c1=-1, c2=-1;
		if(! bmatch && *pfrag_seq!="N") {
			printf("not match: %s %s  %s\n", pfrag_seq->c_str(), seq1.c_str(), tags.c_str());
			goto lprint;
		}
		for(int i=snp_pos; i<snp_pos+max(1,snp_size); i++){
			if(idx[i] < 0) {
				printf("snp in boundary: ");
				goto lprint;
			}
		}
		{
			int it = frag_used[0];
			c1 = i0-frags[0][it];
			c2 = frags[1][it] - i0;
			if(direction == '-') swap(c1, c2);
		}
		{
			string seq2 = (*ref_seq);
			int i1 = (idx[snp_pos]/3) * 3;
			int n1 = (idx[snp_pos]+snp_size - i1 - 1)/3 + 1;
			string s1 = seq2.substr(i1, n1*3), s2 = s1;
			s2.replace(s2.begin()+idx[snp_pos]-i1, s2.begin()+idx[snp_pos]+snp_size-i1, *psnp_seq1);
			if (s1 == "") s1 = "-";
			if (s2 == "") s2 = "-";
			printf("\n>%s %d %s/%s %s %c %ld %ld\n", ccds_id.c_str(), i1/3, s1.c_str(), s2.c_str(), snp_target.c_str(), direction, c1, c2);
/*
			seq2.replace(seq2.begin()+idx[snp_pos], seq2.begin()+idx[snp_pos]+snp_size, " "+snp_seq1+" ");
			fprintf(fp_target, ">%s|%s|%d:%d:%ld|%d\n", ccds_id.c_str(), snp_target.c_str(), idx[snp_pos], snp_size, snp_seq1.size(), snp_num);
//			fprintf(fp_target, ">%s|%s|%d\n", ccds_id.c_str(), snp_target.c_str(), snp_num);
			snp_num ++;
			fprintf(fp_target, "%s\n", seq2.c_str());*/
			return 1;
		}
//
		lprint: ;
		bmatch = 0;
		for(i=0; i<nseq; i++){
			char c='-';
//			if(idx[i]>=0) c = (*ref_seq).at(idx[i]);
			if(idx[i] >= 0){
				if((*pfrag_seq)[i] == (*ref_seq).at(idx[i])) c = '+';
				else c = (*ref_seq).at(idx[i]);
			}
			if(snp_size==0 && i==snp_pos) cout<<'^';
			if(i>=snp_pos && i<snp_pos+snp_size){
				if(c=='+') c= '#';
				else if(c=='-') c='*';
				else c = tolower(c);
			}
			if(c=='*' || c=='+') bmatch = 1;
			cout<<c;
		}
		cout<<" "<<ccds_id<<endl;
		return 0;
	}
	friend void define_CCDS(int chr, long i1);
};
void rdCCDS(string fn){
	char str[9001];
	FILE *fp = openfile(fn);
	while(fgets(str, 9000, fp) != NULL){
		if(str[0] == '#') continue;
		if(strchr(str, '[') == NULL) continue;
		ccds_dat.push_back( CCDS_class(str) );
//		if(ccds_dat.size() > 5) break;
	}
	fclose(fp);
	cout<<"#ccds: "<<ccds_dat.size()<<endl;
}
void define_CCDS(int chr, long i1){
	for(int i=0; i<ccds_dat.size(); i++){
		if(! ccds_dat[i].has_site(chr, i1)) continue;
		printf(" %s", ccds_dat[i].ccds_id.c_str());
	}
	printf("\n");
}
void rdCCDS_nuc(string fn){
	char str[2001];
	FILE *fp = openfile(fn);
	string name;
	while(fgets(str, 2000, fp) != NULL){
		if(str[0] == '>'){
			int i0 = strchr(str, '|') - str;
			name = string(str).substr(1, i0-1);
			i0 = strlen(str);
			if(strchr("XY", str[i0-2]) != NULL) name += str[i0-2];
			if(ccds_nuc.count(name) > 0) die("dup ccds: %s", name.c_str());
			ccds_nuc[name] = "";
		} else {
			sscanf(str, "%s", str);
			ccds_nuc[name] += str;
		}
	}
	cout<<"#ccds_nuc size: "<<ccds_nuc.size()<<endl;
	fclose(fp);
}
void rdlist2(string fn){
	using namespace SNP_dat;
	char str[20001], ss[20][201], ss2[4][90];
	FILE *fp = openfile(fn);
	long i1, i2; int n=0;
	while(fgets(str, 20000, fp) != NULL){
		if(str[0] == '#') continue;
		if(strlen(str) < 5) continue;
		int nt = str2dat(str, ss);
		int chr=0;
		if(ss[0][0] == 'c') chr = getchr_num(ss[0]+3);
		else chr = getchr_num(ss[0]);
		i1 = strtol(ss[1], NULL, 10);
//		i1 = strtol(strchr(ss[3],':')+1, NULL, 10);
		i1 --; 			// here i1 starts from 1
		char direction = '*';
		snp_seq0 = ss[3];
		snp_seq1 = ss[4];
		if(nt >= 6) tags = ss[5];
		else tags = "";
		int nd = snp_seq0.size() - snp_seq1.size();
//		if(nd % 3 != 0) continue;		// for non-frameshift only
//		snp_seq0 = ss2[1]; snp_seq1 = ss2[2];
		snp_size = snp_seq0.size();
		frag_start = i1; snp_pos = 0;
		frag_seq = snp_seq0;
		frag_seq_rev = snp_seq0_rev = reverse_seq(snp_seq0);
		snp_seq1_rev = reverse_seq(snp_seq1);
		frag_dir = '*';
		frag_chr = chr;
//		cout<<i1<<' '<<i1+seq1.size()-1<<endl;
		snp_target = string(ss[0])+"|"+ss[1]+"|"+ss[3]+"/"+ss[4];
		snp_num = 0;
		bool found = 0;
		cout<<'#'<<snp_target<<' ';
		for(int i=0; i<ccds_dat.size(); i++){
			int it = ccds_dat[i].calposition();
			if(it > 0) {found = 1; break;}
		}
		if(! found) printf("not found\n");
	}
	fclose(fp);
}
void rdlist_HGMD(string fn){
	char str[2001], ss[20][201], ss2[4][90];
	FILE *fp = openfile(fn);
	long i1, i2; int n=0;
	while(fgets(str, 2000, fp) != NULL){
		if(str[0] == '#') continue;
		if(strlen(str) < 5) continue;
		str2dat(str, ss);
		int chr = getchr_num(ss[3]+3);
//		sscanf(strchr(ss[3],':')+1, "%ld", &i1);
		i1 = strtol(strchr(ss[3],':')+1, NULL, 10);
		i1 --; 			// here i1 starts from 1
		char direction = ss[4][1];
		if(strchr("+-", direction) == NULL) die("unknown direction: %s", ss[4]);
		string st = ss[5];
		st.at(st.find('[')) = ' ';
		st.at(st.find('/')) = ' ';
		st.at(st.find(']')) = ' ';
		sscanf(st.c_str(), "%s%s%s%s", ss2[0], ss2[1], ss2[2], ss2[3]);
		if(strlen(ss2[3]) == 0) die("wrong frag: %s", ss[5]);
		if(ss2[1][0] == '-') {ss2[1][0] = '\0'; i1 ++;}
		if(ss2[2][0] == '-') ss2[2][0] = '\0';
		string seq1 = string(ss2[0]) + ss2[1] + ss2[3];
//		define_CCDS(chr, i1);
		str[strlen(str)-1] = '\0';
		printf("%s %ld\n", str, strlen(ss2[0]));

//		cout<<seq1<<endl;
		using namespace SNP_dat;
		snp_seq0 = ss2[1]; snp_seq1 = ss2[2];
		snp_size = strlen(ss2[1]);
		if(direction == '+') snp_pos = strlen(ss2[0]);
		else snp_pos = strlen(ss2[3]);
		frag_start = i1 - snp_pos;
		snp_pos = strlen(ss2[0]);
		frag_seq = seq1;
		frag_dir = ss[4][1];
		frag_chr = chr;
//		cout<<i1<<' '<<i1+seq1.size()-1<<endl;
		snp_target = ss[2];
		snp_num = 0;
		bool found = 0;
		for(int i=0; i<ccds_dat.size(); i++){
			int it = ccds_dat[i].calposition();
			if(it > 0) {found = 1; break;}
		}
		if(! found) printf("not found\n");
	}
	fclose(fp);
}
int main(int argc, char *argv[]){
	if(argc < 3) die("usage: RUN CCDS CCDS_nu list_HGMD2");
	fp_target = openfile("tmp.fa", "w");
	rdCCDS(argv[1]);
	rdCCDS_nuc(argv[2]);
//	rdlist_HGMD(argv[3]);
	rdlist2(argv[3]);
}
