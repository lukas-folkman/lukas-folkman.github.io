#!/bin/bash

trap "exit 1" TERM
export MAIN_PID=$$

# paths to be set by the user
parallel=parallel
EASEMM_DIR=$HOME/sparks/ease_mm
TOOLS_DIR=$HOME/sparks/sparks_tools
CCDS_DIR=$HOME/sparks/features/CCDS
SPIDER_DIR=$TOOLS_DIR/spider2
export SPINEX_DIR=$TOOLS_DIR/spineX-2.0
export BLAST_DIR=$TOOLS_DIR/blast-2.2.26
export BLAST_DB=$TOOLS_DIR/blast_database/nrfilt
export SPINED_DIR=$TOOLS_DIR/spineD-2.0
export LIBSVM_PYTHON_DIR=$TOOLS_DIR/libsvm-3.17/python
# bash clean_all.sh
bash compile_all.sh

PARALLEL_JOBS=1 #specify 1 if you wish to use no parallel execution
# MAX_PROTEINS=100
# MAX_VCF=50000
OUTPUT_FORMAT="realval"
##

if [[ ! -d $EASEMM_DIR ]]; then echo "EASE-MM directory does not exist: $EASEMM_DIR" >&2; exit 1; fi
if [[ ! -d $BLAST_DIR ]]; then echo "BLAST directory does not exist: $BLAST_DIR" >&2; exit 1; fi
if [[ ! -d $(dirname $BLAST_DB) ]]; then echo "BLAST DATABASE does not exist: $(dirname $BLAST_DB)" >&2; exit 1; fi
if [[ ! -d $SPIDER_DIR ]]; then echo "SPIDER directory does not exist: $SPIDER_DIR" >&2; exit 1; fi
if [[ ! -d $SPINED_DIR ]]; then echo "SPINE-D directory does not exist: $SPINED_DIR" >&2; exit 1; fi
if [[ ! -d $LIBSVM_PYTHON_DIR ]]; then echo "LIBSVM PYTHON directory does not exist: $LIBSVM_PYTHON_DIR" >&2; exit 1; fi

if [[ ! $# -eq 3 ]]; then echo "Incorrect number of arguments passed to run_ease.sh; USAGE: $0 rundir query {protein|genome}" >&2; exit 1; fi
rundir=$1
query=$2
type=$3
if [[ $type != "protein" && $type != "genome" ]]; then echo "Incorrect arguments passed to run_ease.sh, specify either 'protein' or 'genome'; USAGE: $0 rundir query {protein|genome}" >&2; exit 1; fi
if [[ ! -f $query ]]; then echo "Query file does not exist: $query" >&2; exit 1; fi
if [[ ! -d $rundir ]]; then mkdir $rundir; fi
if [[ ! -d $rundir ]]; then echo "Directory does not exist and cannot be created: $rundir" >&2; exit 1; fi

sdir=$EASEMM_DIR/src
rundir=`readlink -f $rundir`
diff $rundir/$(basename $query) $query > /dev/null 2>&1
if [[ $? -ne 0 ]]; then cp $query $rundir; fi
#if [[ ! -f $rundir/$(basename $query) ]]; then cp $query $rundir; fi
query=$rundir/$(basename $query)
cd $rundir

if [[ $type == "protein" ]]; then
	#
	echo "Converting the user query to EASE-MM format..."
	python $sdir/easemm_input.py $query > $query.easemm
	if [[ ! $? -eq 0 ]]; then echo "Error encountered while parsing the query file, please check your inputs." >&2; exit 1; fi
	sort $query.easemm -o $query.easemm
	awk '{ print $3 }' $query.easemm | sort -u > $query.proteins
	protein_count=`grep . $query.proteins -c`
#	if [[ $protein_count -gt $MAX_PROTEINS ]]; then echo "The maximum number of proteins per job is $MAX_PROTEINS, please submit a smaller job or send us an e-mail." >&2; exit 1; fi
	echo "Converting the query to EASE-MM format... DONE!"
	
	#
	echo "Calculating predictive features (PSI-BLAST, SPIDER, SPINE-D)..."
	check_and_psiblast() {
	  seq_name="${1}"
	  n_threads="${2}"
    if [[ ! -f features/${seq_name}.pssm ]]
    then
      $BLAST_DIR/bin/blastpgp -d $BLAST_DB -i features/${seq_name}.fasta -e 0.001 -o features/${seq_name}.bla -a ${n_threads} -j 3 -Q features/${seq_name}.pssm
      gzip features/${seq_name}.bla -f
    else
      echo "Reusing features/${seq_name}.pssm (skipping PSI-BLAST)"
    fi
  }
  export -f check_and_psiblast
	if [[ ! -d features ]]; then mkdir features; fi
	mv *.fasta features/
	echo "Calculating PSI-BLAST..."
	cat $query.proteins | $parallel -j 1 check_and_psiblast {} $PARALLEL_JOBS > psiblast.log
	if [[ -f error.log ]]; then cat error.log >> psiblast.log; rm error.log; fi
	echo "Calculating SPIDER..."
	cat $query.proteins | $parallel -j $PARALLEL_JOBS python $SPIDER_DIR/run_pssm.py features/{}.pssm > spider.log
	cat $query.proteins | $parallel -j $PARALLEL_JOBS mv {}.spd3 features/
	echo "Calculating SPINE-D..."
	while read seq_id; do if [[ -d ${SPINED_DIR}/predout/$seq_id ]]; then rm -r ${SPINED_DIR}/predout/$seq_id; fi; done < $query.proteins
	cd features
	cat $query.proteins | $parallel -j $PARALLEL_JOBS ln -sf {}.pssm {}.mat
	cd ..
	cat $query.proteins | $parallel -j $PARALLEL_JOBS $SPINED_DIR/bin/run_spine-d features/ {} > spined.log 2> spined.err
	cat spined.err | grep "^Note: The following floating-point exceptions are signalling: IEEE_INVALID_FLAG$" -v
	cat $query.proteins | $parallel -j $PARALLEL_JOBS mv $SPINED_DIR/predout/{}.spd features/
	cat $query.proteins | $parallel -j $PARALLEL_JOBS rm -r $SPINED_DIR/predout/{}
	echo "Calculating predictive features (PSI-BLAST, SPIDER, SPINE-D)... DONE!"
else
	#
	echo "Converting VCF to EASE-MM format..."
	python $sdir/easemm_check_vcf.py $query "SNV" > $query.snv
	if [[ ! $? -eq 0 ]]; then echo "Error encountered while parsing the query file, please check your inputs." >&2; exit 1; fi
	vcf_count=`grep . $query.snv -c`
#	if [[ $vcf_count -gt $MAX_VCF ]]; then echo "The maximum number of SNVs per job is $MAX_VCF, please submit a smaller job or send us an e-mail." >&2; exit 1; fi
	$sdir/readgene_general $CCDS_DIR/CCDS.20131129.txt $CCDS_DIR/CCDS_nucleotide.20131129.fna $query.snv > $query.snv.ccds
	python $sdir/dna_to_protein.py $query.snv.ccds $CCDS_DIR/CCDS_nucleotide.20131129.fna $CCDS_DIR/CCDS_protein.20131129.faa $CCDS_DIR/CCDS.20131129.txt > $query.snv.ddig
	grep " MS$" $query.snv.ddig | sort -k2 > $query.snv.ddig.ms
	python $sdir/ddig_to_easemm.py $query.snv.ddig.ms > $query.mapping
	sort -u -k2,3 $query.mapping > $query.easemm
	awk '{ print $3 }' $query.easemm | sort -u > $query.proteins
	echo "Converting VCF to EASE-MM format... DONE!"
	
	#
	echo "Linking predictive features (FASTA, PSI-BLAST, SPIDER, SPINE-D)..."
	if [[ ! -d features ]]; then mkdir features; fi
	cat $query.proteins | $parallel -j $PARALLEL_JOBS ln -s $CCDS_DIR/fasta/{}.fasta features/
	cat $query.proteins | $parallel -j $PARALLEL_JOBS ln -s $CCDS_DIR/pssm/{}.pssm features/
	cat $query.proteins | $parallel -j $PARALLEL_JOBS ln -s $CCDS_DIR/spider/{}.spd3 features/
	cat $query.proteins | $parallel -j $PARALLEL_JOBS ln -s $CCDS_DIR/spineD/{}.spd features/
	echo "Linking  predictive features (FASTA, PSI-BLAST, SPIDER, SPINE-D)... DONE!"
fi

#
echo "Checking if all features were created successfully..."
check_and_die() {
  seq_name="${1}"
  if [[ ! -f features/${seq_name}.fasta || ! -f features/${seq_name}.pssm || ! -f features/${seq_name}.spd3 || ! -f features/${seq_name}.spd ]]
  then
    echo "ERROR: ${seq_name} missing some of the features, exiting..."
    kill -s TERM $MAIN_PID
  fi
}
export -f check_and_die
cat $query.proteins | $parallel -j $PARALLEL_JOBS check_and_die

#
echo "Predicting mutations with EASE-MM SVM models..."
export LIBSVM_PYTHON_DIR=$LIBSVM_PYTHON_DIR
export AAP_MATRIX=$EASEMM_DIR/data/aap11.scaled
export BLOSUM62=$EASEMM_DIR/data/blosum62.dat
python $sdir/easemm_predict.py $query.easemm $EASEMM_DIR/data/easemm_S1914.class.svm_model $EASEMM_DIR/data/easemm_S1914.real.svm_model > $query.results
echo "Predicting mutations with EASE-MM SVM models... DONE!"

#
echo "Preparing the output for the query..."
if [[ $type == "protein" ]]; then query_flag="$type $query"; else query_flag="$type $query.mapping"; fi
python $sdir/easemm_output.py $query.results $query_flag $OUTPUT_FORMAT --tab_output results.txt --spider_dir features > results_query.txt
echo "Preparing the output for the user query... DONE!"
echo "Exiting..."

