#!/usr/bin/env python
import sys, os, numpy
from sys import *
from math import *
""" Some general functions for PYTHON """

globs_yang = {}
def openfile(fn, action='r'):
	""" open one file and return file pointer. Supported include:
	".gz" for gzip files
	"--" for stdin/stdout
	"""
	if isinstance(fn, file): return fn
	if 'w' in action:
		if fn in ['--', 'STDOUT']: return stdout
	else:
		if fn in ['--', 'STDIN']: return stdin
		else:
			if not os.path.isfile(fn):
				print >>stderr, "no file: %s" % fn
			if fn.endswith('.gz'):
				import gzip
				return gzip.open(fn)
	return open(fn, action)
#
def rdlist(fn, ipos=0):
	""" read one file and return the first field as a list """
	list1 = []
	for x in openfile(fn):
		if x[ipos] == '#': continue
		ss = x.split()
		if len(ss) < 1: continue
		list1.append(ss[ipos])
	return list1
#
def rddict(fn, ipos=0):
	""" read one file and return a dict of first field/line """
	dict1 = {}
	for x in openfile(fn):
		if x[0] == '#': continue
		ss = x.split()
		if len(ss) <= ipos: continue
		if ss[ipos] in dict1:
			print >>stderr, 'duplicate key in 2 lines: ', ss[ipos]
			print >>stderr, x, dict1[ss[ipos]], '\n'
			continue
		dict1[ss[ipos]] = x.rstrip()
	return dict1
#
def die(info=""):
	"""  print info and exit """
	print >>stderr, info
	exit(1)
#
def backup_file(fn):
	if not os.path.isfile(fn): return
	os.rename(fn, fn+'~')
#
def rdelete(line, ext):
	""" return string by deleting 'ext' in the right """
	if line.endswith(ext):
		return line[:-len(ext)]
	return line
#
def list2str(l1, fmt1=""):
	if fmt1 == "":
		return ' '.join([str(x) for x in l1])
	else:
		return ''.join([fmt1 % x for x in l1])
def str_fold(line, ilen=80):
	return [line[x:x+ilen] for x in range(0, len(line), ilen)]
#
#
#
def readopt(args, opt1, nout=1):
	''' simple way to read opt '''
	if opt1 not in args: return -1
	return args.index(opt1)
