#!/usr/bin/env python

import os
import sys
import biodata
import EASE
import traceback

#TYPEs of partitioning
PRED_ASA = 1
PRED_SS = 2
QUICK_PARTITION = 5

#------------------------------------------------------------------------------
def partition_ASA_DSSP(fileName, PREFIX_1, PREFIX_2):
	countExp = 0
	countBur = 0
	
	aFile = open(fileName, 'r')
	partitionExp = open(fileName[:fileName.rfind('/')+1] + PREFIX_1 + fileName[fileName.rfind('/')+1:] , 'w')
	partitionBur = open(fileName[:fileName.rfind('/')+1] + PREFIX_2 + fileName[fileName.rfind('/')+1:], 'w')
	
	for line in aFile:
		lineSplit = line.split()
		pdb = lineSplit[0]
		mutationSite = int(lineSplit[1][1:-1])
		dsspFile = open('../../xEASE/dssp/'+pdb+'.dssp', "r")
		pdbChains = {'1OTR': 'B', '1RN1': 'C'}
		mainBody = False
		aaPdb = {}
		asaPdb = {}
		asaRealPdb = {}
		for lineDssp in dsspFile:
			if mainBody:
				if pdb in pdbChains:
					if lineDssp[11] != pdbChains[pdb]:
						continue
				aa = lineDssp[13]
				if aa.isalpha() and aa.islower():
					aa = 'C'
				if aa != '!':
					residue = int(lineDssp[5:10])
					asa = int(lineDssp[34:38]) 
					asaRealPdb[residue] = asa
					if aa in biodata.AA_VOLUME_ASA:
						asa = asa/float(biodata.AA_VOLUME_ASA)
					else:
						asa = -1.0
					asaClass = ''
					if asa < 0.25:
						asaClass = 'b'
					else:
						asaClass = 'e'
					aaPdb[residue] = aa
					asaPdb[residue] = asaClass
				elif lineDssp[14] == '*':
					#end of this chain
					break
				else:
					#skipping missing residues
					continue
			else:
				lineSplit = lineDssp.split()
				if lineSplit[1] == 'RESIDUE':
					mainBody = True
		dsspFile.close()

		if mutationSite not in asaPdb:
			print 'MANUAL INPUT REQUIRED ' + pdb + ' ' + str(mutationSite)
			countExp = countExp + 1
			partitionExp.write(line)
		else:
			if asaPdb[mutationSite] == 'e':
				countExp = countExp + 1
				partitionExp.write(line)
			else:
				countBur = countBur + 1
				partitionBur.write(line)
	
	aFile.close()
	partitionExp.close()
	partitionBur.close()
	return countExp, countBur

#------------------------------------------------------------------------------
def partition_SS(fileName, prefix_helix, prefix_sheet, prefix_coil, ignore_failure=False):
	countHelix, posCountHelix = 0, 0
	countSheet, posCountSheet = 0, 0
	countCoil, posCountCoil = 0, 0
	
	partitionHelix = open(fileName[:fileName.rfind('/')+1] + prefix_helix + fileName[fileName.rfind('/')+1:] , 'w')
	partitionSheet = open(fileName[:fileName.rfind('/')+1] + prefix_sheet + fileName[fileName.rfind('/')+1:], 'w')
	partitionCoil = open(fileName[:fileName.rfind('/')+1] + prefix_coil + fileName[fileName.rfind('/')+1:], 'w')
	
	with open(fileName, 'r') as f:
		for line in f:
			try:
				variant = biodata.VariantData(line.strip().split())
				spider_cache = biodata.parse_spider(variant.seq_id)
				biodata.check_seq_matrix(variant, spider_cache)
				if spider_cache[variant.position][biodata.AA] != variant.reference: raise ValueError
			except Exception as e:
				if not ignore_failure: raise e
				else:
					exc_type, exc_value, exc_traceback = sys.exc_info()
					print >> sys.stderr, traceback.format_exception(exc_type, exc_value, exc_traceback)
					continue
			
			if spider_cache[variant.position][biodata.SS] == 'H':
				countHelix = countHelix + 1
				if variant.disease == 1:
					posCountHelix += 1
				partitionHelix.write(line)
			elif spider_cache[variant.position][biodata.SS] == 'E':
				countSheet = countSheet + 1
				if variant.disease == 1:
					posCountSheet += 1
				partitionSheet.write(line)
			elif spider_cache[variant.position][biodata.SS] == 'C':
				countCoil = countCoil + 1
				if variant.disease == 1:
					posCountCoil+= 1
				partitionCoil.write(line)
			else:
				raise ValueError()
		
	partitionHelix.close()
	partitionSheet.close()
	partitionCoil.close()
	ratioHelix = round(posCountHelix/float(countHelix) if countHelix != 0 else 0, 3)
	ratioSheet = round(posCountSheet/float(countSheet) if countSheet != 0 else 0, 3)
	rationCoil = round(posCountCoil/float(countCoil) if countCoil != 0 else 0, 3)

	return countHelix, posCountHelix, ratioHelix, countSheet, posCountSheet, ratioSheet, countCoil, posCountCoil, rationCoil

#------------------------------------------------------------------------------
def partition_ASA(fileName, prefix_exp, prefix_bur, ignore_failure=False):
	countExp, posCountExp = 0, 0
	countBur, posCountBur = 0, 0
	
	partitionExp = open(fileName[:fileName.rfind('/')+1] + prefix_exp + fileName[fileName.rfind('/')+1:] , 'w')
	partitionBur = open(fileName[:fileName.rfind('/')+1] + prefix_bur + fileName[fileName.rfind('/')+1:], 'w')
	
	with open(fileName, 'r') as f:
		for line in f:
			try:
				variant = biodata.VariantData(line.strip().split())
				spider_cache = biodata.parse_spider(variant.seq_id)
				biodata.check_seq_matrix(variant, spider_cache)
				if spider_cache[variant.position][biodata.AA] != variant.reference: raise ValueError
				rASA = min(1.0, spider_cache[variant.position][biodata.ASA]/float(biodata.AA_VOLUME_ASA[variant.reference]))
				if rASA < 0.0 or rASA > 1.0: raise ValueError
			except Exception as e:
				if not ignore_failure: raise e
				else:
					exc_type, exc_value, exc_traceback = sys.exc_info()
					print >> sys.stderr, traceback.format_exception(exc_type, exc_value, exc_traceback)
					continue
				
			if rASA > 0.25:
				countExp = countExp + 1
				if variant.disease == 1:
					posCountExp += 1
				partitionExp.write(line)
			else:
				countBur = countBur + 1
				if variant.disease == 1:
					posCountBur += 1
				partitionBur.write(line)
	
	partitionExp.close()
	partitionBur.close()
	
	ratioExp = round(posCountExp/float(countExp) if countExp != 0 else 0, 3)
	ratioBur = round(posCountBur/float(countBur) if countBur != 0 else 0, 3)

	return countExp, posCountExp, ratioExp, countBur, posCountBur, ratioBur

#------------------------------------------------------------------------------		
def partition_all(REPLICATION_NUMBER, NUM_FOLDS_IN_THIS_REP, DATA_SET, DATA_DIR, TYPE):
	files = []
	file_prefix = os.path.join(DATA_DIR, 'replication' + str(REPLICATION_NUMBER), DATA_SET + '.rep' + str(REPLICATION_NUMBER))
	for k in range(1,NUM_FOLDS_IN_THIS_REP+1):
		fold = file_prefix + '.fold' + str(k)
		testfold = fold + '.testFold'
		trainfolds = fold + '.trainFolds'
		files.append(fold)
		files.append(testfold)
		files.append(trainfolds)
	
	for fileName in files:
		if TYPE == PRED_ASA:
			countExp, posCountExp, ratioExp, countBur, posCountBur, ratioBur = partition_ASA(fileName, EASE.EXP + '.', EASE.BUR + '.')
			if ratioExp < 0.1: print 'WARNING:', ratioExp
			if ratioBur < 0.1: print 'WARNING:', ratioBur
			print countExp, '(', posCountExp, ')', ratioExp
			print countBur, '(', posCountBur, ')', ratioBur
		elif TYPE == PRED_SS:
			countHelix, posCountHelix, ratioHelix, countSheet, posCountSheet, ratioSheet, countCoil, posCountCoil, rationCoil = partition_SS(fileName, EASE.HELIX + '.', EASE.SHEET+ '.', EASE.COIL+ '.')
			if ratioHelix < 0.1: print 'WARNING:', ratioHelix
			if ratioSheet < 0.1: print 'WARNING:', ratioSheet
			if rationCoil < 0.1: print 'WARNING:', rationCoil
			print countHelix, '(', posCountHelix, ')', ratioHelix
			print countSheet, '(', posCountSheet, ')', ratioSheet
			print countCoil, '(', posCountCoil, ')', rationCoil
		else:
			print "ERROR: undefined partitioning"
		
#------------------------------------------------------------------------------
def main():
	CURRENT_PATH = './'
	
	if len(sys.argv) < 5:
		print >> sys.stderr, "USAGE: partitionDataSets.py NUM_REPLICATIONS DATA_SET DATA_DIR TYPE:{1: ASA, 2: SS, 5: QUICK_PARTITION}"
		sys.exit()
	
	NUM_REPLICATIONS = int(sys.argv[1])
	DATA_SET = sys.argv[2]
	DATA_DIR = CURRENT_PATH + sys.argv[3] + '/'
	TYPE  = int(sys.argv[4])

	NUM_FOLDS=10
		
	if TYPE == QUICK_PARTITION:
		countExp, posCountExp, ratioExp, countBur, posCountBur, ratioBur = partition_ASA(DATA_SET, EASE.EXP + '.', EASE.BUR + '.')
		if ratioExp < 0.1: print 'WARNING:', ratioExp
		if ratioBur < 0.1: print 'WARNING:', ratioBur
		print countExp, '(', posCountExp, ')', ratioExp
		print countBur, '(', posCountBur, ')', ratioBur
		countHelix, posCountHelix, ratioHelix, countSheet, posCountSheet, ratioSheet, countCoil, posCountCoil, rationCoil = partition_SS(DATA_SET, EASE.HELIX + '.', EASE.SHEET+ '.', EASE.COIL+ '.')
		if ratioHelix < 0.1: print 'WARNING:', ratioHelix
		if ratioSheet < 0.1: print 'WARNING:', ratioSheet
		if rationCoil < 0.1: print 'WARNING:', rationCoil
		print countHelix, '(', posCountHelix, ')', ratioHelix
		print countSheet, '(', posCountSheet, ')', ratioSheet
		print countCoil, '(', posCountCoil, ')', rationCoil
		sys.exit()
	else:
		for REPLICATION_NUMBER in range(1,NUM_REPLICATIONS+1):
			partition_all(REPLICATION_NUMBER, NUM_FOLDS, DATA_SET, DATA_DIR, TYPE)
			
#------------------------------------------------------------------------------

if __name__ == "__main__":
	main()
