#!/usr/bin/env python

import sys
import biodata
import traceback
import collections

DEBUG = False
SEQ = 'SEQ:'
MUT = 'MUT:'

def main ():
	if len(sys.argv) != 2:
		print >> sys.stderr, 'USAGE: python easemm_input.py query_filename'
		sys.exit(1)
		
	query_filename = sys.argv[1]	
	try:
		seq_lines, mut_lines = read_seq_mut_from_query(query_filename)
	except EaseFormatError as e:
		e.print_error()
		sys.exit(1)
		
	mutations = collections.OrderedDict({})
	names, sequences = {}, {}
	error = []
	for i in range(len(seq_lines)):
		name, sequence, line_number = seq_lines[i]		
		try:
			check_sequence(sequence, line_number)
		except EaseFormatError as e:
			error.append(e.message)		
		try:
			check_already_read_sequences(name, sequence, line_number, names, sequences)
		except EaseFormatError as e:
			error.append(e.message)
		
		if sequence not in mutations:
			mutations[sequence] = []
			names[sequence] = name
			sequences[name] = sequence
		
		mut_values, line_number = mut_lines[i]
		for mutation in mut_values:
			try:
				if '*' not in mutation: check_mutation(mutation, sequence, line_number)
				else: check_wildcard_mutation(mutation, sequence, line_number)
				for m in expand_wild_card_mutation(mutation, sequence):
					if m not in mutations[sequence]:
						mutations[sequence].append(m)
			except EaseFormatError as e:
				error.append(e.message)	
	
	if len(error) != 0:
		print >> sys.stderr, '\n'.join(error)
		sys.exit(1)
	
	for seq in mutations:
		with open(names[seq] + '.fasta', 'w') as f:
			print >> f, '>' + names[seq]
			print >> f, seq
		for m in mutations[seq]:
			print names[seq], m, names[seq], 0.0, 0.0, 0.0, -1, 'DDG'
			
class EaseFormatError(Exception):
	def __init__(self, message, line_number=None):
		super(EaseFormatError, self).__init__(('ERROR' if line_number is None else ('ERROR at line ' + str(line_number))) + ': ' + message)
		self.line_number = line_number
	
	def print_error(self):
		print >> sys.stderr, self.message
		
def read_seq_mut_from_query(query_filename):
	with open(query_filename, 'r') as f:
		first = True
		line_number = 0
		seq_lines, mut_lines = [], []
		for line in f:
			line_number += 1
			if len(line.strip()) == 0 or line[0] == '#': continue
			line_split = line.strip().split()
			if len(line_split) < 2:
				raise EaseFormatError('Each line needs to take the following format \'HEADER: value(s)\'', line_number)
			if first:
				if line_split[0] != SEQ or len(line_split) != 3:
					raise EaseFormatError('The format is \'SEQ: unique_name sequence\'', line_number)
				seq_lines.append((line_split[1], line_split[2].upper(), line_number))
				first = False
			else:
				if line_split[0] != MUT:
					raise EaseFormatError('The format is \'MUT: XnY XnY ...\'', line_number)
				mut_lines.append((map(lambda x: x.upper(), line_split[1:]), line_number))
				first = True
				
	if len(seq_lines) != len(mut_lines):
		raise EaseFormatError('There was a different number of SEQ: and MUT: lines')
	
	return seq_lines, mut_lines

def check_already_read_sequences(name, sequence, line_number, names, sequences):
	if sequence in names and name != names[sequence]:
		raise EaseFormatError('The same sequence with two different names: ' + name + ' ' + names[sequence], line_number)
	if name in sequences and sequence != sequences[name]:
		raise EaseFormatError('Two different sequences with the same name: ' + name, line_number)
	
def check_sequence(sequence, line_number):
	for aa in sequence:
		if aa not in biodata.AMINO_ACIDS:
			raise EaseFormatError('A non-standard amino acid in the sequence: ' + aa, line_number)
				
def check_mutation(mutation, sequence, line_number):
	if len(mutation) < 3:
		raise EaseFormatError('An incorrect format of the mutation ("XnY"): ' + mutation, line_number)
	check_mutation_reference(mutation, sequence, line_number)
	check_mutation_mutated(mutation, sequence, line_number)

def check_wildcard_mutation(mutation, sequence, line_number):
	incorrect_format_msg = 'An incorrect format of a wildcard mutation ("Xn*", "*Y", or "**"): ' + mutation
	if mutation.count('*') > 2 or len(mutation) < 2:
		raise EaseFormatError(incorrect_format_msg, line_number)
	elif mutation.count('*') == 2:
		if mutation != '**':
			raise EaseFormatError(incorrect_format_msg, line_number)
	elif mutation[-1] == '*':
		check_mutation_reference(mutation, sequence, line_number)
	elif mutation[0] == '*':
		if len(mutation) != 2:
			raise EaseFormatError(incorrect_format_msg, line_number)
		check_mutation_mutated(mutation, sequence, line_number)
	else:
		raise EaseFormatError(incorrect_format_msg, line_number)
	
def check_mutation_reference(mutation, sequence, line_number):
	ref = mutation[0]
	if ref not in biodata.AMINO_ACIDS:
		raise EaseFormatError('A non-standard amino acid as the reference residue: ' + ref, line_number)
	try:
		position = int(mutation[1:-1])
	except Exception:
		raise EaseFormatError('A non-integer mutation position specified: ' + mutation, line_number)
	if len(sequence) < position:
		raise EaseFormatError('The specified sequence is too short for the specified mutation: ' + mutation, line_number)
	if sequence[position-1] != ref:
		raise EaseFormatError('The sequence does not match the specified reference amino acid: ' + mutation, line_number)

def check_mutation_mutated(mutation, sequence, line_number):
	mut = mutation[-1]
	if mut not in biodata.AMINO_ACIDS:
		raise EaseFormatError('A non-standard amino acid as the mutated residue: ' + mut, line_number)

def expand_wild_card_mutation(mutation, sequence):
	if '*' not in mutation: return [mutation]
	elif mutation == '**': return [ref + str(pos + 1) + mut for pos, ref in enumerate(sequence) for mut in biodata.AMINO_ACIDS.replace(ref, '')]
	elif mutation[-1] == '*': return [mutation[:-1] + mut for mut in biodata.AMINO_ACIDS.replace(mutation[0], '')]
	elif mutation[0] == '*': return filter(lambda m: m[0] != m[-1], [ref + str(pos + 1) + mutation[-1] for pos, ref in enumerate(sequence)])

if __name__ == "__main__":
	main()
