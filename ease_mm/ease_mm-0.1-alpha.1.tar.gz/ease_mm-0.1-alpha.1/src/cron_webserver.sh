#!/bin/bash

lock=~/lock.run
[ -f $lock ] && exit
touch $lock
PATH=$PATH:/home/lukas/bin

#EASE-MM web-server
echo 'EASE' > $lock
sdir=~/EASE/server/src
$sdir/scanweb.py >> $sdir/error.log 2>&1
rm -f $lock

