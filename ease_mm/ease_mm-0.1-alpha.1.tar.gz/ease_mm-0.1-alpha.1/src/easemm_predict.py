#!/usr/bin/env python

import sys
import biodata
import features
import partitionDataSets
import EASE
import os
LIBSVM_PYTHON_DIR = os.environ.get('LIBSVM_PYTHON_DIR')
if LIBSVM_PYTHON_DIR is not None: sys.path.insert(1, LIBSVM_PYTHON_DIR)
import svmutil

EASE_ASA_MODELS = [EASE.EXP, EASE.BUR]
EASE_SS_MODELS = [EASE.HELIX, EASE.SHEET, EASE.COIL]
EASE_MM_MODELS = EASE_ASA_MODELS + EASE_SS_MODELS

def get_prefixed_dataset(prefix, filename):
	return filename[:filename.rfind('/')+1] + prefix + filename[filename.rfind('/')+1:]

def svm_save_problem(filename, labels, data):
	with open(filename, 'w') as f:
		for i in range(len(labels)):
			print >> f, labels[i], ' '.join([str(j+1) + ':' + str(data[i][j]) for j in range(len(data[i]))])		

def predict_mutations_with_one_model(model, query_fn, easemm_model_class_filename, easemm_model_real_filename):
	preditions = {}
	model_query_fn = get_prefixed_dataset(model + '.', query_fn)
	if len(biodata.stripped_lines(model_query_fn)) > 0:
		svm_model_class = svmutil.svm_load_model(get_prefixed_dataset(model + '.', easemm_model_class_filename))
		svm_model_real = svmutil.svm_load_model(get_prefixed_dataset(model + '.', easemm_model_real_filename))
		queries_class, labels_class, data_class = biodata.calculate_features(model_query_fn, features.FeatureSet(EASE.FEATURES_CLASS[model]), biodata.label_method(True), ignore_failure=True)
		queries_real, labels_real, data_real = biodata.calculate_features(model_query_fn, features.FeatureSet(EASE.FEATURES_REG[model]), biodata.label_method(False), ignore_failure=True)

		if len(queries_class) > 0:
			svm_save_problem(model_query_fn + '.class.svm', labels_class, data_class)
			predicted_labels_class, (acc_class, mse_class, r2_class), prediction_values_raw_class, _ = svmutil.svm_predict(labels_class, data_class, svm_model_class, '-b 1 -q')
			for i in range(len(queries_class)):
				variant = biodata.VariantData(queries_class[i].strip().split())
				if biodata.label_method(True)(variant) != labels_class[i]:
					print >> sys.stderr, 'ERROR: query and label do not match', queries_class[i], labels_class[i]
					raise ValueError
				if variant.seq_id not in preditions: preditions[variant.seq_id] = {}
				if variant.ddg_mutation_info() in preditions[variant.seq_id]:
					print >> sys.stderr, 'ERROR: duplicate mutations predicted', variant.ddg_mutation_info()
					raise ValueError
				preditions[variant.seq_id][variant.ddg_mutation_info()] = (prediction_values_raw_class[i][0], None)
		
		if len(queries_real) > 0:
			svm_save_problem(model_query_fn + '.real.svm', labels_real, data_real)
			predicted_labels_real, (acc_real, mse_real, r2_real), prediction_values_raw_real, _ = svmutil.svm_predict(labels_real, data_real, svm_model_real, '-q')
			for i in range(len(queries_real)):
				variant = biodata.VariantData(queries_real[i].strip().split())
				if biodata.label_method(False)(variant) != labels_real[i]:
					print >> sys.stderr, 'ERROR: query and label do not match', queries_real[i], labels_real[i]
					raise ValueError
				if variant.seq_id not in preditions: preditions[variant.seq_id] = {}
				if variant.ddg_mutation_info() in preditions[variant.seq_id]:
					prediction = preditions[variant.seq_id][variant.ddg_mutation_info()]
					if prediction[1] is not None:
						print >> sys.stderr, 'ERROR: duplicate mutations predicted', variant.ddg_mutation_info()
						raise ValueError
					else:
						preditions[variant.seq_id][variant.ddg_mutation_info()] = (prediction[0], predicted_labels_real[i])
				else:
					preditions[variant.seq_id][variant.ddg_mutation_info()] = (None, predicted_labels_real[i])
	return preditions

def add_predictions(container, predictions, container_type):
	for s in predictions:
		if s not in container: container[s] = {}
		for m in predictions[s]:
			if m in container[s]:
				print >> sys.stderr, 'ERROR: duplicate mutations predicted after merging models', container_type, m
				raise ValueError
			container[s][m] = predictions[s][m]

def main():
	if len(sys.argv) != 4: print >> sys.stderr, 'USAGE: python easemm_predict.py query_filename svm_model_class svm_model_real libsvm_python_dir'; sys.exit(1)
	query_fn = sys.argv[1]
	easemm_model_class_filename = sys.argv[2]
	easemm_model_real_filename = sys.argv[3]
	
	partitionDataSets.partition_ASA(query_fn, EASE.EXP + '.', EASE.BUR + '.', ignore_failure=True)
	partitionDataSets.partition_SS(query_fn, EASE.HELIX + '.', EASE.SHEET + '.', EASE.COIL + '.', ignore_failure=True)
	
	ease_asa_predictions = {}
	ease_ss_predictions = {}
	for model in EASE_MM_MODELS:
		predictions = predict_mutations_with_one_model(model, query_fn, easemm_model_class_filename, easemm_model_real_filename)
		if model in EASE_ASA_MODELS:
			add_predictions(ease_asa_predictions, predictions, 'EASE-ASA')
		elif model in EASE_SS_MODELS:
			add_predictions(ease_ss_predictions, predictions, 'EASE-SS')
		else:
			print >> sys.stderr, 'ERROR: incorrectly defined models', model
			raise ValueError
	
	predictions = {}
	with open(query_fn, 'r') as f, open(query_fn + '.ease_asa.predictions', 'w') as fasa, open(query_fn + '.ease_ss.predictions', 'w') as fss:
		for line in f:
			v = biodata.VariantData(line.strip().split())
			if v.seq_id not in ease_asa_predictions or v.ddg_mutation_info() not in ease_asa_predictions[v.seq_id]:
				continue
			if v.seq_id not in ease_ss_predictions or v.ddg_mutation_info() not in ease_ss_predictions[v.seq_id]:
				continue
			ease_asa = ease_asa_predictions[v.seq_id][v.ddg_mutation_info()]
			ease_ss = ease_ss_predictions[v.seq_id][v.ddg_mutation_info()]
			print >> fasa, line.strip('\n'), ease_asa[0], ease_asa[1]
			print >> fss, line.strip('\n'), ease_ss[0], ease_ss[1]
			if v.seq_id not in predictions: predictions[v.seq_id] = {}
			ease_mm_class = float(ease_asa[0] + ease_ss[0])/2.0 if ease_asa[0] is not None and ease_ss[0] is not None else None
			ease_mm_real = float(ease_asa[1] + ease_ss[1])/2.0 if ease_asa[1] is not None and ease_ss[1] is not None else None
			predictions[v.seq_id][v.ddg_mutation_info()] = (ease_mm_class, ease_mm_real)
	
	print '#seq_id mutation real_value_ddg stability_class_raw_probability'
	for s in predictions:
		for m in predictions[s]:
			print s, m, predictions[s][m][1], predictions[s][m][0]
			
if __name__ == "__main__":
	main()
