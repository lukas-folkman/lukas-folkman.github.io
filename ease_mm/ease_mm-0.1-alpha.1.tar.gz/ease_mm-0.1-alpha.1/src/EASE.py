#!/usr/bin/env python


EASE_MM = 'EASE-MM'
EASE_SS = 'EASE-SS'
EASE_ASA = 'EASE-ASA'

EXP = 'exp'
BUR = 'bur'
HELIX = 'helix'
SHEET = 'sheet'
COIL = 'coil'

SVM_C_REG = {EXP: 32.0, BUR: 32.0, HELIX: 32.0, SHEET: 8.0, COIL: 8.0}
SVM_G_REG = {EXP: 0.0625, BUR: 0.015625, HELIX: 0.0625, SHEET: 0.015625, COIL: 0.0625}
SVM_W_REG = {EXP: 0.015625, BUR: 0.00390625, HELIX: 0.0625, SHEET: 0.00390625, COIL: 0.015625}

SVM_C_CLASS = {EXP: 8.0, BUR: 32.0, HELIX: 32.0, SHEET: 0.5, COIL: 2.0}
SVM_G_CLASS = {EXP: 0.125, BUR: 0.0078125, HELIX: 0.125, SHEET: 0.0078125, COIL: 0.125}
SVM_W_CLASS = {EXP: 1.5, BUR: 2, HELIX: 1, SHEET: 2.5, COIL: 2.5}

LARGE_GRID_SVM_C_CLASS = {EXP: 8.0, BUR: 32.0, HELIX: 128.0, SHEET: 0.5, COIL: 2.0}
LARGE_GRID_SVM_G_CLASS = {EXP: 0.125, BUR: 0.0078125, HELIX: 0.125, SHEET: 0.0078125, COIL: 0.125}
LARGE_GRID_SVM_W_CLASS = {EXP: 1.5, BUR: 2, HELIX: 1, SHEET: 2.5, COIL: 2.5}

LARGE_GRID_SVM_C_REG = {EXP: 16.0, BUR: 32.0, HELIX: 64.0, SHEET: 8.0, COIL: 32.0}
LARGE_GRID_SVM_G_REG = {EXP: 0.0625, BUR: 0.015625, HELIX: 0.0625, SHEET: 0.015625, COIL: 0.03125}
LARGE_GRID_SVM_P_REG = {EXP: 0.00390625, BUR: 0.03125, HELIX: 0.00390625, SHEET: 0.00390625, COIL: 0.00390625}

#OPTIMISED FOR S1210
#LARGE_GRID_SVM_C_REG = {EXP: 0.5,  BUR: 16.0,       HELIX: 2.0,        SHEET: 64.0,       COIL: 32.0}
#LARGE_GRID_SVM_G_REG = {EXP: 0.25, BUR: 0.00390625, HELIX: 0.125,      SHEET: 0.00390625, COIL: 0.0625}
#LARGE_GRID_SVM_P_REG = {EXP: 0.5,  BUR: 0.015625,   HELIX: 0.00390625, SHEET: 0.5,        COIL: 0.0078125}

FEATURES_REG = {
			EXP: '8031_w_5_wl_0-7031_w_5_wl_0-61_w_5_wl_0-81_w_5_wl_0-51_w_5_wl_0-10031_w_5_wl_0-1031_w_5_wl_0-811_w_5_wl_0', 
			BUR: '4031_w_5_wl_0-831_w_5_wl_0-9031_w_5_wl_0-51_w_5_wl_0-7031_w_5_wl_0-1031_w_5_wl_0-6031_w_5_wl_0-11031_w_5_wl_0', 
			HELIX: '4031_w_5_wl_0-51_w_5_wl_0-2031_w_5_wl_0-10031_w_5_wl_0-9031_w_5_wl_0-7031_w_5_wl_0-81_w_5_wl_0-71_w_5_wl_0', 
			SHEET: '4031_w_5_wl_0-831_w_5_wl_0-61_w_5_wl_0-2031_w_5_wl_0-8031_w_5_wl_0-7031_w_5_wl_0-10031_w_5_wl_0-71_w_5_wl_0-5031_w_5_wl_0-21_w_5_wl_0', 
			COIL: '6031_w_5_wl_0-8031_w_5_wl_0-831_w_5_wl_0-1031_w_5_wl_0-51_w_5_wl_0-61_w_5_wl_0-7031_w_5_wl_0-811_w_5_wl_0-71_w_5_wl_0'
			}

FEATURES_CLASS = {
			EXP: '71_w_5_wl_0-10031_w_5_wl_0-5031_w_5_wl_0-81_w_5_wl_0-11031_w_5_wl_0-51_w_5_wl_0-1031_w_5_wl_0-21_w_5_wl_0-831_w_5_wl_0-2031_w_5_wl_0', 
			BUR: '4031_w_5_wl_0-9031_w_5_wl_0-831_w_5_wl_0-51_w_5_wl_0', 
			HELIX: '10031_w_5_wl_0-51_w_5_wl_0-9031_w_5_wl_0-7031_w_5_wl_0-81_w_5_wl_0-1031_w_5_wl_0-21_w_5_wl_0-3031_w_5_wl_0-71_w_5_wl_0', 
			SHEET: '11031_w_5_wl_0-1031_w_5_wl_0-831_w_5_wl_0-7031_w_5_wl_0-4031_w_5_wl_0-811_w_5_wl_0-51_w_5_wl_0', 
			COIL: '5031_w_5_wl_0-8031_w_5_wl_0-11031_w_5_wl_0-61_w_5_wl_0-9031_w_5_wl_0-831_w_5_wl_0-1031_w_5_wl_0-811_w_5_wl_0'
			}

def get_exp_svm_params(is_classification, large_grid=False):
	if is_classification:
		if large_grid:
			print 'Using LARGE grid SVM parameters!!!'
			return LARGE_GRID_SVM_C_CLASS[EXP], LARGE_GRID_SVM_G_CLASS[EXP], LARGE_GRID_SVM_W_CLASS[EXP] 
		else:
			print 'Using SMALL grid SVM parameters!!!'
			return SVM_C_CLASS[EXP], SVM_G_CLASS[EXP], SVM_W_CLASS[EXP] 
	else:
		if large_grid:
			print 'Using LARGE grid SVM parameters!!!'
			return LARGE_GRID_SVM_C_REG[EXP], LARGE_GRID_SVM_G_REG[EXP], LARGE_GRID_SVM_P_REG[EXP] 
		else:
			print 'Using SMALL grid SVM parameters!!!'
			return SVM_C_REG[EXP], SVM_G_REG[EXP], SVM_W_REG[EXP] 
	
def get_bur_svm_params(is_classification, large_grid=False):
	if is_classification:
		if large_grid:
			print 'Using LARGE grid SVM parameters!!!'
			return LARGE_GRID_SVM_C_CLASS[BUR], LARGE_GRID_SVM_G_CLASS[BUR], LARGE_GRID_SVM_W_CLASS[BUR] 
		else:
			print 'Using SMALL grid SVM parameters!!!'
			return SVM_C_CLASS[BUR], SVM_G_CLASS[BUR], SVM_W_CLASS[BUR] 
	else:
		if large_grid:
			print 'Using LARGE grid SVM parameters!!!'
			return LARGE_GRID_SVM_C_REG[BUR], LARGE_GRID_SVM_G_REG[BUR], LARGE_GRID_SVM_P_REG[BUR] 
		else:
			print 'Using SMALL grid SVM parameters!!!'
			return SVM_C_REG[BUR], SVM_G_REG[BUR], SVM_W_REG[BUR] 
	
def get_helix_svm_params(is_classification, large_grid=False):
	if is_classification:
		if large_grid:
			print 'Using LARGE grid SVM parameters!!!'
			return LARGE_GRID_SVM_C_CLASS[HELIX], LARGE_GRID_SVM_G_CLASS[HELIX], LARGE_GRID_SVM_W_CLASS[HELIX] 
		else:
			print 'Using SMALL grid SVM parameters!!!'
			return SVM_C_CLASS[HELIX], SVM_G_CLASS[HELIX], SVM_W_CLASS[HELIX] 
	else:
		if large_grid:
			print 'Using LARGE grid SVM parameters!!!'
			return LARGE_GRID_SVM_C_REG[HELIX], LARGE_GRID_SVM_G_REG[HELIX], LARGE_GRID_SVM_P_REG[HELIX] 
		else:
			print 'Using SMALL grid SVM parameters!!!'
			return SVM_C_REG[HELIX], SVM_G_REG[HELIX], SVM_W_REG[HELIX] 

def get_sheet_svm_params(is_classification, large_grid=False):
	if is_classification:
		if large_grid:
			print 'Using LARGE grid SVM parameters!!!'
			return LARGE_GRID_SVM_C_CLASS[SHEET], LARGE_GRID_SVM_G_CLASS[SHEET], LARGE_GRID_SVM_W_CLASS[SHEET] 
		else:
			print 'Using SMALL grid SVM parameters!!!'
			return SVM_C_CLASS[SHEET], SVM_G_CLASS[SHEET], SVM_W_CLASS[SHEET] 
	else:
		if large_grid:
			print 'Using LARGE grid SVM parameters!!!'
			return LARGE_GRID_SVM_C_REG[SHEET], LARGE_GRID_SVM_G_REG[SHEET], LARGE_GRID_SVM_P_REG[SHEET] 
		else:
			print 'Using SMALL grid SVM parameters!!!'
			return SVM_C_REG[SHEET], SVM_G_REG[SHEET], SVM_W_REG[SHEET] 
	
def get_coil_svm_params(is_classification, large_grid=False):
	if is_classification:
		if large_grid:
			print 'Using LARGE grid SVM parameters!!!'
			return LARGE_GRID_SVM_C_CLASS[COIL], LARGE_GRID_SVM_G_CLASS[COIL], LARGE_GRID_SVM_W_CLASS[COIL] 
		else:
			print 'Using SMALL grid SVM parameters!!!'
			return SVM_C_CLASS[COIL], SVM_G_CLASS[COIL], SVM_W_CLASS[COIL] 
	else:
		if large_grid:
			print 'Using LARGE grid SVM parameters!!!'
			return LARGE_GRID_SVM_C_REG[COIL], LARGE_GRID_SVM_G_REG[COIL], LARGE_GRID_SVM_P_REG[COIL] 
		else:
			print 'Using SMALL grid SVM parameters!!!'
			return SVM_C_REG[COIL], SVM_G_REG[COIL], SVM_W_REG[COIL] 
	
def get_exp_features(is_classification):
	if is_classification:
		return FEATURES_CLASS[EXP]
	else:
		return FEATURES_REG[EXP]
	
def get_bur_features(is_classification):
	if is_classification:
		return FEATURES_CLASS[BUR]
	else:
		return FEATURES_REG[BUR]
	
def get_helix_features(is_classification):
	if is_classification:
		return FEATURES_CLASS[HELIX]
	else:
		return FEATURES_REG[HELIX]
	
def get_sheet_features(is_classification):
	if is_classification:
		return FEATURES_CLASS[SHEET]
	else:
		return FEATURES_REG[SHEET]
	
def get_coil_features(is_classification):
	if is_classification:
		return FEATURES_CLASS[COIL]
	else:
		return FEATURES_REG[COIL]