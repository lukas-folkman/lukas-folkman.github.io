#!/usr/bin/env python

import sys

def main():
	if len(sys.argv) != 2: print >> sys.stderr, 'USAGE: python filter_fs_ns.py query_filename'; sys.exit(1)
	query_fn = sys.argv[1]
	with open(query_fn, 'r') as f:
		for line in f:
			line_split = line.strip().split()
			if line_split[-1] in ['FS', 'NS']:
				print line.strip()
			elif line_split[-1].startswith('NFS'):
				continue
			else:
				print >> sys.stderr, 'ERROR: NOT SUPPORTED', line.strip()
				continue
		
if __name__ == "__main__":
	main()
