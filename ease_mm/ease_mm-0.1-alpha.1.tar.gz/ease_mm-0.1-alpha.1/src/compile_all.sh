current_dir=$PWD

if [[ ! -f ${LIBSVM_PYTHON_DIR}/../svm.o ]]
then
  echo "Compiling LIBSVM..."
  cd ${LIBSVM_PYTHON_DIR}/..
  make clean
  make
fi

if [[ ! -f ${LIBSVM_PYTHON_DIR}/../libsvm.so.2 ]]
then
  echo "Compiling Python bindings for LIBSVM..."
  cd ${LIBSVM_PYTHON_DIR}
  make
fi

if [[ ! -f ${SPINEX_DIR}/phipsi_dssp.e || ! -f ${SPINEX_DIR}/bin/phipsi_ss0.e || ! -f ${SPINEX_DIR}/bin/phipsi_rsa.e || ! -f ${SPINEX_DIR}/bin/phipsi_phipsi0.e || ! -f ${SPINEX_DIR}/bin/phipsi_ss1.e || ! -f ${SPINEX_DIR}/bin/phipsi_phipsi1.e ]]
then
  echo "Compiling SPINE-X..."
  which gfortran
  cd ${SPINEX_DIR}/code
  ./compile
fi

if [[ ! -f ${SPINED_DIR}/data/davar/binary/dphi/spiner_test.e || ! -f ${SPINED_DIR}/data/davar/binary/dpsi/spiner_test.e || ! -f ${SPINED_DIR}/data/spd/forcasp9/spiner_pred.e ]]
then
  echo "Compiling SPINE-D..."
  which gfortran
  cd ${SPINED_DIR}/data/davar/binary/dphi
  gfortran -ffixed-line-length-none -O2 -o spiner_test.e spiner_test.f
  cd ${SPINED_DIR}/data/davar/binary/dpsi
  gfortran -ffixed-line-length-none -O2 -o spiner_test.e spiner_test.f
  cd ${SPINED_DIR}/data/spd/forcasp9
  gfortran -ffixed-line-length-none -O2 -o spiner_pred.e spiner_pred.f
fi

cd ${current_dir}
