#!/usr/bin/env python

import sys
import biodata
import EASE
import svmutil
import easemm_predict
import features

def main():
	if len(sys.argv) != 4: print >> sys.stderr, 'USAGE: python easemm_train.py training_dataset svm_model_class svm_model_real'; sys.exit(1)
	training_dataset = sys.argv[1]
	easemm_model_class_filename = sys.argv[2]
	easemm_model_real_filename = sys.argv[3]
	
	queries_class_len, queries_real_len = 0, 0
	for model in easemm_predict.EASE_MM_MODELS:
		model_training_dataset = easemm_predict.get_prefixed_dataset(model + '.', training_dataset)
		queries_class, labels_class, data_class = biodata.calculate_features(model_training_dataset, features.FeatureSet(EASE.FEATURES_CLASS[model]), biodata.label_method(True))
		if len(queries_class) != len(biodata.stripped_lines(model_training_dataset)): raise ValueError
		queries_class_len += len(queries_class)
		queries_real, labels_real, data_real = biodata.calculate_features(model_training_dataset, features.FeatureSet(EASE.FEATURES_REG[model]), biodata.label_method(False))
		if len(queries_real) != len(biodata.stripped_lines(model_training_dataset)): raise ValueError
		queries_real_len += len(queries_real)

		easemm_predict.svm_save_problem(model_training_dataset + '.class.svm', labels_class, data_class)
		svm_params_class = ['-s', '0', '-t', '2', '-c', str(EASE.LARGE_GRID_SVM_C_CLASS[model]), '-g', str(EASE.LARGE_GRID_SVM_G_CLASS[model]), '-w1', str(EASE.LARGE_GRID_SVM_W_CLASS[model]), '-b', '1', '-q']
		model_class = svmutil.svm_train(labels_class, data_class, ' '.join(svm_params_class))	
		svmutil.svm_save_model(easemm_predict.get_prefixed_dataset(model + '.', easemm_model_class_filename), model_class)
		
		easemm_predict.svm_save_problem(model_training_dataset + '.real.svm', labels_real, data_real)
		svm_params_real = ['-s', '3', '-t', '2', '-c', str(EASE.LARGE_GRID_SVM_C_REG[model]), '-g', str(EASE.LARGE_GRID_SVM_G_REG[model]), '-p', str(EASE.LARGE_GRID_SVM_P_REG[model]), '-q']
		model_real = svmutil.svm_train(labels_real, data_real, ' '.join(svm_params_real))	
		svmutil.svm_save_model(easemm_predict.get_prefixed_dataset(model + '.', easemm_model_real_filename), model_real)

	if queries_class_len != queries_real_len or queries_real_len != len(biodata.stripped_lines(training_dataset)) * 2: raise ValueError
	
if __name__ == "__main__":
	main()
