#!/usr/bin/env python
from misc_yang import *

sourcedir = os.path.expanduser('~/EASE/server/src')
prog = os.path.join(sourcedir, 'run_ease.sh')
serverdir = os.path.expanduser('~/public_html/server/ease/')
fqueue = os.path.join(serverdir, 'log', '_queue.dat')
fhistory = os.path.join(serverdir, 'log', '_queue.his')
lockqueue = os.path.join(serverdir, 'log', 'lockqueue')
locknotice = os.path.join(serverdir, 'log', 'locknotice')
lockrun = os.path.join(serverdir, 'log', 'lockrun')
#
def die(info="unknown"):
	if DEBUG: print 'exit with info: %s' % info
	if os.path.isfile(lockrun): os.remove(lockrun)
	exit()
def clean1():
	os.remove(lockrun)
#
def prepare():
	if os.path.isfile(locknotice): die('lock by notice' % locknotice)
	if os.path.getsize(fqueue) < 10: die('queue is null')
	if os.path.isfile(lockrun): die('lock by run: %s' % lockrun)
	#
	# lock run
	open(lockrun, 'w').close()
	#
	# lock queue; GO if not open for 1min (the lockqueue may be dead)
	for i in range(20):
		if not os.path.isfile(lockqueue): break
		time.sleep(3)
	open(lockqueue, 'w').close()
#
	lines = open(fqueue).readlines()
	print >>open(fhistory, 'a'), lines[0].strip()
	if len(lines) > 1:
		print >>open(fqueue, 'w'), ''.join(lines[1:]),
	else: file(fqueue, 'w').close()
	os.remove(lockqueue)
#
# parse the job
	line1 = lines[0]
	ss = line1.split()
	if len(ss) < 2:
		print >>stderr, "wrong line:", line1.strip()
		exit(0)
	jobid, email = ss[:2]
	rundir = os.path.join(serverdir, 'info/%s'%jobid)
	print >>open(os.path.join(rundir, 'info'), 'w'), lines[0]
	rtype = 2
	return jobid, rundir, rtype
#
# __MAIN__
DEBUG = 0
if len(argv)>1 and argv[1]=='-v': DEBUG=1
if not os.path.isdir(serverdir):
	if DEBUG: print 'no mounted disk', serverdir
	exit()
#
jobid, rundir, rtype = prepare()
#try:
#	rundir, rtype = prepare()
#except:
#	import traceback
#	print >>stderr, "Error happens"
#	traceback.print_exc()
#	clean1()
#	exit()
os.system('%s %s %s %s > %s 2> %s' % (prog, rundir, os.path.join(rundir, 'query'), 'genome' if jobid[0] == 'g' else 'protein', os.path.join(rundir, 'progress'), os.path.join(rundir, 'error')))
prog2 = os.path.join(sourcedir, 'buildweb.py')
os.system('%s %s' % (prog2, rundir))
#
#
clean1()
