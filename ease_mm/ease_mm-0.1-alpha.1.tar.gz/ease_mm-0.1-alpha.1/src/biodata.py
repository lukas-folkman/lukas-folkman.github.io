#!/usr/bin/env python

import collections
import os
import sys
import random
import features
import math
import traceback
import re
import textwrap
import gzip

SILENT = 'SL'
MISSENSE = 'MS'
NONSENSE = 'NS'
FS_INDEL = 'FS'
NFS_INDEL = 'NFS'

FASTA_DNA = 'FASTA_DNA'
FASTA_RNA = 'FASTA_RNA'
FASTA_PROT = 'FASTA_PROT'

#CONSTANTS
AA, DNA_CONS = 0, 0
P_D, ENTROPY = 1, 1
SS, PHI, PSI, P_E, P_C, P_H, ASA = 1, 2, 3, 4, 5, 6, 7
PSSM, OBS_PERCENT, INFO_VALUE, REL_WEIGHT = 1, 2, 3, 4
HHM_AA, HHM_STATES = 1, 2
HHM_STATES_NAMES = {features.HHM_MM_STR: 'M->M', features.HHM_MI_STR: 'M->I', features.HHM_MD_STR: 'M->D', features.HHM_IM_STR: 'I->M', features.HHM_II_STR: 'I->I', features.HHM_DM_STR: 'D->M', features.HHM_DD_STR: 'D->D', features.HHM_NEFF_STR: 'Neff', features.HHM_NEFF_I_STR: 'Neff_I', features.HHM_NEFF_D_STR: 'Neff_D'}
DNA_NUCLEOTIDES = 'ACGT'
RNA_NUCLEOTIDES = 'ACGU'
AMINO_ACIDS = 'ACDEFGHIKLMNPQRSTVWY'
SS_TYPES = 'HEC' #helix, extended, coil
RSS_V1, RSS_S1 = 0, 1
AA_VOLUME_ASA = {'A': 115, 'C': 135, 'D': 150, 'E': 190, 'F': 210, 'G': 75, 'H': 195, 'I': 175, 'K': 200, 'L': 170, 'M': 185, 'N': 160, 'P': 145, 'Q': 180, 'R': 225, 'S': 115, 'T': 140, 'V': 155, 'W': 255, 'Y': 230}
SELENOCYSTEINE = 'selenocysteine'
INITIATION_CODON = 'initiation_codon'
PRINT_WARNINGS = False
CHECK = False
CHROMOSOMES = [str(i) for i in range(1,23)] + ['X', 'Y']

CODON_TABLE = {
    'ATA':'I', 'ATC':'I', 'ATT':'I', 'ATG':'M',
    'ACA':'T', 'ACC':'T', 'ACG':'T', 'ACT':'T',
    'AAC':'N', 'AAT':'N', 'AAA':'K', 'AAG':'K',
    'AGC':'S', 'AGT':'S', 'AGA':'R', 'AGG':'R',
    'CTA':'L', 'CTC':'L', 'CTG':'L', 'CTT':'L',
    'CCA':'P', 'CCC':'P', 'CCG':'P', 'CCT':'P',
    'CAC':'H', 'CAT':'H', 'CAA':'Q', 'CAG':'Q',
    'CGA':'R', 'CGC':'R', 'CGG':'R', 'CGT':'R',
    'GTA':'V', 'GTC':'V', 'GTG':'V', 'GTT':'V',
    'GCA':'A', 'GCC':'A', 'GCG':'A', 'GCT':'A',
    'GAC':'D', 'GAT':'D', 'GAA':'E', 'GAG':'E',
    'GGA':'G', 'GGC':'G', 'GGG':'G', 'GGT':'G',
    'TCA':'S', 'TCC':'S', 'TCG':'S', 'TCT':'S',
    'TTC':'F', 'TTT':'F', 'TTA':'L', 'TTG':'L',
    'TAC':'Y', 'TAT':'Y', 'TAA':'*', 'TAG':'*',
    'TGC':'C', 'TGT':'C', 'TGA':'*', 'TGG':'W'
    }

#FOR EASE_MM EVALUATED ON S1210
USE_PDB_SEQ = False

AA_1TO3  = {
    'A': 'ALA', 'C': 'CYS', 'D': 'ASP',
    'E': 'GLU', 'F': 'PHE', 'G': 'GLY', 'H': 'HIS',
    'I': 'ILE', 'K': 'LYS', 'L': 'LEU', 'M': 'MET',
    'N': 'ASN', 'P': 'PRO', 'Q': 'GLN', 'R': 'ARG',
    'S': 'SER', 'T': 'THR', 'V': 'VAL', 'W': 'TRP',
    'Y': 'TYR',
}
AA_3TO1 = dict((x[1], x[0]) for x in AA_1TO3.items())

class VariantData:
	def __init__(self, raw_data, strict=True):
		self.ddg = None
		self.type = raw_data[-1] #this always must be the last attribute!
		if self.type != 'DDG':
			#-1 CCDS44042.1 310 EEEE/E 1|1640294|TTCCTCCTCC/T - 97 61 32 20 NFS
			if raw_data[0] != '1' and raw_data[0] != '-1': raise ValueError
			self.disease = int(raw_data[0])

			self.seq_id = raw_data[1]
			self.position = int(raw_data[2])
			self.reference = raw_data[3].split('/')[0]
			self.mutated = raw_data[3].split('/')[1]
			self.chromosome, self.chr_position, self.chr_reference, self.chr_mutated = get_chr_info(raw_data[4])

			if raw_data[5] != '+' and raw_data[5] != '-':
				raise ValueError
			self.chr_direction = raw_data[5]

			self.splice_left = int(raw_data[6])
			self.splice_right = int(raw_data[7])

			self.splice_aa_left = int(raw_data[8])
			self.splice_aa_right = int(raw_data[9])

			self.gene = raw_data[10]

			if strict:
				if self.type not in [FS_INDEL, NFS_INDEL, NONSENSE, MISSENSE, SILENT]:
					raise ValueError

				if self.type == FS_INDEL:
					if len(self.reference) != 1: print >> sys.stderr, self; raise ValueError
					if self.mutated.startswith(self.reference) and self.reference != '*' and self.mutated != '*' and self.mutated != '!': print >> sys.stderr, self; raise ValueError
					if self.mutated[-1] != '*' and self.mutated[-1] != '!': print >> sys.stderr, self; raise ValueError
					if isNonframeshifting(self.chr_reference, self.chr_mutated, self.reference, self.mutated): print >> sys.stderr, self; raise ValueError
					if min(len(self.chr_reference), len(self.chr_mutated)) != 1: print >> sys.stderr, self; raise ValueError
				elif self.type == NFS_INDEL:
					if '*' in self.mutated and '*' not in self.reference: print >> sys.stderr, self; raise ValueError
					if not isNonframeshifting(self.chr_reference, self.chr_mutated, self.reference, self.mutated): print >> sys.stderr, self; raise ValueError
					if min(len(self.chr_reference), len(self.chr_mutated)) != 1: print >> sys.stderr, self; raise ValueError
				elif self.type == NONSENSE:
					if len(self.reference) != 1 or self.mutated != '*': print >> sys.stderr, self; raise ValueError
					if len(self.chr_reference) != 1 or len(self.chr_mutated) != 1: print >> sys.stderr, self; raise ValueError
				elif self.type == MISSENSE:
					if len(self.reference) != 1 or len(self.mutated) != 1: print >> sys.stderr, self; raise ValueError
					if self.reference == self.mutated: print >> sys.stderr, self; raise ValueError
					if self.mutated == '*': print >> sys.stderr, self; raise ValueError
					if len(self.chr_reference) != 1 or len(self.chr_mutated) != 1: print >> sys.stderr, self; raise ValueError
				elif self.type == SILENT:
					if self.reference != self.mutated: print >> sys.stderr, self; raise ValueError
					if len(self.reference) != 1 or len(self.mutated) != 1: print >> sys.stderr, self; raise ValueError
					if len(self.chr_reference) != 1 or len(self.chr_mutated) != 1: print >> sys.stderr, self; raise ValueError

				#test whether padding is as expected
				strip_variant_x(self.chr_reference, self.chr_mutated, self.chr_position, self.type)
		else:
			#1A23 H32L P0AEG4 7.0 30.0 5.3 1
			self.type = MISSENSE
			if raw_data[6] != '1' and raw_data[6] != '-1': raise ValueError
			self.disease = int(raw_data[6])
			self.ddg = float(raw_data[5])
			self.temp = float(raw_data[4])
			self.ph = float(raw_data[3])
			self.pdb_id = raw_data[0]

			self.seq_id = raw_data[2]
			self.reference = raw_data[1][0]
			self.protherm_position = int(raw_data[1][1:-1])
			self.set_positions(features.SHIFTED_DIR)
			self.mutated = raw_data[1][-1]

			self.chromosome, self.chr_position, self.chr_reference, self.chr_mutated = None, None, None, None
			self.chr_direction, self.splice_left, self.splice_right, self.splice_aa_left = None, None, None, None
			self.splice_aa_right, self.gene = None, None

			if USE_PDB_SEQ:
				self.seq_id = self.pdb_id
				self.position = self.pdb_position

	def set_positions(self, shifted_dir):
		self.position = self.protherm_position - 1 #biodata is 0-based but DDG is 1-based
		self.pdb_position = self.protherm_position - 1 #biodata is 0-based but DDG is 1-based

	def __str__(self):
		if self.ddg is None:
			return ' '.join(map(str, [self.disease, self.seq_id, self.position, self.reference + '/' + self.mutated, self.chr_info(), self.chr_direction, self.splice_left, self.splice_right, self.splice_aa_left, self.splice_aa_right, self.gene, self.type]))
		else:
			return ' '.join(map(str, [self.pdb_id, self.reference+str(self.protherm_position)+self.mutated, self.seq_id, self.ph, self.temp, self.ddg, self.disease]))

	def __repr__(self):
		return self.__str__()

	def chr_info(self):
		if self.ddg is None:
			return 'chr' + self.chromosome + '|' + str(self.chr_position) + '|' + self.chr_reference + '/' + self.chr_mutated
		else:
			return None

	def ddg_mutation_info(self):
		if self.ddg is None:
			return None
		else:
			return self.reference + str(self.position+1) + self.mutated

	def query_info(self):
		if self.ddg is None:
			return 'chr' + self.chromosome + ' ' + str(self.chr_position) + ' ' + self.chr_reference + ' ' + self.chr_mutated
		else:
			return ' '.join(map(str, [self.pdb_id, self.reference+str(self.protherm_position)+self.mutated, self.seq_id]))

	def set_splice_aa_sites(self, ccds_data):
		self.splice_aa_left = None
		self.splice_aa_right = None
		for ccds in ccds_data[self.chromosome]:
			if self.seq_id == ccds:
				head, aa_count = 0, 0
				locations = ccds.cds_locations[1:-1].split(',')
				if self.chr_direction == '-':
					locations.reverse()
				for l in locations:
					start, end = map(int, l.split('-'))
					splice_nuc_len = abs(end - start) + 1 - head #head has already been included in the previous splice
					splice_aa_len = int(math.ceil(splice_nuc_len / 3.0))
					aa_count += splice_aa_len
					head = (3 - (splice_nuc_len % 3)) % 3
					if aa_count >= self.position + 1:
						self.splice_aa_right = aa_count - (self.position + 1)
						self.splice_aa_left = splice_aa_len - self.splice_aa_right - 1
						break
			if self.splice_aa_left != None and self.splice_aa_right != None:
				break

		if self.splice_aa_left == None or self.splice_aa_right == None: raise ValueError

	def set_gene_name(self, ccds_data):
		for ccds_entry in ccds_data[self.chromosome]:
			if ccds_entry == self.seq_id: break
		self.gene = ccds_entry.gene

	def is_transcript(self, ccds_data_transcript):
		return self.seq_id == ccds_data_transcript.ccds_id

class CCDSData:
	def __init__(self, raw_data):
		#chromosome	nc_accession	gene	gene_id	ccds_id	ccds_status	cds_strand	cds_from	cds_to	cds_locations	match_type
		self.chromosome = str(int(raw_data[0])) if raw_data[0] != 'X' and raw_data[0] != 'Y' else raw_data[0]
		self.nc_accession = raw_data[1]
		self.gene = raw_data[2]
		self.gene_id = int(raw_data[3])
		self.ccds_id = raw_data[4] + (self.chromosome if self.chromosome in 'XY' else '')
		self.ccds_status = raw_data[5]
		self.cds_strand = raw_data[6]
		if self.cds_strand != '+' and self.cds_strand != '-':
			raise ValueError
		self.cds_from = int(raw_data[7])
		self.cds_to = int(raw_data[8])
		self.cds_locations = raw_data[9]
		if self.cds_locations[0] != '[' or self.cds_locations[-1] != ']':
			raise ValueError
		self.match_type = raw_data[10]

	def __eq__(self, other):
		if isinstance(other, basestring):
			return self.ccds_id == other
		elif isinstance(other, self.__class__):
			return self.ccds_id == other.ccds_id

	def __ne__(self, other):
		return not self.__eq__(other)

	def __str__(self):
		return ' '.join(map(str, [self.chromosome, self.ccds_id, self.cds_strand, self.cds_from, self.cds_to, self.cds_locations]))

	def __repr__(self):
		return self.__str__()

def mean(x):
	return sum(x)/(float(len(x)))

def std(x):
	m = mean(x)
	d2 = [math.pow(m - y, 2) for y in x]
	return math.sqrt(sum(d2) / float(len(x)))

def get_gene_trancsripts(ccds_data):
	gene_transcritps = {}
	for chromosome in ccds_data.keys():
		for trancsript in ccds_data[chromosome]:
			if trancsript.gene not in gene_transcritps: gene_transcritps[trancsript.gene] = []
			gene_transcritps[trancsript.gene].append(trancsript)
	return gene_transcritps

def get_variant_transcript(variant, transcripts):
	for t in transcripts:
		if t == variant.seq_id:
			return t
	return None

def get_exon_count(transcript):
	return len(transcript.cds_locations[1:-1].split(','))

def get_exon_num(transcript, chr_position):
	locations = transcript.cds_locations[1:-1].split(',')
	if transcript.cds_strand == '-': locations.reverse()
	exon_num = 0
	for l in locations:
		exon_num += 1
		start, end = map(int, l.split('-'))
		#chr_position is 1-based
		if start <= chr_position - 1 and end >= chr_position - 1:
			break
	return exon_num if exon_num != 0 else None

def get_affected_transcripts(transcritps, chr_position_start, chr_position_end):
	affected_transcripts = []
	for t in transcritps:
		for l in t.cds_locations[1:-1].split(','):
			start, end = map(int, l.split('-'))
			#chr_position is 1-based
			if start <= chr_position_start - 1 and end >= chr_position_start - 1 and start <= chr_position_end - 1 and end >= chr_position_end - 1:
				affected_transcripts.append(t)
				break
	return affected_transcripts

def calculate_utr_offset(utr_starts, utr_ends, chr_direction):
	if len(utr_starts) != len(utr_ends): raise ValueError
	if len(utr_starts) == 0: return None
	utr_starts = sorted(utr_starts)
	utr_ends = sorted(utr_ends)
	if chr_direction == '-': utr_starts.reverse(); utr_ends.reverse()
	utr_offset = 0
	for i in range(0, len(utr_starts) - 1):
		if utr_starts[i] > utr_ends[i]: raise ValueError
		utr_offset += (utr_ends[i] - utr_starts[i] + 1)
	#total length of all 3'UTRs but the very last one
	return utr_offset

def get_utr_ensembl_offset(transcript, utr_data, ccds2seq_map):
	ens_transcript_ids = get_utr_transcript_ids(get_ensembl_transcript_ids, transcript.ccds_id, utr_data, ccds2seq_map)
	if len(ens_transcript_ids) == 0:
		return None
	else:
		min_utr_offset = None
		for t_id in ens_transcript_ids:
			#format: utr_data[t_id] = [ens_gene_id, gene_name, ens_transcript_id, strand, utr5_starts, utr5_ends, utr3_starts, utr3_ends]
			if utr_data[t_id][3] != transcript.cds_strand: print >> sys.stderr, 'WARNING: wrong UTR strand direction, skipping', transcript, t_id; return None
			utr_offset = calculate_utr_offset(utr_data[t_id][6], utr_data[t_id][7], transcript.cds_strand)
			if utr_offset is not None:
				min_utr_offset = min(min_utr_offset, utr_offset) if min_utr_offset is not None else utr_offset

		return min_utr_offset

def get_utr_refseq_offset(transcript, utr_data, ccds2seq_map):
	rs_transcript_ids = get_utr_transcript_ids(get_refseq_transcript_ids, transcript.ccds_id, utr_data, ccds2seq_map)
	if len(rs_transcript_ids) == 0:
		return None
	else:
		min_utr_offset = None
		for t_id in rs_transcript_ids:
			utr_starts, utr_ends = [], []
			for utr in utr_data[t_id]:
				utr_starts.append(utr[0])
				utr_ends.append(utr[1])
				if utr[5] != transcript.cds_strand: print >> sys.stderr, 'WARNING: wrong UTR strand direction, skipping', transcript, utr; return None

			utr_offset = calculate_utr_offset(utr_starts, utr_ends, transcript.cds_strand)
			min_utr_offset = min(min_utr_offset, utr_offset) if min_utr_offset is not None else utr_offset

		return min_utr_offset

def get_utr_transcript_ids(get_transcript_ids_method, ccds_id, utr_data, ccds2seq_map):
	#some CCDS have more transcripts because alternative splicing can affect only UTR (multiple transccripts) and not CDS (single CCDS transcript)
	return filter(lambda t: t in utr_data, get_transcript_ids_method(ccds_id, ccds2seq_map))

def get_ensembl_transcript_ids(ccds_id, ccds2seq_map):
	return get_transcript_ids(ccds_id, ccds2seq_map, 'ENST')

def get_refseq_transcript_ids(ccds_id, ccds2seq_map):
	return map(lambda t: t[:t.rfind('.')], get_transcript_ids(ccds_id, ccds2seq_map, 'NM_'))

def get_transcript_ids(ccds_id, ccds2seq_map, prefix):
	return filter(lambda t: t.startswith(prefix), ccds2seq_map[ccds_id.strip('XY')])

def parse_ccds2seq_map(ccds2seq_map_filename=features.CCDS2SEQ):
	ccds2seq_map = {}
	with open_file(ccds2seq_map_filename, 'r') as f:
		for line in f:
			if line[0] == '#': continue
			line_split = line.strip().split('\t')
			ccds_id = line_split[0]
			transcript_id = line_split[4]
			if ccds_id not in ccds2seq_map: ccds2seq_map[ccds_id] = []
			ccds2seq_map[ccds_id].append(transcript_id)
	return ccds2seq_map

def parse_utr_ensembl_data(utr_data_filename=features.UTR_ENSEMBL):
	utr_data = {}
	with open_file(utr_data_filename, 'r') as f:
		line = f.readline()
		while line:
			if line[0] == '>':
				line_split = line[1:].strip().split('|')
				#next_line = f.readline().strip()
				ens_gene_id = line_split[0]
				gene_name = line_split[1]
				ens_transcript_id = line_split[2]
				if int(line_split[3]) != 1 and int(line_split[3]) != -1: raise ValueError
				strand = '+' if int(line_split[3]) == 1 else '-'
				if len(line_split) > 4:
					utr5_starts = map(int, line_split[4].split(';')) if len(line_split[4]) != 0 else []
					utr5_ends = map(int, line_split[5].split(';')) if len(line_split[5]) != 0 else []
					if len(line_split) > 6:
						utr3_starts = map(int, line_split[6].split(';')) if len(line_split[6]) != 0 else []
						utr3_ends = map(int, line_split[7].split(';')) if len(line_split[7]) != 0 else []
						if len(utr5_starts) != len(utr5_ends) or len(utr3_starts) != len(utr3_ends): raise ValueError
						if ens_transcript_id in utr_data: raise ValueError
						#if next_line != 'Sequence unavailable':
						utr_data[ens_transcript_id] = [ens_gene_id, gene_name, ens_transcript_id, strand, utr5_starts, utr5_ends, utr3_starts, utr3_ends]
			line = f.readline()
	return utr_data

def parse_utr_ensembl_data_DEPRECATED(utr_data_filename=features.UTR_3END_ENSEMBL_DEPRECATED):
	utr_data = {}
	with open_file(utr_data_filename, 'r') as f:
		line = f.readline()
		while line:
			if line[0] == '>':
				line_split = line[1:].strip().split('|')
				next_line = f.readline().strip()
				ens_gene_id = line_split[0]
				ens_transcript_id = line_split[1]
				utr_ends = map(int, line_split[2].split(';')) if len(line_split[2]) != 0 else []
				utr_starts = map(int, line_split[3].split(';'))  if len(line_split[3]) != 0 else []
				gene_name = line_split[4]
				if len(utr_starts) != len(utr_ends): raise ValueError
				if ens_transcript_id in utr_data: raise ValueError
				if next_line != 'Sequence unavailable':
					utr_data[ens_transcript_id] = [utr_starts, utr_ends, gene_name, ens_gene_id]
			line = f.readline()
	return utr_data

def parse_utr_refseq_data(utr_data_filename=features.UTR_3END_REFSEQ):
	utr_data = {}
	with open_file(utr_data_filename, 'r') as f:
		for line in f:
			#chr1	1246759	1247057	NM_153339_utr3_7_0_chr1_1246760_f	0	+
			if line[0] == '#': continue
			line_split = line.strip().split('\t')
			chromosome = line_split[0][3:] if line_split[0].startswith('chr') else line_split[0]
			utr_start = int(line_split[1])
			utr_end = int(line_split[2]) - 1 #so that it is inclusive
			utr_id = line_split[3]
			num = int(line_split[4])
			chr_direction = line_split[5]
			if chr_direction != '+' and chr_direction != '-': raise ValueError
			refseq_id = '_'.join(utr_id.split('_')[:2])
			if chromosome in (map(str, range(1,23)) + ['X', 'Y']):
				if refseq_id not in utr_data: utr_data[refseq_id] = []
				utr_data[refseq_id].append([utr_start, utr_end, chromosome, utr_id, num, chr_direction])
	return utr_data

def reposition_mutation_site(variant, ccds_proteins):
	if variant.type != FS_INDEL and  not (variant.type == NFS_INDEL and '*' in variant.mutated): raise ValueError
	sequence = str(ccds_proteins[variant.seq_id].seq)
	check_seq(variant, sequence)
	variant.reference = sequence[variant.position:] + '*'

	if variant.reference == variant.mutated:
		variant.reference = variant.reference[-1]
		variant.mutated = variant.mutated[-1]
		variant.position = len(sequence)
		return

	for i in range(len(variant.reference)):
		if i >= len(variant.mutated): print >> sys.stderr, variant; raise ValueError
		if variant.reference[i] != variant.mutated[i]:
			variant.reference = variant.reference[i]
			variant.mutated = variant.mutated[i:]
			variant.position += i
			break

def strip_snp_variant(variant, strip_chr_info=False):
	if variant.type not in [NONSENSE, MISSENSE, SILENT]: raise ValueError

	if len(variant.reference) != 1:
		variant.reference, variant.mutated, variant.position = strip_snp_ref_mut(variant.reference, variant.mutated, variant.position)

	if strip_chr_info and len(variant.chr_reference) != 1:
		variant.chr_reference, variant.chr_mutated, variant.chr_position = strip_snp_ref_mut(variant.chr_reference, variant.chr_mutated, variant.chr_position)

def strip_snp_ref_mut(reference, mutated, position):
	if len(reference) != len(mutated): raise ValueError

	new_ref, new_mut, new_pos = '', '', position
	for i in range(len(reference)):
		if reference[i] != mutated[i]:
			new_ref += reference[i]
			new_mut += mutated[i]
			new_pos += i

	if len(new_ref) != 1 or len(new_mut) != 1: raise ValueError

	return new_ref, new_mut, new_pos

def get_chr_info(chr_info_raw):
	chr_info = chr_info_raw.split('|')
	chromosome = chr_info[0]
	if chromosome.lower().startswith('chr'): chromosome = chromosome[3:]
	if chromosome not in 'XY': int(chromosome)
	position = int(chr_info[1])
	reference = chr_info[2].split('/')[0]
	mutated = chr_info[2].split('/')[1]
	return chromosome, position, reference, mutated

def parse_ccds_exceptions(filename=features.CCDS_ATTRIBUTES):
	data = {SELENOCYSTEINE: [], INITIATION_CODON: []}
	with open_file(filename, 'r') as f:
		for line in f:
			if line[0] != '#':
				line_split = line.strip().split('\t')
				ccds_id = line_split[0]
				if line_split[-1] == 'Contains selenocysteine':
					if ccds_id in data[SELENOCYSTEINE]: raise ValueError
					data[SELENOCYSTEINE].append(ccds_id)
				elif line_split[-1] == 'Non-AUG initiation codon':
					if ccds_id in data[INITIATION_CODON]: raise ValueError
					data[INITIATION_CODON].append(ccds_id)
	data[INITIATION_CODON].append('CCDS46521.1') #according to the web and data
	return data

def parse_ccds_nucleotides_datafile(filename=features.CCDS_NUCLEOTIDES):
	return parse_ccds_fasta_datafile(filename)

def parse_ccds_proteins_datafile(filename=features.CCDS_PROTEINS):
	return parse_ccds_fasta_datafile(filename)

def parse_ccds_fasta_datafile_deprecated(filename):
	import Bio.SeqIO
	data = {}
	for fasta_seq in Bio.SeqIO.parse(filename, 'fasta'):
		name_split = fasta_seq.name.split('|')
		name = name_split[0]
		if name_split[2][-1] in 'XY':
			name += name_split[2][-1]
		data[name] = fasta_seq
	return data

def parse_ccds_fasta_datafile(filename):
	data = {}
	for fasta in parse_fasta(filename, only_std_letters=False, no_warnings=True):
		name_split = fasta.header[1:].split('|')
		name = name_split[0]
		if name_split[2][-1] in 'XY':
			name += name_split[2][-1]
		data[name] = fasta.seq
	return data

def parse_ccds_datafile(filename=features.CCDS_DATA, include_withdrawn=False):
	data = {}
	with open_file(filename, 'r') as ccds_file:
		for line in ccds_file:
			if line[0] != '#':
				line_split = line.strip().split('\t')
				if line_split[10].lower() == 'identical':
					if include_withdrawn or not line_split[5].lower().startswith('withdrawn'):
						entry = CCDSData(line_split)
						if entry.chromosome not in data.keys():
							data[entry.chromosome] = []
						data[entry.chromosome].append(entry)
	return data

def parse_ccds_datafile_by_ccds(filename=features.CCDS_DATA, include_withdrawn=False):
	data = {}
	with open_file(filename, 'r') as ccds_file:
		for line in ccds_file:
			if line[0] != '#':
				line_split = line.strip().split('\t')
				if line_split[10].lower() == 'identical':
					if include_withdrawn or not line_split[5].lower().startswith('withdrawn'):
						entry = CCDSData(line_split)
						if entry.ccds_id in data.keys(): raise ValueError
						data[entry.ccds_id] = entry
	return data

def reverse_dna_seq(seq):
	dict_rev = {'A':'T', 'T':'A', 'G':'C', 'C':'G'}
	return ''.join([dict_rev[x] for x in reversed(seq)])

def get_direction(ccds_data, chromosome, ccds_id, position):
	for entry in ccds_data[chromosome.strip('chr')]:
		if ccds_id == entry.ccds_id:
			if not (entry.cds_from <= position and entry.cds_to >= position):
				raise ValueError
			return entry.cds_strand

def parse_variants_per_chr_info(dataset_filename):
	variants = {}
	with open_file(dataset_filename, 'r') as f:
		for line in f:
			variant = VariantData(line.strip().split())
			variants[variant.chr_info()] = variant
	return variants

def dscore_results(dscore_filename, dataset_filename):
	variants = parse_variants_per_chr_info(dataset_filename)
	lines = stripped_lines(dscore_filename)
	i = 0
	targets, predictions, prediction_values, target_strings = [], [], [], []
	while i < len(lines):
		if lines[i] == 'Indelz Results':
			if not (lines[i+4].startswith('Also in ') and lines[i+8].startswith('Variation:') and lines[i+9].startswith('Total information content:') and lines[i+10].startswith('Information loss:')  and lines[i+11].startswith('Loss score D:')): raise ValueError
			chr_info = lines[i+4].split('/')[-1].strip()
			if chr_info[-4:] != '.out': raise ValueError
			chr_info = chr_info[:-4].split('_')
			chr_info = chr_info[1] + '|' + chr_info[2] + '|' + chr_info[3] + '/' + chr_info[4]
			iformation_content = float(lines[i+9].split(':')[1].strip())
			iformation_loss = float(lines[i+10].split(':')[1].strip())
			dscore = float(lines[i+11].split(':')[1].strip())
			targets.append(variants[chr_info].disease)
			predictions.append(-1)
			#prediction_values.append(iformation_loss/iformation_content)
			prediction_values.append(dscore)
			target_strings.append(str(variants[chr_info]))
			i += 11
		else:
			i += 1

	return targets, predictions, prediction_values, target_strings

def sift_results(results_list):
	joined_results = {}
	for line in results_list:
		if line.startswith('Coordinates'): continue
		line_split = line.split('\t')
		found_cds, found_prediction = False, False
		for s in line_split:
			if s == 'CDS':
				found_cds = True
			if s == 'neutral' or s == 'damaging':
				found_prediction = True
		if not found_cds or not found_prediction:
			print >> sys.stderr, line
			continue

		target = line_split[0].split(',')[-1].split()
		target_str = ' '.join(target)
		if target[0] != '#' or (int(target[1]) != 1 and int(target[1]) != -1): raise ValueError

		disease = int(target[1]) == 1

		if line_split[6] != 'damaging' and line_split[6] != 'neutral': raise ValueError
		prediction = 1 if line_split[6] == 'damaging' else -1
		if float(line_split[7]) <= 0.5 or float(line_split[7]) > 1.0: raise ValueError
		prediction_value = float(line_split[7]) if prediction == 1 else (1.0 - float(line_split[7]))

		if target_str not in joined_results:
			joined_results[target_str] = []
		alredy_included = False
		for p in joined_results[target_str]:
			if p[0] == (1 if disease else -1) and p[1] == prediction and p[2] == prediction_value:
				alredy_included = True
				break
		if not alredy_included:
			joined_results[target_str].append([1 if disease else -1, prediction, prediction_value])

	return joined_results

def parse_ddig(lines, disease, ccds_data_filename):
	ccds_data = parse_ccds_datafile(ccds_data_filename, include_withdrawn=True)
	variants = []
	for line in lines:
		line_split = line.split()
		for i in range(len(line_split)):
			if line_split[i].startswith('CCDS'):
				ccds_index = i
				break
		line_split = line_split[ccds_index:]
		line_split.insert(0, '1' if disease else '-1')
		chr_direction = get_direction(ccds_data, line_split[4].split('|')[0], line_split[1], int(line_split[4].split('|')[1]) - 1)
		line_split.extend([chr_direction, '-1', '-1', '-1', '-1', NFS_INDEL])
		variant = VariantData(line_split)
		variant.set_splice_aa_sites(ccds_data)
		variant.splice_left = 3 * variant.splice_aa_left #just approximate!
		variant.splice_right = 3 * variant.splice_aa_right #just approximate!
		variants.append(variant)
	return variants

def sift_input(lines, ddig_format=False, disease=None, ccds_data_filename=None):
	if ddig_format:
		variants = parse_ddig(lines, disease, ccds_data_filename)
	else:
		variants = [VariantData(x.split()) for x in lines]

	sift_data = []
	for variant in variants:
		if variant.type in [NONSENSE, MISSENSE, SILENT]: raise ValueError

		reference, mutated, coordinate_s = strip_variant_x(variant.chr_reference, variant.chr_mutated, variant.chr_position - 1, variant.type)
		if len(mutated) == 0:
			allele = reference + '/-'
			coordinate_e = coordinate_s + len(reference)
		elif len(reference) == 0:
			allele = '-/' + mutated
			coordinate_e = coordinate_s
		else:
			raise ValueError

		sift_data.append(','.join([variant.chromosome, str(coordinate_s), str(coordinate_e), '1', allele, '# ' + str(variant)]))

	return sift_data

def stripped_lines(filename):
	with open_file(filename, 'r') as f:
		stripped = map(lambda x: x.strip(), f.readlines())
	return stripped

def isSNP(reference, mutated):
	if len(reference) != len(mutated):
		return False
	diff = 0
	for i in range(len(reference)):
		if reference[i] != mutated[i]:
			diff += 1
	if diff != 1:
		return False

	return True

def isNonframeshifting(chr_reference, chr_mutated, reference_aa, mutated_aa):
	if isSNP(chr_reference, chr_mutated): raise ValueError
	#NFS indels introducing a PTC are treated as FS indels in my framework
	return (len(chr_reference) - len(chr_mutated)) % 3 == 0 and ('*' in reference_aa or '*' not in mutated_aa)

def read_fasta(filename_prefix, extension=features.FASTA_EXT, path=features.FASTA):
	if extension is not None and path is not None:
		filename = os.path.join(path, filename_prefix + extension)
	else:
		filename = filename_prefix
	header = None
	seq = ''
	with open_file(filename, 'r') as f:
		for line in f:
			if line[0] == '>':
				if header is not None: raise ValueError('Multiple sequence records in ' + filename)
				header = line.strip()
			else:
				seq += line.strip()
	return seq

def parse_fasta_deprecated(filename_prefix, extension=features.FASTA_EXT, path=features.FASTA):
	import Bio.SeqIO
	if extension is not None and path is not None:
		filename = os.path.join(path, filename_prefix + extension)
	else:
		filename = filename_prefix
	return Bio.SeqIO.read(filename, 'fasta')

def create_fasta_files(ccds_datafile, ccds_list, path):
	import Bio.SeqIO
	ccds_data = parse_ccds_fasta_datafile(ccds_datafile)
	for ccds_id in ccds_list:
		if not os.path.isdir(path):
			raise ValueError
		if os.path.isfile(os.path.join(path, ccds_id + '.fasta')):
			print >> sys.stderr, os.path.join(path, ccds_id + '.fasta'), 'already exists!'
			raise ValueError
		with open_file(os.path.join(path, ccds_id + '.fasta'), 'w') as fasta_file:
			Bio.SeqIO.write(ccds_data[ccds_id], fasta_file, 'fasta')

def replace_nonstd_aa(fasta_list, fasta_dir):
	import Bio.SeqIO
	from Bio.SeqRecord import SeqRecord
	lines = []
	for fasta in fasta_list:
		seq_record = parse_fasta_deprecated(fasta, path=fasta_dir)
		seq = seq_record.seq.tomutable()
		if 'U' in seq or 'X' in seq:
			if 'U' in seq:
				for i in range(seq.count('U')):
					seq[seq.index('U')] = 'C'

			if fasta == 'CCDS64688.1' and seq[43] == 'X':
				seq[43] = 'Q'
			elif fasta == 'CCDS66138.1' and seq[20] == 'X':
				seq[20] = 'R'
			elif fasta == 'CCDS62700.1' and seq[262] == 'X':
				seq[262] = 'K'
			else:
				lines.append(fasta)
			with open_file(os.path.join(fasta_dir, fasta + '.fasta'), 'w') as fasta_file:
				Bio.SeqIO.write(SeqRecord(seq, id=seq_record.id, name=seq_record.name, description=seq_record.description), fasta_file, 'fasta')
	return lines

def create_blastclust_input(ccds_datafile, ccds_list):
	ccds_data = parse_ccds_fasta_datafile(ccds_datafile)
	i = 0
	lines = []
	for ccds_id in ccds_list:
		i += 1
		lines.append('>gi|' + str(i) + '|' + ccds_id)
		lines.append(str(ccds_data[ccds_id].seq))
	return lines

def translate_blastclust(blastclust_in, blastclust_out):
	ccds_ids = {}
	lines = []
	for line in blastclust_in:
		if line[0] == '>':
			line_split = line.split('|')
			number = int(line_split[1])
			ccds_id = line_split[2]
			ccds_ids[number] = ccds_id
	for line in blastclust_out:
		line_split = line.split()
		translated = ''
		for number in line_split:
			translated += ccds_ids[int(number)] + ' '
		lines.append(translated.strip())
	return lines

def remove_homologs(dataset, blastclust, randomly):
	data = {}
	for line in dataset:
		ccds_id = line.split()[1]
		if ccds_id not in data:
			data[ccds_id] = []
		data[ccds_id].append(line)

	ccds_to_keep = []
	for line in blastclust:
		chosen_ccds = None
		if not randomly:
			for ccds_id in line.split():
				if ccds_id not in data:	raise ValueError
				if chosen_ccds is None or len(data[chosen_ccds]) < len(data[ccds_id]):
					chosen_ccds = ccds_id
		else:
			homologous_ccds_ids = line.split()
			chosen_ccds = homologous_ccds_ids[random.randint(0, len(homologous_ccds_ids) - 1)]

		ccds_to_keep.append(chosen_ccds)

	lines = []
	for line in dataset:
		ccds_id = line.split()[1]
		if ccds_id in ccds_to_keep:
			lines.append(line)
	return lines

def parse_variants_per_protein(dataset):
	data = {}
	for line in dataset:
		line_split = line.split()
		variant = VariantData(line_split)
		if variant.seq_id not in data:
			data[variant.seq_id] = []
		data[variant.seq_id].append(variant)
	return data

def keep_just_one(dataset):
	lines = []
	data = parse_variants_per_protein(dataset)
	for seq_id in data.keys():
		lines.append(str(data[seq_id][random.randint(0, len(data[seq_id]) - 1)]))
	return lines

def balance_by_removal(dataset):
	dataset_neutral = []
	dataset_disease = []
	for line in dataset:
		variant = VariantData(line.split())
		if variant.disease == 1:
			dataset_disease.append(line)
		elif  variant.disease == -1:
			dataset_neutral.append(line)
		else: raise ValueError

	dataset = None
	if len(dataset_neutral) == len(dataset_disease):
		return []
	elif len(dataset_neutral) > len(dataset_disease):
		dataset = dataset_neutral
		other_dataset = dataset_disease
	elif len(dataset_neutral) < len(dataset_disease):
		dataset = dataset_disease
		other_dataset = dataset_neutral

	lines = []
	data = parse_variants_per_protein(dataset)
	seq_ids = data.keys()
	random.shuffle(seq_ids)
	i = 0
	while len(lines) < len(other_dataset):
		seq_id = seq_ids[i]
		random.shuffle(data[seq_id])
		lines.append(str(data[seq_id][0]))
		del data[seq_id][0]
		if len(data[seq_id]) == 0:
			data.pop(seq_id)
			seq_ids.remove(seq_id)
		else:
			i += 1
		i = i % len(seq_ids)

	lines += other_dataset

	return lines

def label_method(is_classification):
	return lambda variant: variant.disease if is_classification else variant.ddg

def calculate_features(dataset_filename, feature_set, label_method, only_one_transcript=False, ignore_failure=False):
	queries = []
	labels = []
	data = []

	seq_id_cache = None
	seq_cache = None
	disorder_cache = None
	spine_x_cache = None
	pssm_cache = None
	phyloP_cache = None
	hhm_cache = None
	hhm_scores_cache = None #for all sequences, do not empty the cache
	kaks_sift_cache = None #for all sequences, do not empty the cache
	kaks_cache = None  #for all sequences, do not empty the cache
	entropy_cache = None
	entropy_cache_type = None
	rss_cache = None
	rss_snp_cache = None
	rss_snp_precomputed_cache = None
	ccds_data_chache = None
	gene_transcripts_cache = None
	ccds2seq_map_cahce = None
	utr_data_cahce = None
	ccds_nucleotides_cache = None
	ccds_proteins_cache = None
	ccds_exceptions_cache = None
	blosum_cache = None
	aap_cache = None

	with open_file(dataset_filename, 'r') as dataset_file:
		for line in dataset_file:
			try:
				variant = VariantData(line.strip().split())
				if CHECK: print variant
				if variant.seq_id != seq_id_cache:
					seq_cache = None
					disorder_cache = None
					spine_x_cache = None
					pssm_cache = None
					phyloP_cache = None
					hhm_cache = None
					entropy_cache = None
					entropy_cache_type = None
					rss_cache = None
					rss_snp_cache = None
					seq_id_cache = variant.seq_id

				if seq_cache is None:
					seq_cache = read_fasta(variant.seq_id)
				check_seq(variant, seq_cache)

				entry = []
				for feature in feature_set:
					value = None

					#KaKs (SIFT)
					if feature.feature == features.KAKS_SIFT:
						if kaks_sift_cache is None: kaks_sift_cache = parse_kaks_sift_datafile()
						value = kaks_sift_cache[variant.seq_id] if variant.seq_id in kaks_sift_cache else -1.0

					#KaKs (Ensembl)
					elif feature.feature in [features.KAKS_AVG, features.KAKS_MOUSE_CHIMP_AVG, features.KAKS_MOUSE, features.KAKS_RAT, features.KAKS_MACAQUE, features.KAKS_CHIMP]:
						if kaks_cache is None: kaks_cache = parse_kaks_ensembl_datafile()
						if ccds2seq_map_cahce is None: ccds2seq_map_cahce = parse_ccds2seq_map()
						value = calculate_kaks(variant, kaks_cache, ccds2seq_map_cahce, feature)

					#multiple-transcritps-based features
					elif feature.get_feature_offset() in [features.UNAFFECTED_TRANSCRIPTS_OFFSET, features.NUM_EXONS_OFFSET, features.EXON_NUM_ABS_OFFSET, features.EXON_NUM_REL_OFFSET, features.SPLICE_LEFT_OFFSET, features.SPLICE_RIGHT_OFFSET, features.SPLICE_CLOSEST_OFFSET, features.LOCATION_N_REL_OFFSET, features.LOCATION_N_ABS_OFFSET, features.LOCATION_C_REL_OFFSET, features.LOCATION_C_ABS_OFFSET, features.LOCATION_CENTRED_OFFSET, features.LENGTH_SEQ_REL_OFFSET, features.LENGTH_SEQ_ABS_OFFSET, features.MUTATED_SEQ_REL_OFFSET, features.MUTATED_SEQ_ABS_OFFSET]:
						if ccds_data_chache is None: ccds_data_chache = parse_ccds_datafile()
						if gene_transcripts_cache is None: gene_transcripts_cache = get_gene_trancsripts(ccds_data_chache)
						if feature.feature in [features.NO_NONSTOP_DECAY_ABS, features.NO_NONSTOP_DECAY_REL, features.NO_NONSENSE_DECAY_ABS, features.NO_NONSENSE_DECAY_REL, features.NO_NONSTOP_NONSENSE_DECAY_ABS, features.NO_NONSTOP_NONSENSE_DECAY_REL] or feature.get_feature_offset() in [features.LENGTH_SEQ_REL_OFFSET, features.LENGTH_SEQ_ABS_OFFSET, features.MUTATED_SEQ_REL_OFFSET, features.MUTATED_SEQ_ABS_OFFSET]:
							if ccds_nucleotides_cache is None: ccds_nucleotides_cache = parse_ccds_nucleotides_datafile()
							if ccds_proteins_cache is None: ccds_proteins_cache = parse_ccds_proteins_datafile()
							if ccds_exceptions_cache is None: ccds_exceptions_cache = parse_ccds_exceptions()
						if feature.feature in [features.NO_NONSENSE_DECAY_ABS, features.NO_NONSENSE_DECAY_REL, features.NO_NONSTOP_NONSENSE_DECAY_ABS, features.NO_NONSTOP_NONSENSE_DECAY_REL]:
							if ccds2seq_map_cahce is None: ccds2seq_map_cahce = parse_ccds2seq_map()
							if utr_data_cahce is None: utr_data_cahce = parse_utr_ensembl_data()
						value = calculate_features_with_multiple_transcripts(variant, feature, ccds_data_chache, gene_transcripts_cache[variant.gene], ccds_nucleotides_cache, ccds_proteins_cache, ccds_exceptions_cache, ccds2seq_map_cahce, utr_data_cahce, only_one_transcript=only_one_transcript)

					#disorder with Spine-D
					elif feature.get_feature_offset() == features.DISORDER_OFFSET:
						if disorder_cache is None: disorder_cache = parse_spine_d(variant.seq_id)
						check_seq_matrix(variant, disorder_cache)
						value = calculate_disorder(variant, disorder_cache, feature)

					#asa with Spine-X/Spider
					elif feature.get_feature_offset() == features.ASA_OFFSET:
						if spine_x_cache is None: spine_x_cache = parse_spider(variant.seq_id)
						check_seq_matrix(variant, spine_x_cache)
						value = calculate_asa(variant, spine_x_cache, feature)

					#ss probabilities with Spine-X/Spider
					elif feature.get_feature_offset() in [features.SHEET_P_OFFSET, features.COIL_P_OFFSET, features.HELIX_P_OFFSET]:
						if spine_x_cache is None: spine_x_cache = parse_spider(variant.seq_id)
						check_seq_matrix(variant, spine_x_cache)
						value = calculate_ss_probability(variant, spine_x_cache, feature)

					#ss fraction with Spine-X/Spider
					elif feature.get_feature_offset() in [features.SHEET_FRAC_OFFSET, features.COIL_FRAC_OFFSET, features.HELIX_FRAC_OFFSET]:
						if spine_x_cache is None: spine_x_cache = parse_spider(variant.seq_id)
						check_seq_matrix(variant, spine_x_cache)
						value = calculate_ss_fraction(variant, spine_x_cache, feature)

					#PSSM
					elif feature.get_feature_offset() == features.PSSM_CONS_OFFSET or feature.get_feature_offset() in features.PSSM_LOG_OFFSETS+features.PSSM_LOG_SCALED_OFFSETS:
						if pssm_cache is None: pssm_cache = parse_pssm(variant.seq_id)
						if blosum_cache is None: blosum_cache = parse_blosum()
						check_seq_matrix(variant, pssm_cache)
						value = calculate_pssm_conservation(variant, pssm_cache, blosum_cache, feature)

					#DNA conservation
					elif feature.get_feature_offset() == features.DNA_CONS_OFFSET:
						if phyloP_cache is None: phyloP_cache = parse_phyloP(variant.seq_id, variant.chr_direction); check_dna_length(len(seq_cache), len(phyloP_cache[0]), variant)
						value = calculate_dna_conservation(variant, phyloP_cache, feature)

					#RNA secondary structure (RSS)
					elif feature.get_feature_offset() == features.RSS_OFFSET:
						if rss_cache is None: rss_cache = parse_rss(variant.seq_id, variant.chr_direction); check_dna_length(len(seq_cache), len(rss_cache[0]), variant)
						value = calculate_rss(variant, rss_cache, feature)

					#calculate RSS for SNP
					elif feature.feature == features.CALC_RSS_SNP:
						if rss_snp_cache is None: rss_snp_cache = parse_rss_snp(variant.seq_id, variant.chr_direction); check_dna_length(len(seq_cache), len(rss_snp_cache[0]), variant)
						dna_position = get_dna_position(variant, rss_snp_cache[1])
						value = rss_snp_cache[0][dna_position]

					#RSS for SNP
					elif feature.feature == features.RSS_SNP:
						if rss_snp_precomputed_cache is None: rss_snp_precomputed_cache = parse_rss_snp_precomputed()
						value = rss_snp_precomputed_cache[variant.chr_info()]

					#HHM
					elif feature.get_feature_offset() in [features.HHM_MM_OFFSET, features.HHM_MI_OFFSET, features.HHM_MD_OFFSET, features.HHM_IM_OFFSET, features.HHM_II_OFFSET, features.HHM_DM_OFFSET, features.HHM_DD_OFFSET, features.HHM_NEFF_OFFSET, features.HHM_NEFF_I_OFFSET, features.HHM_NEFF_D_OFFSET]:
						if hhm_cache is None: hhm_cache = parse_hhm(variant.seq_id)
						check_seq_matrix(variant, hhm_cache)
						value = calculate_hhm_conservation(variant, hhm_cache, feature)

					#HHM score
					elif feature.get_feature_offset() == features.HHM_SCORE_OFFSET:
						if hhm_scores_cache is None: hhm_scores_cache = parse_hhm_scores_datafile()
						value = calculate_hhm_score(variant, hhm_scores_cache, feature)

					#Entropy
					elif feature.get_feature_offset() in [features.SHANNON_ENTROPY_OFFSET, features.PROPERTY_ENTROPY_OFFSET, features.PROPERTY_RELATIVE_ENTROPY_OFFSET, features.VN_ENTROPY_OFFSET, features.RELATIVE_ENTROPY_OFFSET, features.JS_DIVERGENCE_OFFSET, features.SUM_OF_PAIRS_OFFSET]:
						if entropy_cache is None or	entropy_cache_type != feature.get_feature_name_prefix():
							entropy_cache_type = feature.get_feature_name_prefix()
							entropy_cache = parse_entropy(variant.seq_id, entropy_cache_type, path=((features.ENTROPY_NR_X + feature.entropy_path) if feature.entropy_path is not None else features.ENTROPY_NR_30))
						check_seq_matrix(variant, entropy_cache)
						value = calculate_entropy(variant, entropy_cache, feature)

					#AAP
					elif feature.get_feature_offset() in features.AAP_OFFSETS:
						if aap_cache is None: aap_cache = parse_aap_matrix(features.AAP_MATRIX)
						value = calculate_aap(variant, aap_cache, seq_cache, feature)

					#unknown feature
					else:
						print >> sys.stderr, 'ERROR: unknown feature:', feature, feature.get_feature_offset()
						raise ValueError

					entry.append(value)
					if CHECK: print 'F', feature.to_string(True), entry[0]
					if CHECK: print ''

				queries.append(line.strip())
				labels.append(label_method(variant))
				data.append(entry)
			except Exception:
				print >> sys.stderr, 'ERROR: COULD NOT CALCULATE FEATURES:', line.strip()
				exc_type, exc_value, exc_traceback = sys.exc_info()
				print >> sys.stderr, ' '.join(traceback.format_exception(exc_type, exc_value, exc_traceback))
				if not ignore_failure: raise ValueError

	if CHECK: print '--\n'

	if len(queries) != len(labels) or len(queries) != len(data):
		print >> sys.stderr, 'ERROR: COULD NOT CALCULATE FEATURES: unexpected error.'
		raise ValueError

	return queries, labels, data

def check_dna_length(protein_len, dna_len, variant):
	length_check = abs((protein_len + 1)*3 - dna_len)
	if length_check > 1:
		print >> sys.stderr, 'ERROR: DNA/protein length mismatch: ', protein_len, dna_len, variant
		raise ValueError
	if length_check > 0 and PRINT_WARNINGS:
		print >> sys.stderr, 'WARNING: DNA/protein mismatch: ', protein_len, dna_len, variant

'''def calculate_stop_codon(variant, feature):
	if not feature.get_feature_name().startswith(features.NONSTOP_DECAY_STR):
		raise ValueError
	if variant.mutated[-1] not in '*!': raise ValueError
	return 1 if variant.mutated[-1] == '*' else 0'''

def calculate_kaks(variant, kaks_data, ccds2seq_map, feature):
	if not feature.get_feature_name().startswith(features.KAKS_STR):
		raise ValueError
	ens_transcript_ids = get_ensembl_transcript_ids(variant.seq_id, ccds2seq_map)
	for t_id in ens_transcript_ids:
		if t_id in kaks_data:
			if feature.feature == features.KAKS_AVG:
				four_species_kaks = exclude_nones([kaks_data[t_id].get('MUS'), kaks_data[t_id].get('RNO'), kaks_data[t_id].get('MMU'), kaks_data[t_id].get('PTR')])
				kaks = mean(four_species_kaks) if len(four_species_kaks) != 0 else None
				break
			elif feature.feature == features.KAKS_MOUSE_CHIMP_AVG:
				two_species_kaks = exclude_nones([kaks_data[t_id].get('MUS'), kaks_data[t_id].get('PTR')])
				kaks = mean(two_species_kaks) if len(two_species_kaks) != 0 else None
				break
			elif feature.feature == features.KAKS_MOUSE: kaks = kaks_data[t_id].get('MUS'); break
			elif feature.feature == features.KAKS_RAT: kaks = kaks_data[t_id].get('RNO'); break
			elif feature.feature == features.KAKS_MACAQUE: kaks = kaks_data[t_id].get('MMU'); break
			elif feature.feature == features.KAKS_CHIMP: kaks = kaks_data[t_id].get('PTR'); break
			else: raise ValueError
	return kaks if kaks is not None else -1.0

def calculate_disorder(variant, matrix, feature):
	if not feature.get_feature_name().startswith(features.DISORDER_STR):
		raise ValueError
	values = [x[P_D] for x in matrix]
	return calculate_feature(variant, values, feature.get_feature_type(), feature.win_type, feature.win_len, feature.threshold)

def update_aap_id(aap_id, aa_left, aa_right):
	if aap_id == features.AAP_FLEX_OFFSET / 1000:
		rigid_AA = ['W', 'C', 'F', 'I', 'Y', 'V', 'L', 'H', 'M', 'A', 'T']
		rigid_count = 0
		if aa_left in rigid_AA:
			rigid_count += 1
		if aa_right in rigid_AA:
			rigid_count += 1

		if rigid_count == 0:
			aap_id_new = features.AAP_FLEX_OFFSET / 1000
		elif rigid_count == 1:
			aap_id_new = features.AAP_FLEX_ONE_RIGID_NEIGHB
		elif rigid_count == 2:
			aap_id_new = features.AAP_FLEX_TWO_RIGID_NEIGHB
		else:
			raise ValueError
	else:
		aap_id_new = aap_id
	return aap_id_new

def get_aap_values(matrix, aap_id, seq, context_left=None, context_right=None):
	if len(seq) == 0: return -1.0 #NS mutation
	if context_left == None: context_left = ''
	if context_right == None: context_right = ''
	full_seq = context_left + seq + context_right

	values = []
	for i in range(len(full_seq)):
		aap_id_new = update_aap_id(aap_id, full_seq[i-1] if i > 0 else None, full_seq[i+1] if i < len(full_seq)-1 else None)
		values.append(matrix[aap_id_new][full_seq[i]])

	return values[len(context_left):len(full_seq)-len(context_right)]

def get_aa_safe(sequence, position):
	if position > 0 and position < len(sequence):
		return sequence[position]
	else:
		return None

def calculate_aap(variant, matrix, sequence, feature):
	if not feature.get_feature_name().startswith(features.AAP_STR):	raise ValueError
	if feature.win_type != features.WIN_5: raise ValueError
	aap_id = int(feature) / 1000
	ref_mut_delta = ((int(feature) % 100) / 10) * 10
	if ref_mut_delta in [features.REF_OFFSET, features.DELTA_OFFSET]:
		values  = get_aap_values(matrix, aap_id, sequence)
		ref = calculate_feature(variant, values, feature.get_feature_type(), feature.win_type, feature.win_len, feature.threshold)
	if ref_mut_delta in [features.MUT_OFFSET, features.DELTA_OFFSET]:
		if variant.type == NFS_INDEL:
			reference, mutated, position = strip_variant_x(variant.reference, variant.mutated, variant.position, variant.type, strict_padding=False)
			#insertion
			if len(reference) == 0:
				mutated_values = get_aap_values(matrix, aap_id, mutated, get_aa_safe(sequence, position-1), get_aa_safe(sequence, position))
			#deletion
			else:
				left_boundary = get_aa_safe(sequence, position-1)
				right_boundary = get_aa_safe(sequence, position+len(reference))
				mutated_boundary = (left_boundary if left_boundary is not None else '') + (right_boundary if right_boundary is not None else '')
				mutated_values = get_aap_values(matrix, aap_id, mutated_boundary, get_aa_safe(sequence, position-2), get_aa_safe(sequence, position+len(reference)+1))
		# MS, SL, FS, or NS variant
		else:
			mutated_values = get_aap_values(matrix, aap_id, variant.mutated.strip('!'), get_aa_safe(sequence, variant.position-1), get_aa_safe(sequence, variant.position+1) if variant.type != FS_INDEL else None)
		mut = calculate_from_values(mutated_values, feature.get_feature_type(), 0, len(mutated_values), feature.threshold)
	if ref_mut_delta == features.REF_OFFSET:
		return ref
	elif ref_mut_delta == features.MUT_OFFSET:
		return mut
	elif ref_mut_delta == features.DELTA_OFFSET:
		return mut - ref
	else:
		raise ValueError

def calculate_entropy(variant, matrix, feature):
	if not (feature.get_feature_name().startswith(features.SHANNON_ENTROPY_STR) or feature.get_feature_name().startswith(features.PROPERTY_ENTROPY_STR) or feature.get_feature_name().startswith(features.PROPERTY_RELATIVE_ENTROPY_STR) or feature.get_feature_name().startswith(features.VN_ENTROPY_STR) or feature.get_feature_name().startswith(features.RELATIVE_ENTROPY_STR) or feature.get_feature_name().startswith(features.JS_DIVERGENCE_STR) or feature.get_feature_name().startswith(features.SUM_OF_PAIRS_STR)):
		raise ValueError
	values = [x[ENTROPY] for x in matrix]
	return calculate_feature(variant, values, feature.get_feature_type(), feature.win_type, feature.win_len, feature.threshold)

def get_aa_log_odd(matrix_row, aa, scale_position_specific=False):
	MIN_POSSIBLE_LOG_ODD = -12
	if scale_position_specific:
		max_log = max([matrix_row[1][x] for x in AMINO_ACIDS]) - MIN_POSSIBLE_LOG_ODD
		if max_log == 0: max_log = 1 #hack :-(
	return (matrix_row[1][aa] / 13.0) if not scale_position_specific else ((matrix_row[1][aa]-MIN_POSSIBLE_LOG_ODD) / float(max_log))

def calculate_pssm_conservation(variant, matrix, blosum, feature):
	if not feature.get_feature_name().startswith(features.PSSM_STR):
		raise ValueError
	feature_offset = feature.get_feature_offset()
	if feature.feature == features.PSSM_CONS_DELTA:
		return get_pssm_information_content_change(variant, matrix)
	elif feature_offset == features.PSSM_CONS_OFFSET:
		values = [get_pssm_conservation(variant.seq_id, x, blosum) for x in matrix]
		return calculate_feature(variant, values, feature.get_feature_type(), feature.win_type, feature.win_len, feature.threshold)
	elif feature_offset in features.PSSM_LOG_OFFSETS+features.PSSM_LOG_SCALED_OFFSETS:
		scale_position_specific = True if feature_offset in features.PSSM_LOG_SCALED_OFFSETS else False
		ref_mut_delta = ((int(feature) % 100) / 10) * 10

		if ref_mut_delta in [features.REF_OFFSET, features.DELTA_OFFSET] or variant.type != MISSENSE:
			values = [get_aa_log_odd(x, x[0], scale_position_specific) for x in matrix]
			ref = calculate_feature(variant, values, feature.get_feature_type(), feature.win_type, feature.win_len, feature.threshold)

		#features.MUT_OFFSET and features.DELTA_OFFSET are defined only for MISSENSE
		if variant.type != MISSENSE:
			return ref
		else:
			if ref_mut_delta in [features.MUT_OFFSET, features.DELTA_OFFSET]:
				mut = get_aa_log_odd(matrix[variant.position], variant.mutated, scale_position_specific)

			if ref_mut_delta == features.REF_OFFSET:
				return ref
			elif ref_mut_delta == features.MUT_OFFSET:
				return mut
			elif ref_mut_delta == features.DELTA_OFFSET:
				return mut - ref
			else:
				raise ValueError
	else:
		raise ValueError

def calculate_hhm_conservation(variant, matrix, feature):
	if not feature.get_feature_name().startswith('hhm'):
		raise ValueError
	values = [x[HHM_STATES][get_hhm_column(feature)] for x in matrix]
	return calculate_feature(variant, values, feature.get_feature_type(), feature.win_type, feature.win_len, feature.threshold)

def calculate_asa(variant, matrix, feature):
	if not feature.get_feature_name().startswith(features.ASA_STR):
		raise ValueError

	values = [min(1.0, x[ASA]/float(AA_VOLUME_ASA[x[AA]])) for x in matrix]
	return calculate_feature(variant, values, feature.get_feature_type(), feature.win_type, feature.win_len, feature.threshold)

def calculate_ss_probability(variant, matrix, feature):
	if feature.get_feature_name().startswith(features.SHEET_P_STR):
		values = [x[P_E] for x in matrix]
	elif feature.get_feature_name().startswith(features.COIL_P_STR):
		values = [x[P_C] for x in matrix]
	elif feature.get_feature_name().startswith(features.HELIX_P_STR):
		values = [x[P_H] for x in matrix]
	else:
		raise ValueError
	return calculate_feature(variant, values, feature.get_feature_type(), feature.win_type, feature.win_len, feature.threshold)

def calculate_ss_fraction(variant, matrix, feature):
	if feature.get_feature_name().startswith(features.SHEET_FRAC_STR):
		values = [1 if x[SS] == 'E' else 0 for x in matrix]
	elif feature.get_feature_name().startswith(features.COIL_FRAC_STR):
		values = [1 if x[SS] == 'C' else 0 for x in matrix]
	elif feature.get_feature_name().startswith(features.HELIX_FRAC_STR):
		values = [1 if x[SS] == 'H' else 0 for x in matrix]
	else:
		raise ValueError
	return calculate_feature(variant, values, feature.get_feature_type(), feature.win_type, feature.win_len, threshold=0.5)

def get_pssm_conservation_deprecated(matrix_row):
	return sum([ (matrix_row[PSSM][aa] * matrix_row[OBS_PERCENT][aa]) for aa in matrix_row[PSSM].keys() ])

def get_pssm_conservation(seq_id, matrix_row, blosum):
	aa_letters = matrix_row[PSSM].keys()
	s = sum([matrix_row[OBS_PERCENT][aa] for aa in aa_letters])
	freqs = {}
	if s > 0:
		for aa in aa_letters:
			freqs[aa] = matrix_row[OBS_PERCENT][aa] / float(s)
	else:
		blossum_row_sum = sum([blosum[matrix_row[AA]][aa] for aa in aa_letters])
		for aa in aa_letters:
			freqs[aa] = blosum[matrix_row[AA]][aa] / blossum_row_sum

	if str(sum([freqs[aa] for aa in aa_letters])) != '1.0': raise ValueError
	return sum([(matrix_row[PSSM][aa] * freqs[aa]) for aa in aa_letters])

def get_pssm_information_content_change(variant, matrix):
	info_content_change = 0
	reference_info_content = 0
	for i in range(len(matrix)):
		reference_info_content += matrix[i][PSSM][matrix[i][AA]]
		if  i >= variant.position and i < variant.position + get_aa_len(variant.mutated):
			info_content_change += matrix[i][PSSM][matrix[i][AA]] - matrix[i][PSSM][variant.mutated[i - variant.position]]
		elif  i >= variant.position + get_aa_len(variant.mutated):
			info_content_change += matrix[i][PSSM][matrix[i][AA]]

	return info_content_change / float(reference_info_content)

def check_dna_scores_and_coord(direction, scores_and_coord):
	if len(scores_and_coord[0]) != len(scores_and_coord[1]): raise ValueError
	if direction == '+' and len(scores_and_coord[1]) > 1 and scores_and_coord[1][0] >= scores_and_coord[1][1]: raise ValueError
	if direction == '-' and len(scores_and_coord[1]) > 1 and scores_and_coord[1][0] <= scores_and_coord[1][1]: raise ValueError

def calculate_pars_scores(v1_s1):
	values = []
	for v1, s1 in v1_s1:
		if v1 == 0 and s1 == 0:
			values.append(None)
		else:
			values.append(math.log(v1 + 5, 2) - math.log(s1 + 5, 2))
	return values

def calculate_rss(variant, v1_s1_and_coord, feature):
	if not feature.get_feature_name().startswith(features.RSS_STR): raise ValueError
	check_dna_scores_and_coord(variant.chr_direction, v1_s1_and_coord)
	return calculate_feature(variant, calculate_pars_scores(v1_s1_and_coord[0]), feature.get_feature_type(), feature.win_type, feature.win_len, feature.threshold, dna_position=get_dna_position(variant, v1_s1_and_coord[1]))

def calculate_dna_conservation(variant, scores_and_coord, feature):
	if not feature.get_feature_name().startswith(features.DNA_CONS_STR): raise ValueError
	check_dna_scores_and_coord(variant.chr_direction, scores_and_coord)
	return calculate_feature(variant, scores_and_coord[0], feature.get_feature_type(), feature.win_type, feature.win_len, feature.threshold, dna_position=get_dna_position(variant, scores_and_coord[1]))

#returns 0-based position of the chr_reference on a nucleotide sequence in the forward direction
def get_dna_position(variant, chr_coordinates):
	dna_position = None
	for i in range(len(chr_coordinates)):
		if chr_coordinates[i] == variant.chr_position:
			dna_position = i
			break

	if dna_position is None: print >> sys.stderr, 'ERROR:', variant.chr_position; raise ValueError

	if variant.type in [FS_INDEL, NFS_INDEL] and variant.chr_direction == '-':
		dna_position -= (len(variant.chr_reference) - 1)

	return dna_position

def get_impacting_dna_position(dna_position, variant):
	return dna_position if variant.chr_direction == '+' else (dna_position + padding_length(variant.chr_reference, variant.chr_mutated, variant.type))

def get_positions(variant, max_length, dna_position):
	if dna_position is not None:
		position = get_impacting_dna_position(dna_position, variant)
		next_splice = variant.splice_right
		if variant.chr_direction == '-':
			if variant.type in [FS_INDEL, NFS_INDEL]:
				next_splice += (len(variant.chr_reference) - 1)
			next_splice -= padding_length(variant.chr_reference, variant.chr_mutated, variant.type)

		if variant.type == MISSENSE or variant.type == SILENT:
			mutated_end_position = position + 1
		elif get_aa_len(variant.mutated) == 0:
			mutated_end_position = position
		else:
			mutated_end_position = (variant.position + get_aa_len(variant.mutated)) * 3
			if max_length - mutated_end_position <= 3:
				mutated_end_position = max_length
	else:
		position = variant.position
		next_splice = variant.splice_aa_right
		mutated_end_position = position + get_aa_len(variant.mutated)

	return position, mutated_end_position, next_splice

def get_start_end(win_type, variant, max_length, win_len, dna_position=None):

	position, mutated_end_position, next_splice = get_positions(variant, max_length, dna_position)

	if win_type == features.WIN_1:
		return position, max_length

	elif win_type == features.WIN_2:
		return position, mutated_end_position

	elif win_type == features.WIN_3:
		return mutated_end_position, max_length

	elif win_type == features.WIN_4:
		return position, position + next_splice + 1

	elif win_type == features.WIN_5:
		if win_len is None: raise ValueError
		if variant.type == NFS_INDEL or (dna_position is not None and variant.type == FS_INDEL):
			if dna_position is not None:
				reference, mutated, position = strip_variant_x(variant.chr_reference, variant.chr_mutated, position, variant.type)
			else:
				reference, mutated, position = strip_variant_x(variant.reference, variant.mutated, position, variant.type, strict_padding=False)
			#insertion
			if len(reference) == 0:
				return max(position - win_len - 1, 0), position + win_len + 1
			#deletion
			else:
				return max(position - win_len, 0), position + len(reference) + win_len
		elif variant.type == MISSENSE or variant.type == SILENT or (dna_position is not None and variant.type == NONSENSE):
			return max(position - win_len, 0), position + win_len + 1
		#amino acid level feature for FS or NS variant
		else:
			return max(position - win_len, 0), position + win_len

	elif win_type == features.WIN_6:
		return max(position - win_len, 0), max_length

	elif win_type == features.WIN_7:
		return max(position - win_len, 0), position + next_splice + 1

	elif win_type == features.WIN_8:
		return 0, max_length

	else:
		print >> sys.stderr, win_type
		raise ValueError

def calculate_feature(variant, values, feature_type, win_type, win_len, threshold, dna_position=None):
	start, end = get_start_end(win_type, variant, len(values), win_len, dna_position)
	return calculate_from_values(values, feature_type, start, end, threshold)

def calculate_from_values(values, feature_type, start=None, end=None, threshold=None):
	if start == None: start = 0
	if end == None: end = len(values)
	values_w = exclude_nones(values[start : end])
	if CHECK: print 'ALL', ' '.join(map(lambda x: '%.5f'%x, values))
	if CHECK: print 'WIN_'+str(start)+'-'+str(end), ' '.join(map(lambda x: '%.5f'%x, values_w))
	if len(values_w) == 0:
		return 0.0
	elif feature_type == features.MEAN:
		return mean(values_w)
	elif feature_type == features.MIN:
		return min(values_w)
	elif feature_type == features.MAX:
		return max(values_w)
	elif feature_type in [features.TOA, features.TOR, features.TOG]:
		thr_occurence_abs = sum([1 if value > threshold else 0 for value in values_w])
		if feature_type == features.TOA:
			return thr_occurence_abs
		elif feature_type == features.TOR:
			return (thr_occurence_abs / float(len(values_w)))
		elif feature_type == features.TOG:
			thr_occurence_global = sum([1 if value > threshold else 0 for value in exclude_nones(values)])
			return (thr_occurence_abs / float(thr_occurence_global)) if thr_occurence_global != 0 else 0.0
		else:
			raise ValueError
	else:
		raise ValueError

def padding_length(chr_reference, chr_mutated, variant_type):
	if variant_type in [NONSENSE, MISSENSE, SILENT]:
		if chr_reference == chr_mutated or len(chr_reference) != 1 or len(chr_mutated) != 1:
			raise ValueError
		else:
			return 0
	else:
		#deletion
		if chr_reference.endswith(chr_mutated):
			return len(chr_mutated)
		#insertion
		elif chr_mutated.endswith(chr_reference):
			return len(chr_reference)
		else: raise ValueError

def strip_variant_x(reference, mutated, position, variant_type, strict_padding=True, allow_complex_change=False):
	if variant_type in [NONSENSE, MISSENSE, SILENT]:
		if len(reference) != 1 or len(mutated) != 1:
			raise ValueError
	else:
		#deletion (strict post-padding enforced on DNA indel)
		if reference.endswith(mutated):
			reference = reference[:-len(mutated)]
			mutated = ''
		#deletion (for amino acid level, pre-padding is acceptable)
		elif not strict_padding and reference.startswith(mutated):
			position += len(mutated)
			reference = reference[len(mutated):]
			mutated = ''
		#insertion (strict post-padding enforced on DNA indel)
		elif mutated.endswith(reference):
			mutated = mutated[:-len(reference)]
			reference = ''
		#insertion (for amino acid level, pre-padding is acceptable)
		elif not strict_padding and mutated.startswith(reference):
			position += len(reference)
			mutated = mutated[len(reference):]
			reference = ''
		#complex change
		else:
			if not strict_padding or allow_complex_change:
				pass # => len(reference) > 0 and len(mutated) > 0
			else:
				raise ComplexChangeVariantException

	return reference, mutated, position

class ComplexChangeVariantException(Exception):
	pass

def get_hhm_column(feature):
	feature_name = feature.get_feature_name()
	return HHM_STATES_NAMES[feature_name[:feature_name.rfind('_')]]

def exclude_nones(list_with_nones):
	return filter(lambda x: x is not None, list_with_nones)

def calculate_features_with_multiple_transcripts(variant, feature, ccds_data, transcripts, ccds_nucleotides=None, ccds_proteins=None, ccds_exceptions=None, ccds2seq_map=None, utr_data=None, only_one_transcript=False):
	if only_one_transcript:
		for t in transcripts:
			if t.ccds_id == variant.seq_id:
				transcripts = [t]
				break
		if len(transcripts) != 1 or transcripts[0].ccds_id != variant.seq_id: raise ValueError

	chr_reference_stripped, chr_mutated_stripped, chr_position_stripped = strip_variant_x(variant.chr_reference, variant.chr_mutated, variant.chr_position, variant.type)
	affected_transcripts = get_affected_transcripts(transcripts, variant.chr_position, variant.chr_position + max(0, len(chr_reference_stripped) - 1))

	if feature.get_feature_offset() == features.UNAFFECTED_TRANSCRIPTS_OFFSET:
		return calculate_unaffected_transcripts(variant, feature, ccds_data, transcripts, affected_transcripts, ccds2seq_map, utr_data, ccds_nucleotides, ccds_proteins, ccds_exceptions)

	elif feature.get_feature_offset() == features.NUM_EXONS_OFFSET:
		return calculate_from_values(map_transcripts(get_exon_count, transcripts), feature.get_feature_type())

	elif feature.get_feature_offset() == features.EXON_NUM_ABS_OFFSET:
		return calculate_from_values(map_transcripts(get_exon_num, affected_transcripts, variant.chr_position), feature.get_feature_type())

	elif feature.get_feature_offset() == features.EXON_NUM_REL_OFFSET:
		return calculate_from_values(map_transcripts(get_exon_num_relative, affected_transcripts, variant.chr_position), feature.get_feature_type())

	elif feature.get_feature_offset() == features.SPLICE_LEFT_OFFSET:
		return calculate_from_values(map_transcripts(next_left_splice, affected_transcripts, variant), feature.get_feature_type())

	elif feature.get_feature_offset() == features.SPLICE_RIGHT_OFFSET:
		return calculate_from_values(map_transcripts(next_right_splice, affected_transcripts, variant), feature.get_feature_type())

	elif feature.get_feature_offset() == features.SPLICE_CLOSEST_OFFSET:
		return calculate_from_values(map_transcripts(closest_splice, affected_transcripts, variant), feature.get_feature_type())

	elif feature.get_feature_offset() == features.LOCATION_N_REL_OFFSET:
		return calculate_from_values(map_transcripts(location_N_relative, affected_transcripts, variant), feature.get_feature_type())

	elif feature.get_feature_offset() == features.LOCATION_N_ABS_OFFSET:
		return calculate_from_values(map_transcripts(location_N, affected_transcripts, variant), feature.get_feature_type())

	elif feature.get_feature_offset() == features.LOCATION_C_REL_OFFSET:
		return calculate_from_values(map_transcripts(location_C_relative, affected_transcripts, variant), feature.get_feature_type())

	elif feature.get_feature_offset() == features.LOCATION_C_ABS_OFFSET:
		return calculate_from_values(map_transcripts(location_C, affected_transcripts, variant), feature.get_feature_type())

	elif feature.get_feature_offset() == features.LOCATION_CENTRED_OFFSET:
		return calculate_from_values(map_transcripts(location_centred, affected_transcripts, variant), feature.get_feature_type())

	elif feature.get_feature_offset() == features.LENGTH_SEQ_REL_OFFSET:
		return calculate_from_values(map_transcripts(mutated_protein_length_relative, affected_transcripts, variant, ccds_nucleotides, ccds_proteins, ccds_exceptions), feature.get_feature_type())

	elif feature.get_feature_offset() == features.LENGTH_SEQ_ABS_OFFSET:
		return calculate_from_values(map_transcripts(mutated_protein_length, affected_transcripts, variant, ccds_nucleotides, ccds_proteins, ccds_exceptions), feature.get_feature_type())

	elif feature.get_feature_offset() == features.MUTATED_SEQ_REL_OFFSET:
		return calculate_from_values(map_transcripts(mutated_tail_length_relative, affected_transcripts, variant, ccds_nucleotides, ccds_proteins, ccds_exceptions), feature.get_feature_type())

	elif feature.get_feature_offset() == features.MUTATED_SEQ_ABS_OFFSET:
		return calculate_from_values(map_transcripts(mutated_tail_length, affected_transcripts, variant, ccds_nucleotides, ccds_proteins, ccds_exceptions), feature.get_feature_type())

	else: raise ValueError

def map_transcripts(method, transcripts, *args):
	return [method(t, *args) for t in transcripts]

def get_nu_seq(transcript, variant, ccds_nucleotides):
	nu_seq = str(ccds_nucleotides[transcript.ccds_id].seq)
	dna_position = get_dna_position(variant, get_chr_coordinates_for_nucleotide(transcript))
	check_nu_seq_with_reference(nu_seq, dna_position, transcript, variant)
	return nu_seq

def get_protein_seq(transcript, variant, ccds_proteins):
	protein_seq = str(ccds_proteins[transcript.ccds_id].seq)
	if variant is not None: check_protein_seq_with_reference(protein_seq, variant)
	return protein_seq

def check_nu_seq_with_reference(nu_seq, dna_position, transcript, variant):
	if transcript.cds_strand == '-' and next_left_splice(transcript, variant) == 0:
		chr_reference, chr_mutated, chr_position = strip_variant_x(variant.chr_reference, variant.chr_mutated, variant.chr_position, variant.type)
		dna_position += padding_length(variant.chr_reference, variant.chr_mutated, variant.type)
	else:
		chr_reference = variant.chr_reference

	if (chr_reference if variant.chr_direction == '+' else reverse_dna_seq(chr_reference)) != nu_seq[dna_position:dna_position + len(chr_reference)]:
		print >> sys.stderr, variant, nu_seq[dna_position:dna_position + len(chr_reference)], dna_position, transcript.ccds_id
		raise ValueError

def check_protein_seq_with_reference(protein_seq, variant):
	if variant.reference.strip('*') != protein_seq[variant.position:variant.position + len(variant.reference)]:
		print >> sys.stderr, variant, protein_seq[variant.position:variant.position + len(variant.reference)]
		raise ValueError

def mutated_protein_length(transcript, variant, ccds_nucleotides, ccds_proteins, ccds_exceptions):
	mutated_aa_seq = get_mutated_aa_seq(transcript, ccds_nucleotides, ccds_proteins, ccds_exceptions, variant)
	return get_aa_len(mutated_aa_seq)

def mutated_protein_length_relative(transcript, variant, ccds_nucleotides, ccds_proteins, ccds_exceptions):
	reference_aa_seq = get_protein_seq(transcript, variant if variant.is_transcript(transcript) else None, ccds_proteins)
	return min(mutated_protein_length(transcript, variant, ccds_nucleotides, ccds_proteins, ccds_exceptions) / float(get_aa_len(reference_aa_seq)), 1.0)

def mutated_tail_length(transcript, variant=None, ccds_nucleotides=None, ccds_proteins=None, ccds_exceptions=None, reference_aa_seq=None, mutated_aa_seq=None):
	if reference_aa_seq is None and mutated_aa_seq is None:
		reference_aa_seq = get_protein_seq(transcript, variant if variant.is_transcript(transcript) else None, ccds_proteins)
		mutated_aa_seq = get_mutated_aa_seq(transcript, ccds_nucleotides, ccds_proteins, ccds_exceptions, variant)

	return get_aa_len(mutated_aa_seq) - mutation_aa_position(reference_aa_seq, mutated_aa_seq)

def mutated_tail_length_relative(transcript, variant, ccds_nucleotides, ccds_proteins, ccds_exceptions):
	reference_aa_seq = get_protein_seq(transcript, variant if variant.is_transcript(transcript) else None, ccds_proteins)
	mutated_aa_seq = get_mutated_aa_seq(transcript, ccds_nucleotides, ccds_proteins, ccds_exceptions, variant)
	reference_tail_length = float(get_aa_len(reference_aa_seq) - mutation_aa_position(reference_aa_seq, mutated_aa_seq))

	return (min(mutated_tail_length(transcript, reference_aa_seq=reference_aa_seq, mutated_aa_seq=mutated_aa_seq) / reference_tail_length, 1.0)) if reference_tail_length != 0 else 0.0

def mutation_aa_position(reference_aa_seq, mutated_aa_seq, ccds_id=None, ccds_exceptions=None):
	has_U, different_M = get_ccds_exceptions(ccds_id, ccds_exceptions)
	for aa_position in range(1 if different_M else 0, min(get_aa_len(reference_aa_seq), get_aa_len(mutated_aa_seq))):
		if has_U and reference_aa_seq[aa_position] == 'U' and mutated_aa_seq[aa_position] == '*': continue
		if reference_aa_seq[aa_position] != mutated_aa_seq[aa_position]:
			break
	if reference_aa_seq[aa_position] == mutated_aa_seq[aa_position]:
		if aa_position != min(get_aa_len(reference_aa_seq), get_aa_len(mutated_aa_seq)) - 1: raise ValueError
		aa_position += 1
	return aa_position

def get_ccds_exceptions(ccds_id, ccds_exceptions):
	if ccds_id is not None and ccds_exceptions is not None:
		return ccds_id in ccds_exceptions[SELENOCYSTEINE], ccds_id in ccds_exceptions[INITIATION_CODON]
	return False, False

#N terminus is the start of the protein
def location_N(transcript, variant):
	return get_impacting_dna_position(get_dna_position(variant, get_chr_coordinates_for_nucleotide(transcript)), variant)

def location_N_relative(transcript, variant):
	return location_N(transcript, variant) / float(get_nucleotide_len(transcript))

#C terminus is the end of the protein
def location_C(transcript, variant):
	ref, mut, chr_position = strip_variant_x(variant.chr_reference, variant.chr_mutated, variant.chr_position, variant.type)
	return get_nucleotide_len(transcript) - (location_N(transcript, variant) + len(ref)) #len(ref) is zero in case of insertion

def location_C_relative(transcript, variant):
	return location_C(transcript, variant) / float(get_nucleotide_len(transcript))

#ranges in [0.0, ~0.5], values close to 0.0 mean that the chr_position is close to the beginning or end of the sequence
def location_centred(transcript, variant):
	return min(location_N_relative(transcript, variant), location_C_relative(transcript, variant))

def get_exon_num_relative(transcript, chr_position):
	return get_exon_num(transcript, chr_position) / float(get_exon_count(transcript))

def closest_splice(transcript, variant=None, chr_position=None, exon_num=None):
	next_left, next_right = next_splice(transcript, variant, chr_position, exon_num)
	return min(next_left, next_right)

def next_right_splice(transcript, variant=None, chr_position=None, exon_num=None):
	return next_splice(transcript, variant, chr_position, exon_num)[1]

def next_left_splice(transcript, variant=None, chr_position=None, exon_num=None):
	return next_splice(transcript, variant, chr_position, exon_num)[0]

#returns the distance to the left intron and to the right intron on a positive strand
def next_splice(transcript, variant=None, chr_position=None, exon_num=None):
	if (chr_position is None and variant is None) or (chr_position is not None and variant is not None): raise ValueError

	if chr_position is None:
		ref, mut, chr_position = strip_variant_x(variant.chr_reference, variant.chr_mutated, variant.chr_position, variant.type)
		chr_position_to_start = chr_position - 1 #chr_position is 1-based
		chr_position_to_end = chr_position - 1 + (len(ref) - 1) #len(ref) is zero in case of insertion
	else:
		#chr_position is 1-based
		chr_position_to_start = chr_position - 1
		chr_position_to_end = chr_position - 1

	#get_exon_num takes 1-based chr_position
	if exon_num is None: exon_num = get_exon_num(transcript, chr_position)
	start, end = get_exon_start_end(transcript, exon_num)
	to_end = end - chr_position_to_end
	to_start = chr_position_to_start - start
	if start >= end or to_end < 0 or to_start < 0: print >> sys.stderr, start, end, to_start, to_end, variant, chr_position, exon_num; raise ValueError

	if transcript.cds_strand == '+':
		return to_start, to_end
	else:
		return to_end, to_start

def calculate_unaffected_transcripts(variant, feature, ccds_data, transcripts, affected_transcripts, ccds2seq_map, utr_data, ccds_nucleotides, ccds_proteins, ccds_exceptions):
	if CHECK: print 'number of transcripts:', len(transcripts)
	if feature.feature == features.NUM_TRANSCRIPTS:
		return len(transcripts)

	elif feature.feature == features.UNAFFECTED_TRANSCRIPTS_ABS:
		return len(transcripts) - len(affected_transcripts)

	elif feature.feature == features.UNAFFECTED_TRANSCRIPTS_REL:
		return (len(transcripts) - len(affected_transcripts)) / float(len(transcripts))

	elif feature.feature == features.NO_NONSTOP_DECAY_ABS:
		return transcripts_without_nonstop_decay_count(variant, transcripts, affected_transcripts, ccds_nucleotides, ccds_proteins, ccds_exceptions)

	elif feature.feature == features.NO_NONSTOP_DECAY_REL:
		return transcripts_without_nonstop_decay_relative(variant, transcripts, affected_transcripts, ccds_nucleotides, ccds_proteins, ccds_exceptions)

	elif feature.feature == features.NO_NONSENSE_DECAY_ABS:
		return transcripts_without_nonsense_decay_count(variant, transcripts, affected_transcripts, ccds2seq_map, utr_data, ccds_nucleotides, ccds_proteins, ccds_exceptions)

	elif feature.feature == features.NO_NONSENSE_DECAY_REL:
		return transcripts_without_nonsense_decay_relative(variant, transcripts, affected_transcripts, ccds2seq_map, utr_data, ccds_nucleotides, ccds_proteins, ccds_exceptions)

	elif feature.feature == features.NO_NONSTOP_NONSENSE_DECAY_ABS:
		return transcripts_without_nonstop_nonsense_decay_count(variant, transcripts, affected_transcripts, ccds2seq_map, utr_data, ccds_nucleotides, ccds_proteins, ccds_exceptions)

	elif feature.feature == features.NO_NONSTOP_NONSENSE_DECAY_REL:
		return transcripts_without_nonstop_nonsense_decay_relative(variant, transcripts, affected_transcripts, ccds2seq_map, utr_data, ccds_nucleotides, ccds_proteins, ccds_exceptions)

	else: raise ValueError

def transcripts_without_nonstop_decay_count(variant, transcripts, affected_transcripts, ccds_nucleotides, ccds_proteins, ccds_exceptions):
	nonstop_decay_transcripts = get_nonstop_decay_transcripts(variant, affected_transcripts, ccds_nucleotides, ccds_proteins, ccds_exceptions)
	return len(transcripts) - len(nonstop_decay_transcripts)

def transcripts_without_nonstop_decay_relative(variant, transcripts, affected_transcripts, ccds_nucleotides, ccds_proteins, ccds_exceptions):
	return transcripts_without_nonstop_decay_count(variant, transcripts, affected_transcripts, ccds_nucleotides, ccds_proteins, ccds_exceptions) / float(len(transcripts))

def transcripts_without_nonsense_decay_count(variant, transcripts, affected_transcripts, ccds2seq_map, utr_data, ccds_nucleotides, ccds_proteins, ccds_exceptions):
	nonsense_decay_transcripts = get_nonsense_decay_transcripts(variant, affected_transcripts, ccds2seq_map, utr_data, ccds_nucleotides, ccds_proteins, ccds_exceptions)
	return len(transcripts) - len(nonsense_decay_transcripts)

def transcripts_without_nonsense_decay_relative(variant, transcripts, affected_transcripts, ccds2seq_map, utr_data, ccds_nucleotides, ccds_proteins, ccds_exceptions):
	return transcripts_without_nonsense_decay_count(variant, transcripts, affected_transcripts, ccds2seq_map, utr_data, ccds_nucleotides, ccds_proteins, ccds_exceptions) / float(len(transcripts))

def transcripts_without_nonstop_nonsense_decay_count(variant, transcripts, affected_transcripts, ccds2seq_map, utr_data, ccds_nucleotides, ccds_proteins, ccds_exceptions):
	nonstop_decay_transcripts = get_nonstop_decay_transcripts(variant, affected_transcripts, ccds_nucleotides, ccds_proteins, ccds_exceptions)
	nonsense_decay_transcripts = get_nonsense_decay_transcripts(variant, affected_transcripts, ccds2seq_map, utr_data, ccds_nucleotides, ccds_proteins, ccds_exceptions)
	return len(transcripts) - len(nonstop_decay_transcripts) - len(nonsense_decay_transcripts)

def transcripts_without_nonstop_nonsense_decay_relative(variant, transcripts, affected_transcripts, ccds2seq_map, utr_data, ccds_nucleotides, ccds_proteins, ccds_exceptions):
	return transcripts_without_nonstop_nonsense_decay_count(variant, transcripts, affected_transcripts, ccds2seq_map, utr_data, ccds_nucleotides, ccds_proteins, ccds_exceptions) / float(len(transcripts))

def get_nonstop_decay_transcripts(variant, affected_transcripts, ccds_nucleotides, ccds_proteins, ccds_exceptions):
	nonstop_decay_transcripts = []
	for t in affected_transcripts:
		mutated_aa_seq = get_mutated_aa_seq(t, ccds_nucleotides, ccds_proteins, ccds_exceptions, variant)
		if mutated_aa_seq[-1] == '!': nonstop_decay_transcripts.append(t)
		elif mutated_aa_seq[-1] != '*': raise ValueError
	return nonstop_decay_transcripts

def get_mutated_nu_seq(transcript, variant, ccds_nucleotides):
	transcript_nu_seq = get_nu_seq(transcript, variant, ccds_nucleotides)
	dna_position = get_dna_position(variant, get_chr_coordinates_for_nucleotide(transcript))
	mutated_nu_seq = transcript_nu_seq[:dna_position] + (variant.chr_mutated if variant.chr_direction == '+' else reverse_dna_seq(variant.chr_mutated)) + transcript_nu_seq[dna_position + len(variant.chr_reference):]
	return mutated_nu_seq

def get_mutated_aa_seq(transcript, ccds_nucleotides, ccds_proteins, ccds_exceptions, variant):
	transcript_protein_seq = get_protein_seq(transcript, variant if variant.is_transcript(transcript) else None, ccds_proteins)
	mutated_protein_seq = translate_nucleotide_to_protein(get_mutated_nu_seq(transcript, variant, ccds_nucleotides))
	aa_position = mutation_aa_position(transcript_protein_seq, mutated_protein_seq, transcript.ccds_id, ccds_exceptions)
	mutated_aa_tail = mutated_protein_seq[aa_position:]
	if '*' not in mutated_aa_tail: mutated_aa_tail += '!'
	else: mutated_aa_tail = mutated_aa_tail[:mutated_aa_tail.find('*')+1]
	if variant.type in [FS_INDEL, NONSENSE] and variant.is_transcript(transcript) and mutated_aa_tail != variant.mutated: print >> sys.stderr, variant, mutated_aa_tail, aa_position; raise ValueError
	return transcript_protein_seq[:aa_position] + mutated_aa_tail #using transcript_protein_seq[:aa_position] because of special replacements in CCDS (like amino acid U, etc.)

def mutation_aa_position_from_nucleotide_DEPRECATED(reference_aa_seq, mutated_nu_seq):
	for nu_position in range(0, min(len(reference_aa_seq) * 3, len(mutated_nu_seq) - 1), 3):
		if reference_aa_seq[nu_position/3].replace('U', '*') != translate_nucleotide_to_protein(mutated_nu_seq[nu_position:nu_position + 3]):
			break
	if reference_aa_seq[nu_position/3] == translate_nucleotide_to_protein(mutated_nu_seq[nu_position:nu_position + 3]):
		if nu_position != max(range(0, min(len(reference_aa_seq) * 3, len(mutated_nu_seq) - 1), 3)): print >> sys.stderr, nu_position, len(reference_aa_seq), len(mutated_nu_seq); raise ValueError
		nu_position += 3
	return nu_position / 3

def translate_nucleotide_to_protein(nu_sequence):
	from Bio.Alphabet import IUPAC
	from Bio.Seq import Seq
	return str(Seq(nu_sequence, IUPAC.unambiguous_dna).translate())

def get_nonsense_decay_transcripts(variant, affected_transcripts, ccds2seq_map, utr_data, ccds_nucleotides, ccds_proteins, ccds_exceptions):
	nonsense_decay_transcripts = []
	for t in affected_transcripts:
		if CHECK: print '\n', get_nu_seq(t, variant, ccds_nucleotides), t.ccds_id, '\n'
		if CHECK: print get_mutated_nu_seq(t, variant, ccds_nucleotides), t.ccds_id, '\n'
		if CHECK: print get_mutated_aa_seq(t, ccds_nucleotides, ccds_proteins, ccds_exceptions, variant), t.ccds_id, '\n'

		early_stop_codon_position = get_early_stop_codon_position(t, variant, ccds_nucleotides)
		if (early_stop_codon_position is None) != (get_mutated_aa_seq(t, ccds_nucleotides, ccds_proteins, ccds_exceptions, variant)[-1] == '!'): raise ValueError
		if early_stop_codon_position is None: continue #there is no non-stop codon in the mutated sequence (non-stop decay)
		early_stop_codon_chr_position = get_chromosome_coordinate(t, early_stop_codon_position) #1-based nonsense_chr_position
		exon_num = get_exon_num(t, early_stop_codon_chr_position) #exon_num is 1-based
		num_exons = get_exon_count(t)
		if CHECK: print t.ccds_id, '*:', early_stop_codon_position, early_stop_codon_chr_position, 'exon:', exon_num, '/', num_exons

		nmd = False
		#stop-codon in the last CDS exon
		if num_exons - exon_num == 0:
			nmd = False
			if CHECK: print 'LAST EXON'
		#stop-codon in the second last CDS exon, special rules apply
		elif num_exons - exon_num == 1:
			utr_offset = get_utr_ensembl_offset(t, utr_data, ccds2seq_map)
			next_splice = next_right_splice(t, chr_position=early_stop_codon_chr_position, exon_num=exon_num)
			if CHECK: print 'UTR_offset:', utr_offset, 'next_splice:', next_splice, 'last exon length:', exon_length(t, num_exons)
			if utr_offset is None:
				utr_offset = 0
				if PRINT_WARNINGS: print >> sys.stderr, 'WARNING: UTR offset is unknown', variant
			#0 or 1 UTR connected to the last exon
			if utr_offset == 0 and next_splice < 50:
				nmd = False
				if CHECK: print '0 OR 1 UTR & SPLICE < 50'
			#more than 1 UTR (thus, need to add the length of the last exon - the one attached to the first UTR)
			elif utr_offset != 0 and utr_offset + exon_length(t, num_exons) + next_splice < 50:
				nmd = False
				if CHECK: print '>1 UTR & SPLICE < 50'
			else:
				nmd = True
				if CHECK: print 'NMD!!!'
		#stop-codon NOT in the last two CDS exons
		elif num_exons - exon_num > 1:
			nmd = True
			if CHECK: print 'FAR IN'
		else: raise ValueError

		if nmd: nonsense_decay_transcripts.append(t)

	return nonsense_decay_transcripts

def get_early_stop_codon_position(transcript, variant, ccds_nucleotides):
	mutated_nu_seq = get_mutated_nu_seq(transcript, variant, ccds_nucleotides)
	dna_position = get_dna_position(variant, get_chr_coordinates_for_nucleotide(transcript))
	dna_position -= (dna_position % 3) #to get in-frame
	if dna_position % 3 != 0: raise ValueError
	mutated_nu_seq = mutated_nu_seq[dna_position:]
	for i in range(0, len(mutated_nu_seq), 3):
		if mutated_nu_seq[i:i+3] in ['TAA', 'TAG', 'TGA']:
			ref, mut, pos = strip_variant_x(variant.chr_reference, variant.chr_mutated, variant.chr_position, variant.type)
			return dna_position + i + len(ref) - len(mut) #if insertion len(ref) is 0, if deletion len(mut) is 0, if substitution len(ref) - len(mut) is 0
			#the adjustment is made so that dna_position points to TAA/TAG/TGA in the reference sequence for which we have CCDS and UTR entries
	return None

def exon_length(transcript, exon_num):
	start, end = get_exon_start_end(transcript, exon_num)
	if start > end: raise ValueError
	return end - start + 1

#this will return start and end on a positive/negative strand!
def get_exon_start_end(transcript, exon_num):
	locations = transcript.cds_locations[1:-1].split(',')
	if transcript.cds_strand == '-': locations.reverse()
	this_exon = locations[exon_num - 1]
	s, e = map(int, this_exon.split('-'))
	return s, e

#these coordinates are always for the positive strand
def get_chr_coordinates_for_nucleotide(transcript):
	coordinates = []
	for l in transcript.cds_locations[1:-1].split(','):
		s, e = map(int, l.split('-'))
		coordinates += range(s + 1, e + 2) #CCDS is 0-based but chr_position is 1-based
	if transcript.cds_strand == '-': coordinates.reverse()
	return coordinates

def get_nucleotide_len(transcript):
	length = 0
	for l in transcript.cds_locations[1:-1].split(','):
		s, e = map(int, l.split('-'))
		length += (e - s + 1)
	return length

def get_chromosome_coordinate(transcript, nuc_position):
	#this is 1-based chr_position
	return get_chr_coordinates_for_nucleotide(transcript)[nuc_position]

'''def calculate_splice_sites_locations(variant, feature):
	if not feature.get_feature_name().startswith(features.SPLICE_STR):
		raise ValueError
	feature_type = feature.get_feature_type()
	if feature_type == features.LEFT:
		return variant.splice_left
	elif feature_type == features.RIGHT:
		return variant.splice_right
	elif feature_type == features.MIN:
		return min(variant.splice_left, variant.splice_right)
	elif feature_type == features.MAX:
		return max(variant.splice_left, variant.splice_right)
	elif feature_type == 'relleft':
		return variant.splice_left / float(variant.splice_left + variant.splice_right)
	elif feature_type == 'relright':
		return variant.splice_right / float(variant.splice_left + variant.splice_right)
	elif feature_type == 'relleftright':
		return (variant.splice_left / float(variant.splice_right)) if variant.splice_right != 0 else variant.splice_left
	else:
		raise ValueError
	
def calculate_location_length(variant, sequence, feature):
	feature_type = feature.get_feature_type()
	if feature.get_feature_name().startswith(features.LOCATION_N_STR):
		if feature_type == features.ABSOLUTE:
			return variant.position
		elif feature_type == features.RELATIVE:
			return variant.position / float(len(sequence))
		else:
			raise ValueError
	if feature.get_feature_name().startswith(features.LOCATION_C_STR):
		if feature_type == features.ABSOLUTE:
			return len(sequence) - variant.position
		elif feature_type == features.RELATIVE:
			return (len(sequence) - variant.position) / float(len(sequence))
		else:
			raise ValueError
	elif feature.get_feature_name().startswith(features.LENGTH_SEQ_STR):
		if variant.type == NFS_INDEL:
				return len(sequence)
		else:
			if feature_type == features.ABSOLUTE:
				return variant.position + get_aa_len(variant.mutated)
			elif feature_type == features.RELATIVE:
				return (variant.position + get_aa_len(variant.mutated)) / float(len(sequence))
			else:
				raise ValueError
	elif feature.get_feature_name().startswith(features.LENGTH_MUTATED_STR):
		if variant.type == NFS_INDEL:
			return abs(len(variant.reference) - len(variant.mutated))
		else:
			if feature_type == features.ABSOLUTE:
				return get_aa_len(variant.mutated)
			elif feature_type == features.RELATIVE:
				return (get_aa_len(variant.mutated) / float(len(sequence) - variant.position)) if len(sequence) - variant.position != 0 else 1.0
			else:
				raise ValueError
	else:
		raise ValueError'''

def get_aa_len(aa_seq):
	return len(aa_seq.strip('*!'))

def parse_entropy(filename_prefix, score_type, path=features.ENTROPY_NR_30, extension=features.ENTROPY_NR_30_EXT):
	#[ [AA, ENTROPY], ... ]
	return parse_spine_into_matrix(lambda x: [x[1], float(x[2])], lambda x: x[1], os.path.join(path, score_type, filename_prefix + extension))

	'''
	seq = str(parse_fasta_deprecated(filename_prefix).seq)
	matrix_seq = ''.join([x[0] for x in matrix])
	index = seq.find(matrix_seq[:5])
	for i in range(index):
		matrix.insert(i, [seq[i], 0.0])

	if len(seq) > len(matrix):
		offset = len(matrix)
		for i in range(len(seq) - len(matrix)):
			matrix.append([seq[offset+i], 0.0])
			
	for i in range(len(seq)):
		if seq[i] != matrix[i][0]: print >> sys.stderr, 'WRONG PADDING', i, filename_prefix; raise ValueError

	return matrix
	'''

def parse_spine_d(filename_prefix, extension=features.SPINE_D_EXT, path=features.SPINE_D):
	#[ [AA, P_D], ... ]
	return parse_spine_into_matrix(lambda x: [x[0], float(x[2])], lambda x: x[0], os.path.join(path, filename_prefix + extension))

def parse_spine_x(filename_prefix, extension=features.SPINE_X_EXT, path=features.SPINE_X):
	#[ [AA, SS, PHI, PSI, P_E, P_C, P_H, ASA], ... ]
	return parse_spine_into_matrix(lambda x: [x[1], x[2], float(x[3]), float(x[4]), float(x[5]), float(x[6]), float(x[7]), float(x[10])], lambda x: x[1], os.path.join(path, filename_prefix + extension))

def parse_spider(filename_prefix, extension=features.SPIDER_EXT, path=features.SPIDER):
	#[ [AA, SS, PHI, PSI, P_E, P_C, P_H, ASA], ... ]
	return parse_spine_into_matrix(lambda x: [x[1], x[2], float(x[4]), float(x[5]), float(x[9]), float(x[8]), float(x[10]), float(x[3])], lambda x: x[1], os.path.join(path, filename_prefix + extension))

def parse_spine_into_matrix(parse_method, get_aa_method, filename):
	matrix = []
	with open_file(filename, 'r') as f:
		for line in f:
			if line[0] == '#': continue
			line_split = line.strip().split()
			if get_aa_method(line_split) not in AMINO_ACIDS:
				print >> sys.stderr, filename, line
				raise ValueError
			matrix.append(parse_method(line_split))
	return matrix

def parse_phyloP(filename_prefix, direction, extension=features.PHYLOP_EXT, path=features.PHYLOP):
	#[ DNA_CONS, ... ], [ CHR_COORDINATE_1_BASED, ... ]
	if direction not in ['+', '-']: raise ValueError
	scores_list = []
	coordinates_list = []
	with open_file(os.path.join(path, filename_prefix + extension), 'r') as f:
		for line in f:
			if line[0] == '#': continue
			line_split = line.strip().split()
			dna_cons = float(line_split[0])
			coordinate_1based = int(line_split[1])
			if dna_cons == -100.0:
				dna_cons = None
			scores_list.append(dna_cons)
			coordinates_list.append(coordinate_1based)

	if direction == '-':
		scores_list.reverse()
		coordinates_list.reverse()

	return scores_list, coordinates_list

def parse_rss_snp_precomputed(filename='rss_snp_max.dat', path=features.MISSENSE_RSS_DATA):
	rss_data = {}
	with open_file(os.path.join(path, filename), 'r') as f:
		for line in f:
			mutation, rss = line.strip().split()
			if mutation in rss_data: raise ValueError
			rss_data[mutation] = float(rss)
	return rss_data

def parse_rss_snp(filename_prefix, direction, extension=features.RSS_EXT, path=features.MISSENSE_RSS, half_win=2):
	#[ PARS, ... ], [CHR_COORDINATE_1BASED, ... ]
	v1_s1, coordinates_list = parse_rss(filename_prefix, direction, extension, path)
	pars = []
	for i in range(len(v1_s1)):
		s = max(0, i - half_win)
		e = min(i + half_win + 1, len(v1_s1))
		v1, s1 = calculate_v1_s1_nonzero_average(v1_s1[s:e])
		pars.append(math.log(v1 + 5, 2) - math.log(s1 + 5, 2))
	return pars, coordinates_list

def calculate_v1_s1_nonzero_average(v1_s1):
	v_avg, s_avg, divider = 0.0, 0.0, 0
	for v1, s1 in v1_s1:
		if v1 == 0 and s1 == 0: continue
		v_avg += v1
		s_avg += s1
		divider += 1
	v_avg /= float(divider)
	s_avg /= float(divider)
	return v_avg, s_avg

def calculate_v1_s1_max(v1_s1):
	v_max, s_max, max_diff = 0.0, 0.0, 0.0
	for v1, s1 in v1_s1:
		if abs(v1-s1) > max_diff:
			max_diff = abs(v1-s1)
			v_max = v1
			s_max = s1
	return v_max, s_max

def parse_rss(filename_prefix, direction, extension=features.RSS_EXT, path=features.RSS):
	#[ [RSS_V1, RSS_S1], ... ], [CHR_COORDINATE_1BASED, ... ]
	if direction not in ['+', '-']: raise ValueError
	matrix = []
	coordinates_list = []
	with open_file(os.path.join(path, filename_prefix + extension), 'r') as f:
		for line in f:
			if line[0] == '#': continue
			v1, s1, chr_coordinate = map(int, line.strip().split())
			matrix.append([v1, s1])
			coordinates_list.append(chr_coordinate)

	if direction == '-':
		matrix.reverse()
		coordinates_list.reverse()

	return matrix, coordinates_list

def parse_blosum(filename=features.BLOSUM62):
	blosum = {}
	alphabet = None
	with open_file(filename, 'r') as f:
		i = 0
		for line in f:
			if line[0] == '#': continue
			if alphabet is None:
				alphabet = line.strip()
				if len(alphabet) != 20: raise ValueError
			else:
				if i > 19: raise ValueError
				blosum[alphabet[i]] = {}
				line_split = line.strip().split()
				for j in range(len(line_split)):
					if j > 19: raise ValueError
					blosum[alphabet[i]][alphabet[j]] = float(line_split[j])
				i += 1
	return blosum

def parse_pssm(filename_prefix, extension=features.PSSM_EXT, path=features.PSSM_DIR):
	#[ [AA, PSSM_DICT, OBS_PERCENT_DICT, INFO_VALUE, REL_WEIGHT], ... ]
	matrix = []
	with open_file(os.path.join(path, filename_prefix + extension), 'r') as f:
		line_number = 0
		pssm_alphabet = None
		for line in f:
			line_number += 1
			if line_number > 2:
				line_split = line.strip().split()
				if line_number == 3:
					if len(line_split) != 40 or line_split[0:20] != line_split[20:40]:
						raise ValueError
					pssm_alphabet = line_split[0:20]
				elif len(line_split) == 0:
					break
				else:
					aa = line_split[1]
					#if aa not in AMINO_ACIDS: print >> sys.stderr, filename_prefix; raise ValueError
					pssm_dict = {}
					observed_percentage_dict = {}
					for i in range(20):
						pssm_dict[pssm_alphabet[i]] = int(line_split[2 + i])
						observed_percentage_dict[pssm_alphabet[i]] = float(line_split[22 + i])/100.0
					information_value = float(line_split[42])
					relative_weight = float(line_split[43])
					matrix.append([ aa, pssm_dict, observed_percentage_dict, information_value, relative_weight ])
	return matrix

def parse_hhm_scores_datafile(data_filename=os.path.join(features.HHM_SCORES, 'hhm_scores.dat')):
	hhm_scores = {}
	with open_file(data_filename, 'r') as f:
		for line in f:
			wt, mutant, score_wt, score_mutant = line.strip().split()
			if wt not in hhm_scores: hhm_scores[wt] = {}
			if mutant in hhm_scores[wt]: raise ValueError
			hhm_scores[wt][mutant] = [float(score_wt), float(score_mutant)]
	return hhm_scores

def parse_kaks_sift_datafile(data_filename=features.KAKS_SIFT_AVG):
	kaks_data = {}
	with open_file(data_filename, 'r') as f:
		for line in f:
			if line[0] == '#': continue
			ccds_id, kaks = line.strip().split()
			kaks_data[ccds_id] = float(kaks)
	return kaks_data

def parse_kaks_ensembl_datafile(data_filename=features.KAKS_ENSEMBL):
	kaks_data = {}
	quality = {}
	check_t = {}
	check_gene_names = ['CCDC54', 'ARG1', 'NIPA2', 'OR5M1', 'UROD', 'TREX1', 'PLIN1', 'PBOV1', 'OR14C36', 'OR2T11', 'KPRP', 'MTFP1', 'UNC45B', 'NAGLU', 'PTRF', 'GAS2L2']
	with open_file(data_filename, 'r') as f:
		for line in f:
			if line[0] == '#': continue
			line_split = line.strip().split('\t')
			gene_name = line_split[1]
			transcript_id = line_split[2]
			if gene_name in check_gene_names:
				if transcript_id in check_t: raise ValueError
				check_t[transcript_id] = gene_name
				check_gene_names.remove(gene_name)
			species1 = line_split[4][3:6] if len(line_split) > 4 and len(line_split[4]) != 0 else None
			species1_confidence = int(line_split[12]) if len(line_split) > 12 and len(line_split[12]) != 0 else None
			species1_seq_sim = int(line_split[13]) if len(line_split) > 13 and len(line_split[13]) != 0 else None
			species1_ka = float(line_split[15]) if len(line_split) > 15 and len(line_split[15]) != 0 else None
			species1_ks = float(line_split[16]) if len(line_split) > 16 and len(line_split[16]) != 0 else None
			species2 = line_split[17][3:6] if len(line_split) > 17 and len(line_split[17]) != 0 else None
			species2_confidence = int(line_split[25]) if len(line_split) > 25 and len(line_split[25]) != 0 else None
			species2_seq_sim = int(line_split[26]) if len(line_split) > 26 and len(line_split[26]) != 0 else None
			species2_ka = float(line_split[28]) if len(line_split) > 28 and len(line_split[28]) != 0 else None
			species2_ks = float(line_split[29]) if len(line_split) > 29 and len(line_split[29]) != 0 else None
			species3 = line_split[30][3:6] if len(line_split) > 30 and len(line_split[30]) != 0 else None
			species3_confidence = int(line_split[38]) if len(line_split) > 38 and len(line_split[38]) != 0 else None
			species3_seq_sim = int(line_split[39]) if len(line_split) > 39 and len(line_split[39]) != 0 else None
			species3_ka = float(line_split[41]) if len(line_split) > 41 and len(line_split[41]) != 0 else None
			species3_ks = float(line_split[42]) if len(line_split) > 42 and len(line_split[42]) != 0 else None
			species4 = line_split[43][3:6] if len(line_split) > 43 and len(line_split[43]) != 0 else None
			species4_confidence = int(line_split[51]) if len(line_split) > 51 and len(line_split[51]) != 0 else None
			species4_seq_sim = int(line_split[52]) if len(line_split) > 52 and len(line_split[52]) != 0 else None
			species4_ka = float(line_split[54]) if len(line_split) > 54 and len(line_split[54]) != 0 else None
			species4_ks = float(line_split[55]) if len(line_split) > 55 and len(line_split[55]) != 0 else None

			if transcript_id not in kaks_data:
				kaks_data[transcript_id] = {}
				quality[transcript_id] = {}
			if species1 is not None and species1_ks != 0 and species1_ka is not None and species1_ks is not None:
				if species1 not in quality[transcript_id] or quality[transcript_id][species1][0] < species1_confidence or (quality[transcript_id][species1][0] == species1_confidence and quality[transcript_id][species1][1] < species1_seq_sim):
					kaks_data[transcript_id][species1] = species1_ka/species1_ks
					quality[transcript_id][species1] = [species1_confidence, species1_seq_sim]
			if species2 is not None and species2_ks != 0 and species2_ka is not None and species2_ks is not None:
				if species2 not in quality[transcript_id] or quality[transcript_id][species2][0] < species2_confidence or (quality[transcript_id][species2][0] == species2_confidence and quality[transcript_id][species2][1] < species2_seq_sim):
					kaks_data[transcript_id][species2] = species2_ka/species2_ks
					quality[transcript_id][species2] = [species2_confidence, species2_seq_sim]
			if species3 is not None and species3_ks != 0 and species3_ka is not None and species3_ks is not None:
				if species3 not in quality[transcript_id] or quality[transcript_id][species3][0] < species3_confidence or (quality[transcript_id][species3][0] == species3_confidence and quality[transcript_id][species3][1] < species3_seq_sim):
					kaks_data[transcript_id][species3] = species3_ka/species3_ks
					quality[transcript_id][species3] = [species3_confidence, species3_seq_sim]
			if species4 is not None and species4_ks != 0 and species4_ka is not None and species4_ks is not None:
				if species4 not in quality[transcript_id] or quality[transcript_id][species4][0] < species4_confidence or (quality[transcript_id][species4][0] == species4_confidence and quality[transcript_id][species4][1] < species4_seq_sim):
					kaks_data[transcript_id][species4] = species4_ka/species4_ks
					quality[transcript_id][species4] = [species4_confidence, species4_seq_sim]

	if CHECK:
		for t in check_t:
			for s in kaks_data[t]:
				print check_t[t], s, kaks_data[t][s]
		if len(check_gene_names) != 0: raise ValueError
	return kaks_data

def calculate_hhm_score(variant, hhm_scores, feature):
	if not feature.get_feature_name().startswith('hhm_score'):
		raise ValueError
	score_wt, score_mutant = hhm_scores[variant.seq_id][variant.chr_info()]
	return (score_mutant - score_wt)/1000.0

def parse_hhm_score(filename_prefix, extension=features.HHM_SCORES_EXT, path=features.HHM_SCORES):
	with open_file(os.path.join(path, filename_prefix + extension), 'r') as f:
		line_number = 0
		for line in f:
			line_number += 1
			if line_number == 9:
				line_split = line.strip().split()
				if line_split != ['No', 'Hit', 'Prob', 'E-value', 'P-value', 'Score', 'SS', 'Cols', 'Query', 'HMM', 'Template', 'HMM']: raise ValueError
			elif line_number == 10:
				line_split = line.strip().split()
				return float(line_split[5])

def parse_hhm(filename_prefix, extension=features.HHM_EXT, path=features.HHM):
	#[ [AA, HHM_AA_DICT, HHM_STATES_DICT], ... ]
	matrix = []
	with open_file(os.path.join(path, filename_prefix + extension), 'r') as f:
		line_number = None
		alphabet_line = True
		hhm_aa_dict, hhm_states_dict = {}, {}
		for line in f:
			line_split = line.strip().split()
			if line_number is None:
				if line_split[0] == '#': line_number = 0
				else: continue
			else:
				line_number += 1
				if line_number == 1: continue
				elif line_number == 2:
					if len(line_split) != 21: raise ValueError
					hhm_alphabet = line_split[1:21]
				elif line_number == 3:
					if len(line_split) != 10: raise ValueError
					hhm_states = line_split[:]
				elif line_number == 4: continue
				elif line_number > 4:
					if len(line_split) == 0: continue
					elif line_split[0] == '//': break
					else:
						if alphabet_line:
							alphabet_line = False
							aa = line_split[0]
							if aa not in AMINO_ACIDS: raise ValueError
							hhm_aa_dict = {}
							for i in range(20):
								hhm_value = line_split[2 + i]
								hhm_aa_dict[hhm_alphabet[i]] = get_frequency(hhm_value)
						else:
							alphabet_line = True
							hhm_states_dict = {}
							for i in range(10):
								hhm_value = line_split[i]
								hhm_states_dict[hhm_states[i]] = get_frequency(hhm_value)

						if alphabet_line:
							matrix.append([aa, hhm_aa_dict, hhm_states_dict])
				else:
					raise ValueError

	return matrix

def get_frequency(hhm_value):
	return 0.0 if hhm_value == '*' else 2**(int(hhm_value)/-1000.0)

def scale_hhm(hhm_value):
	return 9.999 if hhm_value == '*' else int(hhm_value)/1000.0

def check_seq_matrix(variant, matrix):
	if variant.position < len(matrix):
		for i in range(len(variant.reference.strip('*'))):
			if variant.reference[i] != matrix[variant.position + i][AA]:
				print >> sys.stderr, 'ERROR: Sequence mismatch:', matrix[variant.position + i], variant
				raise ValueError
	else:
		if variant.reference != '*':
			print >> sys.stderr, 'ERROR: Sequence mismatch: matrix length is', len(matrix), 'and variant is', variant
			raise ValueError

def check_seq(variant, sequence, position=None):
	if position is None:
		position = variant.position
	reference = sequence[position : position + len(variant.reference)]
	if variant.reference.strip('*') != reference:
		print >> sys.stderr, 'ERROR: Sequence mismatch:', reference, position, variant
		raise ValueError

def parse_ccds_to_refseq(refseq_data_filename):
	lines = ['#refseq_id ccds_id cds_locations_1based_inclusive refseq_length rna_type alt_ids_list']
	location_pattern = re.compile('^[0-9]+\.\.[0-9]+$')
	join_pattern = re.compile('^join\(([0-9]+\.\.[0-9]+\,?)+\)$')
	with open_file(refseq_data_filename, 'r') as f:
		eoe = False
		in_features = False
		refseq_id, length, rna_type, alt_ids, cds_locations, ccds_id, warning = None, None, None, None, None, None, None
		for line in f:
			try:
				line_split = line.split()
				if len(line_split) > 0:
					if line_split[0] == '//':
						eoe = True
						in_features = False
					elif line_split[0] == 'LOCUS':
						if refseq_id is not None: raise ValueError
						refseq_id = line_split[1]
						length = int(line_split[2])
						rna_type = line_split[4]
					elif line_split[0] == 'ACCESSION':
						if alt_ids is not None: raise ValueError
						alt_ids = line_split[1:]
						if refseq_id in alt_ids: alt_ids.remove(refseq_id)
					elif line_split[0] == 'FEATURES':
						in_features = True
					elif in_features and line_split[0] == 'CDS':
						if cds_locations is not None: raise ValueError
						if location_pattern.match(line_split[1]) is not None:
							s, e = map(int, line_split[1].split('..'))
							cds_locations = '['+str(s)+'-'+str(e)+']'
						elif join_pattern.match(line_split[1]) is not None:
							cds_locations = '['
							locations = line_split[1][5:-1].split(',')
							for l in locations:
								s, e = map(int, l.split('..'))
								cds_locations += str(s)+'-'+str(e)+', '
							cds_locations = cds_locations[:-2] + ']'
						else:
							cds_locations = line_split[1]
							warning = 'WARNING: ' + refseq_id + ' check CDS location.'

					elif line_split[0].startswith('/db_xref="CCDS:'):
						if ccds_id is not None: raise ValueError
						ccds_id = line_split[0][15:-1]

					if eoe:
						if ccds_id is not None:
							lines.append(' '.join([refseq_id, ccds_id, cds_locations, str(length), rna_type] + alt_ids))
							if warning is not None:
								print >> sys.stderr, warning
						refseq_id, length, rna_type, alt_ids, cds_locations, ccds_id, warning = None, None, None, None, None, None, None
						eoe = False

			except Exception:
				exc_type, exc_value, exc_traceback = sys.exc_info()
				print >> sys.stderr, ''.join(traceback.format_exception(exc_type, exc_value, exc_traceback))

	return lines

def parse_refseq_ccds_mapping(refseq_ccds_data_filename):
	data = {}
	with open_file(refseq_ccds_data_filename, 'r') as f:
		for line in f:
			line_split = line.split()
			refseq_id = line_split[0]
			data[refseq_id] = line_split[1:]
	return data

def parse_coding_rss(rss_values, ref_seq_locations):
	cds_rss = []
	values = map(int, rss_values.split(';'))
	locations = map(str.strip, ref_seq_locations[1:-1].split(','))
	for l in locations:
		s, e = map(int, l.split('-'))
		cds_rss.extend(values[s-1:e])
	return cds_rss

def get_xy_ccds_mapping(ccds_list):
	xy_ccds_map = {}
	for ccds in ccds_list:
		if ccds[-1] in 'XY':
			xy_ccds_map[ccds[:-1]] = ccds
	return xy_ccds_map

def parse_rss_for_ccds_list(rss_filename_v1, rss_filename_s1, ccds_list, refseq_data):
	xy_ccds_map = get_xy_ccds_mapping(ccds_list)
	rss = {}
	for ss_type in [RSS_V1, RSS_S1]:
		filename = rss_filename_v1 if ss_type == RSS_V1 else (rss_filename_s1 if ss_type == RSS_S1 else None)
		with open_file(filename, 'r') as f:
			for line in f:
				refseq_id, values = line.split()
				if refseq_id not in refseq_data:
					print >> sys.stderr, 'MISSING:', refseq_id
					continue
				ccds_id = refseq_data[refseq_id][0]
				if ccds_id in xy_ccds_map: ccds_id = xy_ccds_map[ccds_id]
				if ccds_id in ccds_list:
					this_rss = parse_coding_rss(values, refseq_data[refseq_id][1])
					if ccds_id not in rss: rss[ccds_id] = {}
					if ss_type not in rss[ccds_id] or len(filter(lambda x: int(x) != 0, this_rss)) > len(filter(lambda x: int(x) != 0, rss[ccds_id][ss_type])):
						rss[ccds_id][ss_type] = this_rss
	return rss

def parse_mills_neutral(filename):
	lines = ['#chr start_hg18_1based_inclusive end_hg18_1based_inclusive reference mutated']
	with open_file(filename, 'r') as f:
		for line in f:
			if line[0] == '#': continue
			line_split = line.strip().split('\t')
			if line_split[15].lower() != 'inside': continue
			indel_len = int(line_split[2])
			seq = line_split[21].upper()
			if len(seq) != indel_len: raise ValueError
			#type = NFS_INDEL if (indel_len % 3 == 0) else FS_INDEL
			location_hg18 = line_split[1]
			indel_type = line_split[3].upper()
			if indel_type != 'DEL' and indel_type != 'INS': raise ValueError

			chromosome, coordinates = location_hg18.split(':')
			if chromosome[:3].lower() != 'chr': raise ValueError
			chromosome = str(int(chromosome[3:])) if chromosome[3:] not in 'XY' else chromosome[3:]
			s, e = map(int, coordinates.split('-'))
			lines.append(' '.join(['chr' + chromosome	, str(s), str(e), seq if indel_type == 'DEL' else '.', seq if indel_type == 'INS' else '.']))
	return lines

def keep_vcf(dataset, dataset_vcf, vcf_list):
	data = {}
	for line in dataset_vcf:
		line_split = line.strip().split()
		data['_'.join(line_split[:5])] = line_split[7].split(';')[0][4:]

	vcf_list = map(str.split, vcf_list)

	chr_tags = []
	for e in vcf_list:
		chr_tags.append(data['_'.join(e)])

	lines = []
	for line in dataset:
		v = VariantData(line.strip().split())
		if v.chr_info() in chr_tags:
			lines.append(str(v))

	return lines

'''
def calculate_feature_deprecated(variant, values, feature_type, win_type, win_len, threshold, dna=False, dna_position=None, dna_reference=None):
	start, end = get_start_end(win_type, variant, len(values), win_len, dna, dna_position, dna_reference)
	if CHECK: print variant
	if CHECK: print 'ALL', ' '.join(map(lambda x: '%.5f'%x, values))
	return calculate_from_values(values, feature_type, start, end, threshold)
	
def calculate_dna_conservation_deprecated(variant, scores_and_coord, feature):
	if not feature.get_feature_name().startswith(features.DNA_CONS_STR):
		raise ValueError
	if len(scores_and_coord[0]) != len(scores_and_coord[1]): raise ValueError
	
	dna_position, dna_ref = get_dna_pos_dna_ref_deprecated(variant, scores_and_coord[1])
	
	return calculate_feature(variant, scores_and_coord[0], feature.get_feature_type(), feature.win_type, feature.win_len, feature.threshold, dna=True, dna_position=dna_position, dna_reference=dna_ref)

def get_dna_pos_dna_ref_deprecated(variant, chr_coordinates, reverse=True):
	dna_ref, dna_mut, chr_position = strip_variant_x(variant.chr_reference, variant.chr_mutated, variant.chr_position, variant.type)
	dna_position, pre_dna_pos = None, None
	for i in range(len(chr_coordinates)):
		if chr_coordinates[i] == chr_position:
			dna_position = i
			break
		elif chr_coordinates[i] == chr_position - 1:
			pre_dna_pos = i
	if dna_position is None:
		if pre_dna_pos is None:
			print >> sys.stderr, 'ERROR:', variant.seq_id, chr_position, variant
			raise ValueError
		else:
			dna_position = pre_dna_pos
			if PRINT_WARNINGS: print >> sys.stderr, 'WARNING:', 'no dna score at', chr_position, '- using dna score at', chr_position - 1, '- ', variant
	
	if reverse and variant.chr_direction == '-':
		dna_position = len(chr_coordinates) - dna_position - 1
	
	return dna_position, dna_ref

def get_start_end_deprecated(win_type, variant, max_length, win_len, dna=False, dna_position=None, dna_reference=None):
	
	if dna:
		if dna_position is None or dna_reference is None: raise ValueError
		position = dna_position
		next_splice = variant.splice_right
		if get_aa_len(variant.mutated) == 0:
			mutated_end_position = position
		else:
			protein_len = (max_length / 3) - 1
			real_protein_len = len(parse_fasta_deprecated(variant.seq_id).seq)
			if abs(protein_len - real_protein_len) > 1:
				print >> sys.stderr, variant, max_length, real_protein_len
				raise ValueError
			tailing_aa_len = real_protein_len - min(variant.position + get_aa_len(variant.mutated), real_protein_len)
			if tailing_aa_len == 0: #mutation affects all the way to the end of protein
				mutated_end_position = max_length #thus, all the way to the end of dna sequence (including stop-codon)
			else:
				mutated_end_position = max_length - ((tailing_aa_len + 1) * 3)
	else:
		position = variant.position
		next_splice = variant.splice_aa_right
		mutated_end_position = position + get_aa_len(variant.mutated)
	
	start, end = None, None
	
	if win_type == features.WIN_1:
		start, end = position, max_length
		if dna and variant.chr_direction == '-':
			start, end = reverse_dna_start_end_deprecated(start, end, max_length)
		
	elif win_type == features.WIN_2:
		start, end = position, mutated_end_position
		if dna and variant.chr_direction == '-':
			start, end = reverse_dna_start_end_deprecated(start, end, max_length)
	
	elif win_type == features.WIN_3:
		start, end = mutated_end_position, max_length
		if dna and variant.chr_direction == '-':
			start, end = reverse_dna_start_end_deprecated(start, end, max_length)
		
	elif win_type == features.WIN_4:
		start, end = position, position + next_splice + 1
		if dna and variant.chr_direction == '-':
			position = max_length - position - 1
			start, end = max(position - next_splice, 0), position + 1
				
	elif win_type == features.WIN_5:
		if win_len is None: raise ValueError
		if dna or variant.type == NFS_INDEL:
			if dna:
				reference = dna_reference
			elif variant.type == NFS_INDEL:
				reference, mutated, position = strip_variant_x(variant.reference, variant.mutated, position, variant.type, strict_padding=False)
				
			#insertion
			if len(reference) == 0:
				start, end = max(position - win_len - 1, 0), position + win_len + 1
			#deletion or complex change
			else:
				start, end = max(position - win_len, 0), position + len(reference) + win_len
		else:
			start, end = max(position - win_len, 0), position + win_len
	
	elif win_type == features.WIN_6:
		start, end = max(position - win_len, 0), max_length
		if dna and variant.chr_direction == '-':
			start, end = reverse_dna_start_end_deprecated(start, end, max_length)
			
	elif win_type == features.WIN_7:
		start, end = max(position - win_len, 0), position + next_splice + 1
		if dna and variant.chr_direction == '-':
			position = max_length - position - 1
			start, end = max(position - next_splice, 0), position + 1 + win_len
	
	else:
		print >> sys.stderr, win_type
		raise ValueError
	
	return start, end

def reverse_dna_start_end_deprecated(start, end, max_length):
	return max_length - end, max_length - start
'''

def change_padding_vcf_line(vcf_line_split, chromosome_seq, chromosome, do_post_padding=True):
	if vcf_line_split[0] != chromosome: print vcf_line_split[0], chromosome; raise ValueError
	position = int(vcf_line_split[1])
	the_dot = vcf_line_split[2]
	reference = vcf_line_split[3]
	mutated = vcf_line_split[4]
	extras = vcf_line_split[5:]
	if isSNP(reference, mutated):
		reference, mutated, position = strip_snp_ref_mut(reference, mutated, position)
	elif len(reference) > 1 and len(mutated) > 1 and reference[0] == mutated[0] and reference[-1] == mutated[-1]:
		i = 0
		while reference[-(1+i)] == mutated[-(1+i)]:
			i += 1
		i = min(min(len(reference), len(mutated)) - 1, i)
		if reference[-i:] != mutated[-i:]: print >> sys.stderr, chromosome, position, reference, mutated; raise ValueError
		reference = reference[:-i]
		mutated = mutated[:-i]
	return change_padding(chromosome_seq, chromosome, position, reference, mutated, the_dot, extras, do_post_padding)

def change_padding(chromosome_seq, chromosome, position, reference, mutated, the_dot='.', extras=[], do_post_padding=True):
	if chromosome_seq[position-1:position-1+len(reference)] != reference:
		raise ValueError

	if do_post_padding: #changing VCF (1000G) to my format
		#deletion of YZ: XYZ/X --> YZ/- --> YZQ/Q
		if reference.startswith(mutated):
			position += len(mutated)
			reference = reference[len(mutated):]
			mutated = ''
			padding = chromosome_seq[position-1+len(reference)]
		#insertion of YZ X/XYZ --> -/YZ --> Q/YZQ
		elif mutated.startswith(reference):
			position += len(reference)
			mutated = mutated[len(reference):]
			reference = ''
			padding = chromosome_seq[position-1]
		#SNP
		elif len(mutated) == 1 and len(reference) == 1 and mutated != reference:
			padding = ''
		#complex change
		else:
			padding = ''
		reference += padding
		mutated += padding
	else: #changing my format to VCF (1000G)
		#deletion of YZ: YZQ/Q --> YZ/- --> XYZ/X
		if reference.endswith(mutated):
			position -= 1
			reference = reference[:-len(mutated)]
			mutated = ''
			padding = chromosome_seq[position-1]
		#insertion of YZ Q/YZQ --> -/YZ --> X/XYZ
		elif mutated.endswith(reference):
			position -= 1
			mutated = mutated[:-len(reference)]
			reference = ''
			padding = chromosome_seq[position-1]
		#SNP
		elif len(mutated) == 1 and len(reference) == 1 and mutated != reference:
			padding = ''
		#complex change
		else:
			padding = ''
		reference = padding + reference
		mutated = padding + mutated

	if chromosome_seq[position-1:position-1+len(reference)] != reference:
		raise ValueError

	return '\t'.join(['chr' + chromosome.strip('chr'), str(position), the_dot, reference, mutated] + extras)

def parse_vcf_by_chromosome(filename):
	data = {}
	with open_file(filename, 'r') as f:
		for line in f:
			line_split = line.strip().split()
			chrom = line_split[0]
			if chrom not in data: data[chrom] = []
			data[chrom].append(line_split)
	return data

def parse_chromosome_ref_ass_1000G(chromosome, chr_dir):
	with open_file(os.path.join(chr_dir, 'ref_ass_chr'+chromosome), 'r') as f:
		chromosome_seq = f.readline()
	return chromosome_seq

def change_padding_1000G(data_filename, chr_dir, do_post_padding=True):
	lines = []
	data = parse_vcf_by_chromosome(data_filename)
	for chromosome in data.keys():
		chromosome_seq = parse_chromosome_ref_ass_1000G(chromosome, chr_dir)
		for vcf_line_split in data[chromosome]:
			lines.append(change_padding_vcf_line(vcf_line_split, chromosome_seq, chromosome, do_post_padding))
	return lines

def open_file(filename, mode='r', compresslevel=9):
	assert mode in ['r', 'rb', 'a', 'ab', 'w', 'wb']
	if filename.endswith('.gz') or \
			(mode in ['r', 'rb'] and not os.path.exists(filename) and os.path.exists(filename + '.gz')):
		return gzip.open(filename if filename.endswith('.gz') else filename + '.gz', mode, compresslevel)
	else:
		return open(filename, mode)

def parse_af(filename):
	af = {}
	with open_file(filename, 'r') as f:
		for line in f:
			if line[0] == '#': continue
			line_split = line.strip().split()
			af[line_split[0]] = float(line_split[1])
	return af

def isDNA(dna):
	for base in dna:
		if base.upper() not in 'ACGT':
			return False
	return True

def parse_user_input(line):
	line_split = line.strip().split()
	if len(line_split) < 4:
		raise ValueError('INPUT TOO SHORT')

	chromosome = line_split[0]
	chromosome = chromosome.strip('chr')
	if chromosome not in CHROMOSOMES:
		raise ValueError('NOT A CHROMOSOME')

	try:
		position = int(line_split[1])
	except ValueError:
		raise ValueError('NOT A POSITION')

	reference = line_split[2]
	mutated = line_split[3]
	if not isDNA(reference) or not isDNA(mutated) or reference == mutated:
		raise ValueError('NOT A SUPPORTED VARIATION')

	return chromosome, position, reference, mutated

def strip_end_to_sigle_base(reference, mutated):
	#deletion
	if reference.endswith(mutated):
		reference = reference[:-len(mutated)]
		mutated = mutated[0]
		reference += mutated
	#insertion
	elif mutated.endswith(reference):
		mutated = mutated[:-len(reference)]
		reference = reference[0]
		mutated += reference
	return reference, mutated

def parse_aap_matrix(aap_matrix_filename):
	matrix = {}
	AA_ROW_FILE_FORMAT = ['ALA', 'ASP', 'CYS', 'GLU', 'PHE', 'GLY', 'HIS', 'ILE', 'LYS', 'LEU', 'MET', 'ASN', 'PRO', 'GLN', 'ARG', 'SER', 'THR', 'VAL', 'TRP', 'TYR']
	with open_file(aap_matrix_filename, 'r') as f:
		first_row = True
		for line in f:
			if len(line.strip()) == 0: continue
			line_split = line.strip().split()
			if first_row:
				if len(line_split) != 22: raise ValueError
				for i in range(2,22):
					if line_split[i].upper() != AA_ROW_FILE_FORMAT[i-2]:
						print >> sys.stderr, line_split[i].upper(), AA_ROW_FILE_FORMAT[i-2]
						raise ValueError
				first_row = False
				continue

			feature_index = int(line_split[0])
			matrix[feature_index] = {}
			i = 2
			for aa in AA_ROW_FILE_FORMAT:
				matrix[feature_index][AA_3TO1[aa]] = float(line_split[i])
				i = i + 1

	return matrix

def get_targets_from_raw_data(raw_data, is_classification):
	targets= []
	for line in raw_data:
		v = VariantData(line.strip().split())
		targets.append(v.disease if is_classification else v.ddg)
	return targets

def get_relative_asa(amino_acid, absolute_asa):
	return min(1.0, absolute_asa/float(AA_VOLUME_ASA[amino_acid]))

class DsspResidue:
	def __init__(self, res_id, aa, ss, detailed_ss, rasa, asa):
		self.res_id = res_id
		self.aa = aa
		self.ss = ss
		self.detailed_ss = detailed_ss
		self.rasa = rasa
		self.asa = asa

def parse_dssp_chain(filename, chain, only_std_aa=True):
	dssp_chain = collections.OrderedDict({})
	with open_file(filename, 'r') as f:
		header = True
		for line in f:
			line_split = line.strip().split()
			if header:
				if line_split[0] != '#' or line_split[1] != 'RESIDUE': continue
				else: header = False; continue

			if line[13] == '!': continue #end of the current chain
			if line[11] != chain: continue

			aa = line[13]
			if aa.isalpha() and aa.islower(): aa = 'C' #cystine has special coding in DSSP
			if only_std_aa and aa not in AMINO_ACIDS:
				print >> sys.stderr, filename, line
				raise ValueError
			res_id = int(line[6:10])
			detailed_ss = line[16]
			asa = int(line[34:38])

			if detailed_ss == ' ' or detailed_ss == 'T' or detailed_ss == 'S':
				ss = 'C'
			elif detailed_ss == 'E' or detailed_ss == 'B':
				ss = 'E'
			elif detailed_ss == 'G' or detailed_ss == 'H' or detailed_ss == 'I':
				ss = 'H'
			else:
				print >> sys.stderr, 'Unexpected type of secondary structure:', detailed_ss; raise ValueError

			rasa = get_relative_asa(aa, asa) if aa in AMINO_ACIDS else None
			dssp_chain[res_id] = DsspResidue(res_id, aa, ss, detailed_ss, rasa, asa)

	return dssp_chain

def translate_dna(dna_seq, codon_table=CODON_TABLE):
	protein = ''
	dna_seq = dna_seq.upper()
	for i in range(0, len(dna_seq), 3):
		if i + 3 <= len(dna_seq):
			protein += codon_table[dna_seq[i:i + 3]]
	return protein

def check_standard_letters(letter, filename=None, raise_exc=False, seq_type=FASTA_PROT, no_warnings=False):
	if seq_type == FASTA_PROT:
		alphabet, info = AMINO_ACIDS, 'amino acid'
	elif seq_type == FASTA_DNA:
		alphabet, info = DNA_NUCLEOTIDES, 'DNA nucleotide'
	elif seq_type == FASTA_RNA:
		alphabet, info = RNA_NUCLEOTIDES, 'RNA nucleotide'
	else: raise ValueError
	if letter not in alphabet:
		if not no_warnings: print >> sys.stderr, 'Non-standard', info, letter, 'in', filename
		if raise_exc: raise ValueError

class Fasta:
	def __init__(self, header, seq, filename=None, only_std_letters=False, seq_type=FASTA_PROT, no_warnings=False):
		for letter in seq:
			check_standard_letters(letter, filename, only_std_letters, seq_type, no_warnings)
		self.header = header
		self.seq = seq

	def print_fasta(self, line_len=None):
		return self.header + '\n' + (self.seq if line_len is None else '\n'.join(textwrap.wrap(self.seq, line_len)))

	def __str__(self):
		return self.seq

	def __repr__(self):
		return self.__str__()

def parse_fasta(filename, only_std_letters=True, replace_U=False, seq_type=FASTA_PROT, no_warnings=False):
	if seq_type != FASTA_PROT and replace_U: raise ValueError
	fastas = []
	with open_file(filename, 'r') as f:
		header, seq = None, ''
		for line in f:
			if line[0] == '>':
				if header is not None:
					fastas.append(Fasta(header, seq if not replace_U else seq.replace('U', 'C'), filename, only_std_letters, seq_type, no_warnings))
				header = line.strip()
				seq = ''
			else:
				seq += line.strip()

		if header is not None:
			fastas.append(Fasta(header, seq if not replace_U else seq.replace('U', 'C'), filename, only_std_letters, seq_type, no_warnings))
	return fastas
