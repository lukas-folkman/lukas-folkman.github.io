#!/usr/bin/env python
import sys, os

def readque(fn, nprint=0):
	if nprint == 0:
		lines = file(fn).readlines()
	else:
		lines = file(fn).readlines()[-5000:]
	list1 = []
	for i in range(len(lines)) if nprint == 0 else range(len(lines)-1, -1, -1):
		x = lines[i]
		ss = x.split()
		if len(ss) < 2: continue
		list1.append(i)
		if nprint > 0 and len(list1) >= nprint: break
	if len(list1) == 0: return

	for i,n in enumerate(list1):
		ss = lines[n].split()
		descr = ss[0]
		try:
			n0 = int(ss[2])
			if n0 > 0: descr = ' '.join(ss[3:3+n0])
		except:
			pass
		if len(descr) > 60: descr = descr[:57] + '...'
#		print "%d. <a href=info/%s/results.html>job %s</a> <br>" % (i+1, ss[0], descr)
		print "%d. job %s <br>" % (i+1, descr)
#
#
fn = sys.argv[1]
nprint = int(sys.argv[2]) if len(sys.argv) > 2 else 0
readque(fn, nprint)
