<html>
<title>EASE-MM: prediction of mutation-induced stability changes</title>
<!-- Lukas Folkman,  21/7/2015 -->
<META name=keywords content="stability change, missense mutation, amino acid substitution, non-synonymous
SNV, free energy change, server">
<head>
<style>
a:link {color:green;}
a:visited {color:green;}
a:hover {color:#c5000b;}
a:active {color:green;}
</style>
</head>

<body bgcolor="cornsilk">
<center>
<h1><font color=green>EASE-MM Genome:</font> prediction of mutation-induced <BR> stability changes for the human genome</h1>

<img src="./mutation.png" alt="EASE-MM: Evolutionary, Amino acid, and Structural Encodings with Multiple Models" width="500"> 
<p>

<?php
$SEQ = $_REQUEST['mutations'];
if($SEQ == ""){
?>
	<B><font color=green>EASE-MM Genome</font> predicts single-nucleotide variants (SNVs) in the human genome.<BR>
	For predicting amino acid substitutions in protein sequences, use <a href=http://sparks-lab.org/server/ease/protein>EASE-MM Protein</a>.</B>

	<FORM enctype='multipart/form-data' ACTION="index.php" METHOD="post">
	<table border="0" >
	<tr>
	   <td align=left> E-mail address (optional): </td>
	   <td align=left> <INPUT TYPE="TEXT" VALUE="" NAME="EMAIL" SIZE=53></td>
	</tr>

	<tr>
	   <td align=left> Job name (optional): </td>
	   <td align=left> <INPUT TYPE="TEXT" VALUE="" NAME="DESCRIPTION" SIZE=53></td>
	</tr>

	<tr>
	<td colspan=2> <Strong>Input your sequences and mutations (<a href=ease_vcf_format.txt>VCF format and examples</a>):</Strong><br>
	<textarea name="mutations" rows=10 cols=70></textarea> </td>
	</tr>
	</table>

	<INPUT TYPE="SUBMIT" VALUE="Submit ">
	<INPUT TYPE="RESET"  VALUE="Clear">
	<INPUT TYPE="hidden" NAME="METHOD" VALUE="EASE">
	</FORM> 
	<p><b>To check the status of your submission, see the <a href=../queue.php>queue</a>.<br>
	To learn more about EASE-MM, see the <a href=../ease_output.txt>output fromat</a> and <a href=../datasets.zip>training and testing datasets</a>.<br>
	By using this service, you accept the <a href=http://sparks-lab.org/Softwares-Services_files/notices.htm>terms and conditions</a>.</b></p>
<?php
	}
else {
	$hostnm = gethostbyaddr($_SERVER['HTTP_X_FORWARDED_FOR']);
	$date = date("Y-m-d H:i:s");
	$eml = $_REQUEST['EMAIL'];
	$descrip = $_REQUEST['DESCRIPTION'];
	if($eml == "") {$eml = "unknown";}
	$qid = rand(1, 9999);
	$fweb = "../tmp/ease$qid";
	$fp = fopen($fweb, "w");
	fprintf($fp, "EASEMM: genome\n");
	fprintf($fp, "EMAIL: %s\n", $eml);
	fprintf($fp, "DESCRIPTION: %s\n", $descrip);
	fprintf($fp, "HOST: %s\n", $hostnm);
	fprintf($fp, "QUERY:\n%s\n", $SEQ);
	chmod($fweb, 0666);
	fclose($fp);
	echo exec("python ../readweb.py $fweb 2>&1");
	$info = $_REQUEST['METHOD'] . " $target";

}
?>

</center>
</p>
<p>
<br>
<b>Please cite the following article:</b>
<br>
<ul><li>
Lukas Folkman, Bela Stantic, Abdul Sattar, and Yaoqi Zhou, ‘EASE-MM: sequence-based prediction of mutation-induced stability changes with feature-based multiple models’, <I>Journal of Molecular Biology</I> (2016), <A href="http://dx.doi.org/10.1016/j.jmb.2016.01.012">doi:10.1016/j.jmb.2016.01.012</A>.
</ul></li>
</p>
<br>
<div>
<hr>Please address any questions or comments to <a href=http://sparks-lab.org/lukas/>Lukas Folkman</a>:
<img src="../email.png" alt="An image dispalying the contact e-mail address." width="220" style="position:relative; top:4.7px;"> 
</div>
<?php include("../misc.php"); google_analytic();?>

</body>
</html>
