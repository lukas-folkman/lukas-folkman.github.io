#!/usr/bin/env python
from sys import *
import random, os, time, shutil, re

webdir = 'info/'
logdir = 'log/'
lockqueue = logdir + 'lockqueue'
fqueue = logdir + '_queue.dat'
def buildweb(sdir):
	fweb = os.path.join(sdir, 'results.html')
	fpo = open(fweb, 'w')
	os.chmod(fweb, 0666)
	print >>fpo, """<html><title>EASE-MM: prediction results</title>
	<head>
	<style> a:link {color:green;} a:visited {color:green;} a:hover {color:#c5000b;} a:active {color:green;}	</style>
	<meta http-equiv="refresh" content="60;url=results.html">
	</head><body>
	<h1>Your job is being processed.</h1>
	<p>Please wait for 30 mins or up to a few hours depending on the number of your sequences and your position in the <a href=http://sparks-lab.org/server/ease/queue.php>queue</a>.<br>
	You will receive an e-mail (if provided) once the job has finished. You can also bookmark this page for your convenience.<br>
	These are your inputs submitted for this job: <a href=query>query file</a>.
	<hr>Please contact the web-master if you have any problems.</p>
	</body></html>
	"""
	fpo.close()
def skip1(line):
	global nskip
	nskip += 1
	print >>stderr, 'skip line: %s' % x.strip()
def allocate_file():
	global jobid
	for i in range(33):
		k = random.randint(1, 9999)
		jobid = '%04d' % k
		d1 = os.path.join(webdir, jobid)
		if not os.path.isdir(d1):
			os.mkdir(d1); os.chmod(d1, 0777)
			break
	f1 = os.path.join(d1, 'query')
	open(f1, 'w').close()
	os.chmod(f1, 0666)
	buildweb(d1)
	return f1
def write1(ss):
	global fout, fpo, nrec
	if fout == "":
		fout = allocate_file()
		fpo = open(fout, 'w')
	nrec += 1
	print >>fpo, ' '.join(ss)
def clean1():
	if fout != "": os.remove(fout)
#
#
if len(argv) < 2:
	print >>stderr, 'usage: RUN fweb_filename'; exit()
email = 'unknown'
nskip = nrec = 0
jobid = fout = hostnm = ''; fpo = stdout
read_query = False
email = 'UNK'
for x in open(argv[1]):
	ss = x.split()
	status = ''
	if read_query:
		write1(ss)
	elif len(ss) == 0:
		continue
	elif ss[0] == 'EMAIL:':
		if '@' in x: email = ''.join(ss[1:])
	elif ss[0] == 'HOST:':
		hostnm = ss[-1]
	elif ss[0] == 'DESCRIPTION:':
		description = x[12:]
	elif ss[0] == 'QUERY:':
		read_query = True
	else: skip1(x)
if jobid == '':
	print '<font color=red> No input detected</font>'
	print >>open(logdir+'queue.err', 'a'), argv[1], hostnm, time.asctime()
	exit()
#
print "moving"
shutil.move(argv[1], os.path.join(webdir, jobid))
for i in range(9):
	if not os.path.isfile(lockqueue): break
file(lockqueue, 'w').close()
#
# write record
print "writing record"
fp = open(fqueue, 'a')
ss = description.split()
print >>fp, jobid, email, len(ss), ' '.join(ss), hostnm, nrec, time.asctime()
fp.close()
print '<font size=5><strong><a href=info/%s/results.html>Click this link</a> to see your results.</strong></font>' % jobid
os.remove(lockqueue)
