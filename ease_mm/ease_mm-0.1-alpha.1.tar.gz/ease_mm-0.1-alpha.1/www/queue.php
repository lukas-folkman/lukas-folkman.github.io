<html>
<title>EASE-MM: queue</title>
<style>
a:link {color:green;}
a:visited {color:green;}
a:hover {color:#c5000b;}
a:active {color:green;}
</style>
<head>
<center>
</head>
<h1><font size=6 color=green>EASE-MM:</font> job queue<br></h1></center>
<body bgcolor="cornsilk">
<a href=./>Back to the server</a><br><br>
<?php
	$n = $_REQUEST['n'];
	if($n == ""){
	echo "<b>Current queue:</b><br>\n";
	system("python readqueue.py log/_queue.dat 0");
	echo "<br>\n";
	echo "<b>30 most recently finished jobs (the first job may be still running):</b><br>\n";
	system("python readqueue.py log/_queue.his 30");
	echo "<br>\n";	
	echo "<a href=?n=100>Show more</a>\n";
	} else {
	echo "<b>100 most recently finished jobs (the first job may be still running):</b><br>\n";
	system("python readqueue.py log/_queue.his $n");
	echo "<br>\n";
	}
?>
</body>
</html>
