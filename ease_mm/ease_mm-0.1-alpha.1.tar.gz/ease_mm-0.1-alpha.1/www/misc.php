<?php
if( !isset($__MISC) ) {
$__MISC = 1;

$admin_name = "Lukas Folkman";
$admin_email = "lukas.folkman@griffithuni.edu.au";

function flush2 (){
	echo(str_repeat(' ',2024));
	// check that buffer is actually set before flushing
	if (ob_get_length()){		   
		@ob_flush();
		@flush();
		@ob_end_flush();
	}   
	@ob_start();
}
function getremotehost(){
	$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
	if($ip == ""){
		$ip = $_SERVER['REMOTE_ADDR'];
	}
	return gethostbyaddr($ip);
}
function contact_admin(){
	global $admin_email, $admin_name;
	google_analytic();
	echo <<<_EOF
	<div style="position:relative; bottom:0;">
	<hr>
	Please address any questions or comments to
	<a href="mailto:$admin_email">$admin_name</a>.
	</div>
_EOF;
}
function writeLOG($logfile, $info){
	$fp=fopen($logfile, "a");
	if($fp == NULL){
		echo "fail to open: $logfile\n"; return;
	}
	$hostnm = getremotehost();
	fprintf($fp, "%s %s %s\n", $info, $hostnm, date("Y-m-d H:i:s"));
	fclose($fp);
}

function google_analytic(){
	echo <<<_EOF
<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-16402543-2']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>
_EOF;
}

}
?>
