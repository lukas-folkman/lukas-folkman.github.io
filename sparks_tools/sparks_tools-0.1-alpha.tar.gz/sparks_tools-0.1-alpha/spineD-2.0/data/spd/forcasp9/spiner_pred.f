c     Retraining Protein Structure Prediction by Artificial Neural Network
c	21 window 
c	g77 -ffixed-line-length-none -Wall -W -Wsurprising  -O2 -o spiner.e spiner.f
c	ifort -132 -watch all -warn all -O2 -o spiner.e spiner.f
c	ifort -132 -O2 -o spiner.e spiner.f
c	this code originated from /data3/efaraggi/protein/spine/crossvald/new/t6.peak/t2.average/corrected
c	later from: /data3/efaraggi/protein/spine2.0/t7.sprt/predmach/step1/combine/tatctdteti/h150
c	08/31/07:   /data3/efaraggi/papers/2peak/data/weak/j2pk/weaker3/boosting/t5
c	11/07/07:   retraining on missed peak clasifications.
c	from:	    /data3/efaraggi/papers/2peak/data/weak/j2pk/weaker3/boosting/t6.new/linear/nodisca/h14/corrected
c	12/24/07    /data3/efaraggi/papers/2peak/data/CV10/t1.step1/cv01/psi/av01
c	gfortran -ffixed-line-length-none [-O2 | -fbounds-check -g ] -o spiner_pred.e spiner_pred.f (EF 2011)
c

      program SPINE_r
      implicit real*8(a-h,o-z)
      PARAMETER(nrdx=1900,nrpx=4300,naax=1050000,nrx=21,nip=58,nw1=51,nw2=51,nrxo=1,nfilt=11)

      common/weights/ wi(nrx+1,nip,nw1),wh(nw1+1,nw2)
      common/oldwei/ oldwi(nrx+1,nip,nw1),oldwh(nw1+1,nw2)
      common/pwei/ wo2(nw2+1,nrxo,3),oldwo2(nw2+1,nrxo,3)
      common/filtwei/ fwi(nrx+1,3,nfilt), fwo(nfilt+1,nrxo,3)
      common/ofiltwei/ ofwi(nrx+1,3,nfilt), ofwo(nfilt+1,nrxo,3)
      common/filin/ protin(naax,nip+2),cdis(4,naax),phir2(naax,3),phip(naax),phir(naax),dphir(naax)
      common/filout/ phia(naax),icphi(naax)
      common/inout/ resv(nrx+1,nip),phi2(nrxo,3)
      common/neurons/ hnu1(nw1+1),hnu2(nw2+1),onu2(naax,3),hnuf(nfilt+1),onuf(nrxo,3), finp(nrx,3)
      common/learn/ alpha, ratel, rmoment
      common/edges/ ibegia(naax),iendia(naax),ibegoa(naax),iendoa(naax), nisf, nosf
      common/misc/ rmae, ccoef, q10scr, q10prh, cvfrac, itsd
      common/dcays/ dij1(nrx,nw1),dij2(nw2,nrxo),dfac,dijh(nw1,nw2),dijfi(nrx,nfilt),dijfo(nfilt,nrxo)
      character rtrainf(nrpx)*120
      common/sinout/ numtrf,ntotf,ntf,numtra,ntota,nta,idxprt(nrpx),rtrainf
      common/peaks/ peks(naax)
      character protnm(naax)*10, aac(naax)*1, dra(naax)*1
      common/pnaac/ protnm, aac, dra
      common/ssprob/ onu2p(naax,3)
c--   modified by Tuo + Eshel
      integer nrli, nwli, nargs
      character rinpath*200, winpath*200, arg*200
      common/numofin/ nrli, nwli, rinpath, winpath
c--

      character fylevld*120

c* Definition of the general input/output files
c--   number of residue-level/window-level inputs
      nrli = 33
      nwli = 25
      numoftrials = 100
      numdr = 2
      
      nargs=iargc()
      if (nargs.eq.2) then
        call getarg(1,arg)
	rinpath = trim(arg) // "/"
        call getarg(2,arg)
	winpath = trim(arg) // "/"
! Use with two command line options rinpath and winpath
      else
        rinpath = "/data5/tuozhang/project/casp9/disorder/experiment/casp8/rl/"
        winpath = "/data5/tuozhang/project/casp9/disorder/experiment/casp8/wl/"
      endif
c      write(*,*) nrli, nwli, trim(rinpath), trim(winpath)
c      stop
c--
      call getdefs(fylevld,nte,npe,icv)
      open(unit=15,file=fylevld)
      call netinit()    ! initialize weights
      call setio()	! initialize input/output
      call readwei(0)
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
CCCCCCCCCCCCCCCCCCCC--- OUTPUT CROSS VALIDATION  ---CCCCCCCCCCCCCCCCCCCC
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
        call initphi(phia,icphi)
        do ix=1,numtra
          call readwin(ix,0,0)
          call calcnet(ix,0)
        enddo
        do ix=numtra+1,nta
          call readwin(ix,1,0)
          call calcnet(ix,0)
        enddo
c        call normphi(phia)
        call calcerr(phia,numtra+1,nta)
        write(*,*) "Q10Pb:", q10prh
	write(15,*) 
	write(15,*) "#Cross Validation"
	write(15,*) "#----------------"
	write(15,*) ie,q10prh
	write(15,*) 
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
      write(15,*) "#After filter"
      write(15,*) "#------------"
      write(*,*) "#After filter"
      write(*,*) "#------------"
      call readweif(0)
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
CCCCCCCCCCCCCCCCCCCC--- OUTPUT CROSS VALIDATION  ---CCCCCCCCCCCCCCCCCCCC
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
        call initphi(phia,icphi)
        do ix=1,numtra
          call readwinf(ix)
          call calcnetf(ix,0)
        enddo
        do ix=numtra+1,nta
          call readwinf(ix)
          call calcnetf(ix,0)
        enddo
c        call normphi(phia)
        call calcerr(phia,numtra+1,nta)
        write(*,*) "Q10Pa:", q10prh
	write(15,*) 
	write(15,*) "#Cross Validation"
	write(15,*) "#----------------"
	write(15,*) ie,q10prh
	write(15,*) 
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
      close(15)
      do i=1,nta
        v3sm = 1.d0 / (3.d0 + onu2p(i,1) + onu2p(i,2) + onu2p(i,3))
        v1 = v3sm * (1.d0 + onu2p(i,1))
        v2 = v3sm * (1.d0 + onu2p(i,2))
        v3 = v3sm * (1.d0 + onu2p(i,3))
        write(99,499) protnm(i),aac(i),phip(i),phia(i),v1,v2,v3
      enddo
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
399   format (I6,2x,D12.4,2x,D12.4,2x,D12.4)
499   format (A10,2x,A2,2x,F5.1,2x,F5.1,2x,D12.4,2x,D12.4,2x,D12.4)
      stop
      end
c_______________________________________________________________________
      
c------------- subroutine getdefs-------------------------------
c--
c* Get initial definitions
c--
      subroutine getdefs(fylevld,nte,npe,icv)
      implicit real*8(a-h,o-z)
      PARAMETER(nrdx=1900,nrpx=4300,naax=1050000,nrx=21,nip=58,nw1=51,nw2=51,nrxo=1,nfilt=11)
      common/learn/ alpha, ratel, rmoment
      common/dcays/ dij1(nrx,nw1),dij2(nw2,nrxo),dfac,dijh(nw1,nw2),dijfi(nrx,nfilt),dijfo(nfilt,nrxo)
      common/misc/ rmae, ccoef, q10scr, q10prh, cvfrac, itsd
      character rtrainf(nrpx)*120
      common/sinout/ numtrf,ntotf,ntf,numtra,ntota,nta,idxprt(nrpx),rtrainf

      character fyle*6, fylein*120, fylevld*120
      character rtrain*15, rtraing(nrpx)*120

c* Definition of the general input/output files
      fyle='spiner'
      fylein=fyle//'.in'
      fylevld=fyle//'.valdav'
      open(unit=2,file=fylein)
c****  The following parameters are read from the input file progname.in
c*********** nte -- number of training epochs
      read(2,*)nte
c*********** npe -- size of protein set
      read(2,*)npe
c*********** ipe -- iterations per exemplar
      read(2,*)ipe
c*********** ratel -- learning rate
      read(2,*)ratel
c*********** rmoment -- initial momentum
      read(2,*)rmoment
c*********** alpha -- parameter for transfer function
      read(2,*)alpha
c*********** dfac -- parameter for distance decay matrix
      read(2,*)dfac
c*********** icv -- set for 10 fold cross validation
      read(2,*)icv
c*********** cvfrac -- fraction for cross validation
      read(2,*)cvfrac
c*********** rtrain -- file containing names of training proteins
      read(2,'(A)')rtrain
      close(2)

      open(unit=3,file=rtrain)
c* read names of files containing training proteins
      i = 1
      do 245 while (i.gt.0)
        read(3,'(A)',end=246)rtraing(i)
	i = i + 1
245   continue
246   continue
      close(3)
      ntotp = i-1
      if (npe.le.ntotp) then
        ntotf = npe
      else
        write(*,*) "Protein set too small for number of proteins selected, using full set."
        ntotf = ntotp
      endif
      numval2 = nint(cvfrac*ntotf)
      ntf = ntotf
c      ntotf = ntf-numval2
      numval = nint(0.05d0 * ntotf)
      numtrf = ntotf - numval

c      call plst(ntf,ntotf,numval2,icv,idxprt)

      do i=1,ntf
        rtrainf(i) = rtraing(i)
      enddo

      end
c___________________________________________________________________

c------------- subroutine plst-------------------------------
c--
c* Initialize the protein lists
c--
      subroutine plst(itot,ipt,ipv,indcv,lstt)
      implicit real*8(a-h,o-z)
      PARAMETER(nrdx=1900,nrpx=4300,naax=1050000,nrx=21,nip=58,nw1=51,nw2=51,nrxo=1,nfilt=11)
      common/misc/ rmae, ccoef, q10scr, q10prh, cvfrac, itsd

      integer itot, ipt, ipv, indcv
      integer lstt(nrpx)
      
      iptv = ipt + ipv
      if (iptv.eq.itot) then
        ivf = nint(cvfrac*indcv*iptv)
        ivs = ivf - ipv
        jt = 1
        jv = ipt+1
        do i=1,iptv
          if ((ivs.lt.i).and.(i.le.ivf)) then
            lstt(jv) = i
            jv = jv + 1
          else
            lstt(jt) = i
            jt = jt + 1
          endif
        enddo
      else
        write(*,*) "Problem generating protein list"
        stop
      endif

      end
c___________________________________________________________________

c------------- subroutine netinit -------------------------------
c--
c* Initialize the neural network (the weights are randomized)
c--
      subroutine netinit()
      implicit real*8(a-h,o-z)
      PARAMETER(nrdx=1900,nrpx=4300,naax=1050000,nrx=21,nip=58,nw1=51,nw2=51,nrxo=1,nfilt=11)

      common/weights/ wi(nrx+1,nip,nw1),wh(nw1+1,nw2)
      common/oldwei/ oldwi(nrx+1,nip,nw1),oldwh(nw1+1,nw2)
      common/pwei/ wo2(nw2+1,nrxo,3),oldwo2(nw2+1,nrxo,3)
      common/filtwei/ fwi(nrx+1,3,nfilt), fwo(nfilt+1,nrxo,3)
      common/ofiltwei/ ofwi(nrx+1,3,nfilt), ofwo(nfilt+1,nrxo,3)
      common/inout/ resv(nrx+1,nip),phi2(nrxo,3)
      common/neurons/ hnu1(nw1+1),hnu2(nw2+1),onu2(naax,3),hnuf(nfilt+1),onuf(nrxo,3), finp(nrx,3)
      common/misc/ rmae, ccoef, q10scr, q10prh, cvfrac, itsd
      common/dcays/ dij1(nrx,nw1),dij2(nw2,nrxo),dfac,dijh(nw1,nw2),dijfi(nrx,nfilt),dijfo(nfilt,nrxo)
      
      integer*4 timeArray(3)    ! Holds the hour, minute, and second
      double precision randnm !random LCG

        call itime(timeArray)     ! Get the current time for seed
        ta1 = timeArray(1) / 1.74
        ta2 = timeArray(2) / 4.35
        ta3 = timeArray(3) / 2.8
        jta3 = timeArray(3)
        ita3 = exp(ta3)
        ta3 = (mod(ita3,61)/2.8)
        ta4 = exp(ta1) + exp(ta2) + exp(ta3)
        ita4log = log10(ta4)
        ita4 = ta4
        dta4 = 10**ita4log * (ta4 - ita4)
        itsd = abs(dta4 - ta4) + ta3
c      itsd = 44027
        write(*,*) "random seed = ",itsd
c 578     continue
c          call itime(timeArray)     ! Get the current time for seed
c        if (timeArray(3) .eq. jta3) goto 578

c***   setting up the biases
      resv(nrx+1,1) = 1.d0
      hnu2(nw2+1) = 1.d0
      hnu1(nw1+1) = 1.d0
      hnuf(nfilt+1) = 1.d0

c***    randomizing weights
	do i=1,nrx+1
	  do j=1,nip
	    do k=1,nw1
	      atmp = randnm() - 0.5
	      wi(i,j,k) = atmp
	      oldwi(i,j,k) = atmp / 10.d0
	    enddo
	  enddo
	enddo

	do i=1,nw1+1
          do j=1,nw2
	    atmp = randnm() - 0.5
	    wh(i,j) = atmp
	    oldwh(i,j) = atmp / 10.d0
          enddo
	enddo

	do i=1,nw2+1
          do j=1,nrxo
            do k=1,3
	      atmp = randnm() - 0.5
   	      wo2(i,j,k) = atmp
	      oldwo2(i,j,k) = atmp / 10.d0
            enddo
          enddo
	enddo

	do i=1,nrx+1
	  do j=1,3
	    do k=1,nfilt
	      atmp = randnm() - 0.5
	      fwi(i,j,k) = atmp
	      ofwi(i,j,k) = atmp / 10.d0
	    enddo
	  enddo
	enddo
	do i=1,nfilt+1
          do j=1,3
	    atmp = randnm() - 0.5
	    fwo(i,1,j) = atmp
	    ofwo(i,1,j) = atmp / 10.d0
          enddo
	enddo

        delhi = (nrx-1.d0)/(nw1-1.d0)
c***    initialize distance matrix
	do i=1,nrx
          do k=1,nw1
	    dij1(i,k) = dfac / dsqrt(1.d0+((k-1)*delhi-i+1)*
     *                          ((k-1)*delhi-i+1))
	  enddo
	enddo

        jc = (nw1+1)/2
        jc2 = (nw2+1)/2
        mc = (nrxo+1)/2
	do i=1,nw1
          do j=1,nw2
	    dijh(i,j) = dfac / dsqrt(1.d0+delhi*delhi*(i-jc-j+jc2)*
     *                          (i-jc-j+jc2))
          enddo
	enddo

	do i=1,nw2
          do j=1,nrxo
	    dij2(i,j) = dfac / dsqrt(1.d0+((i-jc)*delhi-j+mc)*
     *                          ((i-jc)*delhi-j+mc))
          enddo
	enddo

        delhi = (nrx-1.d0)/(nfilt-1.d0)
c***    initialize distance matrix
	do i=1,nrx
          do k=1,nfilt
	    dijfi(i,k) = dfac / dsqrt(1.d0+((k-1)*delhi-i+1)*
     *                          ((k-1)*delhi-i+1))
	  enddo
	enddo

        jc = (nfilt+1)/2
        mc = (nrxo+1)/2
	do i=1,nfilt
          do j=1,nrxo
	    dijfo(i,j) = dfac / dsqrt(1.d0+((i-jc)*delhi-j+mc)*
     *                          ((i-jc)*delhi-j+mc))
          enddo
	enddo

      end
c___________________________________________________________________

c------------- subroutine outwei -------------------------------
c--
c* Output weights
c--
      subroutine outwei(ishift)
      implicit real*8(a-h,o-z)
      PARAMETER(nrdx=1900,nrpx=4300,naax=1050000,nrx=21,nip=58,nw1=51,nw2=51,nrxo=1,nfilt=11)
      common/weights/ wi(nrx+1,nip,nw1),wh(nw1+1,nw2)
      common/pwei/ wo2(nw2+1,nrxo,3),oldwo2(nw2+1,nrxo,3)

CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
CCCCCCCCCCCCCCCCCCCCCCCCC--- OUTPUT WEIGHTS  ---CCCCCCCCCCCCCCCCCCCCCCCC
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
      do i=1,nrx+1
	do j=1,nip
	  do k=1,nw1
	    write(ishift+77,*) wi(i,j,k)
	  enddo
	enddo
      enddo
      close(ishift+77)
      do i=1,nw1+1
        do j=1,nw2
	  write(ishift+78,*) wh(i,j)
        enddo
      enddo
      close(ishift+78)
      do i=1,nw2+1
        do j=1,nrxo
	  write(ishift+79,*) (wo2(i,j,k),k=1,3)
        enddo
      enddo
      close(ishift+79)

      end
c___________________________________________________________________

c------------- subroutine readwei -------------------------------
c--
c* Read optimized weights
c--
      subroutine readwei(ishift)
      implicit real*8(a-h,o-z)
      PARAMETER(nrdx=1900,nrpx=4300,naax=1050000,nrx=21,nip=58,nw1=51,nw2=51,nrxo=1,nfilt=11)
      common/weights/ wi(nrx+1,nip,nw1),wh(nw1+1,nw2)
      common/pwei/ wo2(nw2+1,nrxo,3),oldwo2(nw2+1,nrxo,3)

CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
CCCCCCCCCCCCCCCCCCCCCCCCC--- INPUT WEIGHTS  ---CCCCCCCCCCCCCCCCCCCCCCCCC
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
      do i=1,nrx+1
	do j=1,nip
	  do k=1,nw1
	    read(ishift+77,*) wi(i,j,k)
	  enddo
	enddo
      enddo
      close(ishift+77)
      do i=1,nw1+1
        do j=1,nw2
	  read(ishift+78,*) wh(i,j)
        enddo
      enddo
      close(ishift+78)
      do i=1,nw2+1
        do j=1,nrxo
	  read(ishift+79,*) (wo2(i,j,k),k=1,3)
        enddo
      enddo
      close(ishift+79)

      end
c___________________________________________________________________

c------------- subroutine outweif -------------------------------
c--
c* Output filter weights
c--
      subroutine outweif(ishift)
      implicit real*8(a-h,o-z)
      PARAMETER(nrdx=1900,nrpx=4300,naax=1050000,nrx=21,nip=58,nw1=51,nw2=51,nrxo=1,nfilt=11)
      common/filtwei/ fwi(nrx+1,3,nfilt), fwo(nfilt+1,nrxo,3)

CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
CCCCCCCCCCCCCCCCCCCCCCCCC--- OUTPUT WEIGHTS  ---CCCCCCCCCCCCCCCCCCCCCCCC
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
      do i=1,nrx+1
	do j=1,3
	  do k=1,nfilt
	    write(ishift+87,*) fwi(i,j,k)
	  enddo
	enddo
      enddo
      close(ishift+87)
      do i=1,nfilt+1
        do j=1,3
	  write(ishift+88,*) fwo(i,1,j)
        enddo
      enddo
      close(ishift+88)

      end
c___________________________________________________________________

c------------- subroutine readweif -------------------------------
c--
c* Read optimized weights
c--
      subroutine readweif(ishift)
      implicit real*8(a-h,o-z)
      PARAMETER(nrdx=1900,nrpx=4300,naax=1050000,nrx=21,nip=58,nw1=51,nw2=51,nrxo=1,nfilt=11)
      common/filtwei/ fwi(nrx+1,3,nfilt), fwo(nfilt+1,nrxo,3)

CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
CCCCCCCCCCCCCCCCCCCCCCCCC--- INPUT WEIGHTS  ---CCCCCCCCCCCCCCCCCCCCCCCCC
CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
      do i=1,nrx+1
	do j=1,3
	  do k=1,nfilt
	    read(ishift+87,*) fwi(i,j,k)
	  enddo
	enddo
      enddo
      close(ishift+87)
      do i=1,nfilt+1
        do j=1,3
	  read(ishift+88,*) fwo(i,1,j)
        enddo
      enddo
      close(ishift+88)

      end
c___________________________________________________________________

c------------- subroutine setio -------------------------------
c--
c* Setup the input/output arrays
c--
      subroutine setio()
      implicit real*8(a-h,o-z)
      PARAMETER(nrdx=1900,nrpx=4300,naax=1050000,nrx=21,nip=58,nw1=51,nw2=51,nrxo=1,nfilt=11)
      common/filin/ protin(naax,nip+2),cdis(4,naax),phir2(naax,3),phip(naax),phir(naax),dphir(naax)
      common/edges/ ibegia(naax),iendia(naax),ibegoa(naax),iendoa(naax), nisf, nosf
      character rtrainf(nrpx)*120
      common/sinout/ numtrf,ntotf,ntf,numtra,ntota,nta,idxprt(nrpx),rtrainf
      character protnm(naax)*10, aac(naax)*1, dra(naax)*1
      common/pnaac/ protnm, aac, dra
      character rinpath*200, winpath*200
      common/numofin/ nrli, nwli, rinpath, winpath

      character tc, tc2, tc3, tc4, predfl*120, protnm1*5, infile*120
      double precision tprot(59), tprotw(100)

c* midpoint for input/output windows
      nisf = (nrx+1)/2
      nosf = (nrxo+1)/2
c--      nrli = 33
c--      nwli = 25
c--      write(*,*) nrli,nwli,trim(rinpath),trim(winpath)
      if ((nrli+nwli).ne.nip) then
        write(*,*) "number of input features?", nrli,nwli,nip
	stop
      endif

      nta = 0
      do ix=1,ntf
        ntao = nta
        if (ix.eq.(numtrf+1)) numtra = nta 
        if (ix.eq.(ntotf+1)) ntota = nta
	infile = trim(rinpath)//trim(rtrainf(ix))//".dr"
c--	infile = "/data5/tuozhang/project/casp9/disorder/experiment/test/rl/"//trim(rtrainf(ix))//".dr"
        open(unit=4,file=infile)
	infile = trim(winpath)//trim(rtrainf(ix))//".dr"
c--	infile = "/data5/tuozhang/project/casp9/disorder/experiment/test/wl/"//trim(rtrainf(ix))//".dr"
        open(unit=44,file=infile)
        i = 1
        do 265 while (i.gt.0)
          read(4,*,end=266) tc,tc2,(tprot(j),j=1,nrli)
          read(44,*,end=266) tc3,tc4,(tprotw(j),j=1,nwli)
	  if ((tc.ne.tc3).or.(tc2.ne.tc4)) then
	    write(*,*) "Wrong???", tc, tc2, tc3, tc4
	    stop
	  endif

          nta = nta + 1
          aac(nta) = tc
	  dra(nta) = tc2
	  
          protnm(nta) = trim(rtrainf(ix))
          do j=1,nrli
            protin(nta,j) = tprot(j)
          enddo
          do j=1,nwli
            protin(nta,j+nrli) = tprotw(j)
          enddo

          if (tc2.eq."L") then
            phir2(nta,1) = 1.d0
            phir2(nta,2) = -1.d0
            phir2(nta,3) = -1.d0
            phip(nta) = 2.d0
          elseif (tc2.eq."S") then
            phir2(nta,1) = -1.d0
            phir2(nta,2) = 1.d0
            phir2(nta,3) = -1.d0
            phip(nta) = 1.d0
          elseif (tc2.eq."O") then
            phir2(nta,1) = -1.d0
            phir2(nta,2) = -1.d0
            phir2(nta,3) = 1.d0
            phip(nta) = 0.d0
          endif

          i = i + 1
265     continue
266     continue
        close(4)
        numres = i-1  ! number of residues in current protein

c* Setup the edges for each amino acid
        do i=1,numres
          inta = ntao + i
          ib = 1 + nisf - i
          if(ib.lt.1) ib = 1
          ibegia(inta) = ib
          ib = numres + nisf - i
          if(ib.gt.nrx) ib = nrx
          iendia(inta) = ib
          ib = 1 + nosf - i
          if(ib.lt.1) ib = 1
          ibegoa(inta) = ib
          ib = numres + nosf - i
          if(ib.gt.nrxo) ib = nrxo
          iendoa(inta) = ib
        enddo
      enddo

      end
c___________________________________________________________________

c------------- subroutine initphi -------------------------------
c--
c* Initialize output angle array
c--
      subroutine initphi(phit,icphit)
      implicit real*8(a-h,o-z)
      PARAMETER(nrdx=1900,nrpx=4300,naax=1050000,nrx=21,nip=58,nw1=51,nw2=51,nrxo=1,nfilt=11)
      character rtrainf(nrpx)*120
      common/sinout/ numtrf,ntotf,ntf,numtra,ntota,nta,idxprt(nrpx),rtrainf

      double precision phit(naax)
      integer icphit(naax)

      do i=1,nta
        phit(i) = 0.d0
        icphit(i) = 0
      enddo

      end
c___________________________________________________________________

c------------- subroutine readwin -------------------------------
c--
c* Read the current protein window
c--
      subroutine readwin(iwin,itp,itp2)
      implicit real*8(a-h,o-z)
      PARAMETER(nrdx=1900,nrpx=4300,naax=1050000,nrx=21,nip=58,nw1=51,nw2=51,nrxo=1,nfilt=11)
      common/filin/ protin(naax,nip+2),cdis(4,naax),phir2(naax,3),phip(naax),phir(naax),dphir(naax)
      common/inout/ resv(nrx+1,nip),phi2(nrxo,3)
      common/edges/ ibegia(naax),iendia(naax),ibegoa(naax),iendoa(naax), nisf, nosf
      character rinpath*200, winpath*200
      common/numofin/ nrli, nwli, rinpath, winpath
      
      integer iwin,itp,itp2

      do i=ibegia(iwin),iendia(iwin)
        irw = iwin-nisf+i
c--     residue-level inputs
        do j=1,nrli
          resv(i,j) = protin(irw,j)
        enddo
c--     window-level inputs
        do j=1,nwli
	  if (irw.eq.iwin) then
            resv(i,j) = protin(irw,j)
	  else
	    resv(i,j) = 0.d0
	  endif
        enddo
      enddo
      
      do i=ibegoa(iwin),iendoa(iwin)
        irw = iwin-nosf+i
        if (itp2.le.0) then		! PEAK (itp2=0)
          phi2(i,1) = phir2(irw,1)
          phi2(i,2) = phir2(irw,2)
          phi2(i,3) = phir2(irw,3)
        else				! dPHI (itp2=1)
          phi2(i,1) = dphir(irw)
          phi2(i,2) = dphir(irw)
        endif
      enddo

      end
c___________________________________________________________________

c------------- subroutine calcnet -------------------------------
c--
c* Calculate the neural network's output angle given input residue
c* sequence parameters in resv matrix
c--
      subroutine calcnet(iwin,itp)
      implicit real*8(a-h,o-z)
      PARAMETER(nrdx=1900,nrpx=4300,naax=1050000,nrx=21,nip=58,nw1=51,nw2=51,nrxo=1,nfilt=11)
      common/weights/ wi(nrx+1,nip,nw1),wh(nw1+1,nw2)
      common/pwei/ wo2(nw2+1,nrxo,3),oldwo2(nw2+1,nrxo,3)
      common/filout/ phia(naax),icphi(naax)
      common/inout/ resv(nrx+1,nip),phi2(nrxo,3)
      common/neurons/ hnu1(nw1+1),hnu2(nw2+1),onu2(naax,3),hnuf(nfilt+1),onuf(nrxo,3), finp(nrx,3)
      common/edges/ ibegia(naax),iendia(naax),ibegoa(naax),iendoa(naax), nisf, nosf
      common/dcays/ dij1(nrx,nw1),dij2(nw2,nrxo),dfac,dijh(nw1,nw2),dijfi(nrx,nfilt),dijfo(nfilt,nrxo)
      common/peaks/ peks(naax)
      integer iwin,itp
      
      double precision tfunc !transfer function

c** Calculate nueron values of the first hidden layer
      do i=1,nw1
        ztemp=0.d0
	do j=ibegia(iwin),iendia(iwin)
	  do k=1,nip
	    ztemp = ztemp + resv(j,k) * wi(j,k,i) * dij1(j,i)
	  enddo
	enddo
        ztemp = ztemp + resv(nrx+1,1) * wi(nrx+1,1,i)
	hnu1(i) = tfunc(ztemp)
      enddo

      do i=1,nw2
        ztemp=0.d0
	do j=1,nw1
          ztemp = ztemp + hnu1(j) * wh(j,i) * dijh(j,i)
	enddo
        ztemp = ztemp + hnu1(nw1+1) * wh(nw1+1,i)
	hnu2(i) = tfunc(ztemp)
      enddo

c** Calculate output nueron values
      do i=ibegoa(iwin),iendoa(iwin)
        do k=1,3
          ztemp=0.d0
          do j=1,nw2
            ztemp = ztemp + hnu2(j) * wo2(j,i,k) * dij2(j,i)
          enddo
          ztemp = ztemp + hnu2(nw2+1) * wo2(nw2+1,i,k)
          onu2(iwin,k) = tfunc(ztemp)
        enddo

CC!CC: Need to modify next lines and normphi to run more than one ouput (i.e., if nrxo>1)
CCCCC! PEAK (itp=0)
        if (itp.le.0) then
          if (onu2(iwin,3).ge.onu2(iwin,2)) then
            if (onu2(iwin,3).ge.onu2(iwin,1)) then
              r2phin = 0.d0
            else
              r2phin = 2.d0
            endif
          else
            if (onu2(iwin,1).ge.onu2(iwin,2)) then
              r2phin = 2.d0
            else 
              r2phin = 1.d0
            endif
          endif
          phia(iwin+i-nosf) = phia(iwin+i-nosf) + r2phin
          icphi(iwin+i-nosf) = icphi(iwin+i-nosf) + 1
CCCCC! dPHI (itp=1)
        endif
      enddo

      end
c___________________________________________________________________

c------------- subroutine normphi -------------------------------
c--
c* Normalize peak assignement (averaging)
c--
      subroutine normphi(phit)
      implicit real*8(a-h,o-z)
      PARAMETER(nrdx=1900,nrpx=4300,naax=1050000,nrx=21,nip=58,nw1=51,nw2=51,nrxo=1,nfilt=11)
      character rtrainf(nrpx)*120
      common/sinout/ numtrf,ntotf,ntf,numtra,ntota,nta,idxprt(nrpx),rtrainf

      double precision phit(naax)

      do i=1,nta
        if (phit(i).lt.0) then
          phit(i) = -1.d0
        else
          phit(i) = 1.d0
        endif
      enddo

      end
c___________________________________________________________________

c------------- subroutine readwinf -------------------------------
c--
c* Read the current protein window
c--
      subroutine readwinf(iwin)
      implicit real*8(a-h,o-z)
      PARAMETER(nrdx=1900,nrpx=4300,naax=1050000,nrx=21,nip=58,nw1=51,nw2=51,nrxo=1,nfilt=11)
      common/filin/ protin(naax,nip+2),cdis(4,naax),phir2(naax,3),phip(naax),phir(naax),dphir(naax)
      common/inout/ resv(nrx+1,nip),phi2(nrxo,3)
      common/neurons/ hnu1(nw1+1),hnu2(nw2+1),onu2(naax,3),hnuf(nfilt+1),onuf(nrxo,3), finp(nrx,3)
      common/edges/ ibegia(naax),iendia(naax),ibegoa(naax),iendoa(naax), nisf, nosf
      
      integer iwin

      do i=ibegia(iwin),iendia(iwin)
        irw = iwin-nisf+i
        do j=1,3
          finp(i,j) = onu2(irw,j)
        enddo
      enddo
      
      do i=ibegoa(iwin),iendoa(iwin)
        irw = iwin-nosf+i
        do j=1,3
          phi2(i,j) = phir2(irw,j)
        enddo
      enddo

      end
c___________________________________________________________________

c------------- subroutine calcnetf -------------------------------
c--
c* Calculate the neural network's output 
c--
      subroutine calcnetf(iwin,itp)
      implicit real*8(a-h,o-z)
      PARAMETER(nrdx=1900,nrpx=4300,naax=1050000,nrx=21,nip=58,nw1=51,nw2=51,nrxo=1,nfilt=11)
      common/filtwei/ fwi(nrx+1,3,nfilt), fwo(nfilt+1,nrxo,3)
      common/filout/ phia(naax),icphi(naax)
      common/neurons/ hnu1(nw1+1),hnu2(nw2+1),onu2(naax,3),hnuf(nfilt+1),onuf(nrxo,3), finp(nrx,3)
      common/edges/ ibegia(naax),iendia(naax),ibegoa(naax),iendoa(naax), nisf, nosf
      common/dcays/ dij1(nrx,nw1),dij2(nw2,nrxo),dfac,dijh(nw1,nw2),dijfi(nrx,nfilt),dijfo(nfilt,nrxo)
      common/ssprob/ onu2p(naax,3)
      integer iwin,itp

      double precision tfunc !transfer function

c** Calculate nueron values of the first hidden layer
      do i=1,nfilt
        ztemp=0.d0
	do j=ibegia(iwin),iendia(iwin)
	  do k=1,3
	    ztemp = ztemp + finp(j,k) * fwi(j,k,i) * dijfi(j,i)
	  enddo
	enddo
        ztemp = ztemp + fwi(nrx+1,1,i)
	hnuf(i) = tfunc(ztemp)
      enddo

c** Calculate output nueron values
      do i=ibegoa(iwin),iendoa(iwin)
        do k=1,3
          ztemp=0.d0
          do j=1,nfilt
            ztemp = ztemp + hnuf(j) * fwo(j,i,k) * dijfo(j,i)
          enddo
          ztemp = ztemp + hnuf(nfilt+1) * fwo(nfilt+1,i,k)
          onuf(i,k) = tfunc(ztemp)
          onu2p(iwin,k) = onuf(i,k)
        enddo

CC!CC: Need to modify next lines and normphi to run more than one ouput (i.e., if nrxo>1)
CCCCC! PEAK (itp=0)
        if (itp.le.0) then
          if (onuf(i,3).ge.onuf(i,2)) then
            if (onuf(i,3).ge.onuf(i,1)) then
              r2phin = 0.d0
            else
              r2phin = 2.d0
            endif
          else
            if (onuf(i,1).ge.onuf(i,2)) then
              r2phin = 2.d0
            else 
              r2phin = 1.d0
            endif
          endif
          phia(iwin+i-nosf) = phia(iwin+i-nosf) + r2phin
          icphi(iwin+i-nosf) = icphi(iwin+i-nosf) + 1
CCCCC! dPHI (itp=1)
        endif
      enddo

      end
c___________________________________________________________________

c------------- subroutine normphiz -------------------------------
c--
c* Normalize output angle (averaging)
c--
      subroutine normphiz()
      implicit real*8(a-h,o-z)
      PARAMETER(nrdx=1900,nrpx=4300,naax=1050000,nrx=21,nip=58,nw1=51,nw2=51,nrxo=1,nfilt=11)
      common/filout/ phia(naax),icphi(naax)
      character rtrainf(nrpx)*120
      common/sinout/ numtrf,ntotf,ntf,numtra,ntota,nta,idxprt(nrpx),rtrainf

      do i=1,nta
        phia(i) = phia(i) / icphi(i)
      enddo

      end
c___________________________________________________________________

c------------- subroutine calcerr -------------------------------
c--
c* Calculate the neural network's error
c--
      subroutine calcerr(phit,istart,ifinish)
      implicit real*8(a-h,o-z)
      PARAMETER(nrdx=1900,nrpx=4300,naax=1050000,nrx=21,nip=58,nw1=51,nw2=51,nrxo=1,nfilt=11)
      common/misc/ rmae, ccoef, q10scr, q10prh, cvfrac, itsd
      common/filin/ protin(naax,nip+2),cdis(4,naax),phir2(naax,3),phip(naax),phir(naax),dphir(naax)
      
      double precision phit(naax)

c** Calculate error
      q10prh = 0.d0
      do i=istart,ifinish
        if (dabs(phit(i)-phip(i)).le.0.1d0) then
          q10prh = q10prh + 1.d0
        endif
      enddo
      q10prh = q10prh / (ifinish - istart + 1)

      end
c___________________________________________________________________

c------------- subroutine calcor -------------------------------
c--
c* Calculate the neural network's correlation and Q10 errors
c--
      subroutine calcor(phit,istart,ifinish)
      implicit real*8(a-h,o-z)
      PARAMETER(nrdx=1900,nrpx=4300,naax=1050000,nrx=21,nip=58,nw1=51,nw2=51,nrxo=1,nfilt=11)
      common/misc/ rmae, ccoef, q10scr, q10prh, cvfrac, itsd
      common/filin/ protin(naax,nip+2),cdis(4,naax),phir2(naax,3),phip(naax),phir(naax),dphir(naax)
      
      double precision phit(naax)
      double precision tphi(naax),tphip(naax)

c** Calculate error, correlation and Q10
      rmae = 0.d0
      avphi = 0.d0
      avphip = 0.d0
      q10scr = 0.d0
      q10prh = 0.d0
      do i=istart,ifinish
        erro1 = dabs(phir(i) - phit(i))
        rmae = rmae + erro1
        avphi = avphi + phir(i)
	avphip = avphip + phit(i)
        iqrh = (1.d0+phir(i)) / 0.2d0
        iqph = (1.d0+phit(i)) / 0.2d0
        if (iqrh.eq.iqph) q10scr = q10scr + 1.d0
        if (erro1.le.0.2d0) q10prh = q10prh + 1
      enddo
      rmae = rmae / (ifinish - istart + 1)
      avphi = avphi / (ifinish - istart + 1)
      avphip = avphip / (ifinish - istart + 1)
      q10scr = q10scr / (ifinish - istart + 1)
      q10prh = q10prh / (ifinish - istart + 1)

      do i=istart,ifinish
        tphi(i) = phir(i) - avphi
        tphip(i) = phit(i) - avphip
      enddo

      crhn = 0.d0
      cnor1hn = 0.d0
      cnor2hn = 0.d0
      do i=istart,ifinish
	crhn = crhn + tphi(i)*tphip(i)
	cnor1hn = cnor1hn + tphi(i)*tphi(i)
	cnor2hn = cnor2hn + tphip(i)*tphip(i)
      enddo
      ccoef = crhn / (sqrt(cnor1hn)*sqrt(cnor2hn))

      end
c___________________________________________________________________

c------------- function tfunc(xoutp) -------------------------------
c--
c* This is the transfer function f(x) = 1/(1+exp(alpha*x))
c* Note: the derivative f'(x) = alpha*f(x)*(1-f(x)). This fact is used
c* in the computation
c--
      real*8 function tfunc(xoutp)
      implicit real*8(a-h,o-z)
      common/learn/ alpha, ratel, rmoment

      tfunc = tanh(alpha * xoutp)

      return
      end function tfunc
c___________________________________________________________________

c------------- function randnm() -------------------------------
c--
c* LCG psuedorandom 
c--
      real*8 function randnm()
      implicit real*8(a-h,o-z)
      common/misc/ rmae, ccoef, q10scr, q10prh, cvfrac, itsd
      
      dvs = 2147483647.d0
      dnm = 2147483711.d0
      dml = 16807.d0

      if(itsd .lt. 1) itsd = itsd + dvs
      ditsd = itsd * dml
      ditsd = mod(ditsd, dvs)
      randnm = itsd / dnm
      itsd = ditsd

      return
      end function randnm
c___________________________________________________________________

c------------- function myfct() -------------------------------
c--
c* Recursive factorial
c--
c     recursive real*8 function yfct(yfnum)
c     implicit real*8(a-h,o-z)
c      
c     if(yfnum .le. 1.d0) then
c       yfct = 1
c     else
c       yfct = yfnum * yfct(yfnum-1)
c     endif
c
c     return
c     end function yfct
c___________________________________________________________________
